# AI-Powered Browser & IDE

## Overview

This is a developer-focused web application that combines a browser interface with an integrated development environment (IDE). The application enables users to browse the web, write and edit code, and deploy projects to GitHub. It features AI assistance powered by Hugging Face, multiple code generation tools, and specialized builders for mobile apps and automation workflows.

The project is designed as a hybrid system inspired by VS Code, Linear, GitHub Desktop, and Replit, prioritizing clean information hierarchy and efficient development workflows.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server with HMR support
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management

**UI Component System:**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component library (New York style variant) with custom theme system
- Tailwind CSS for utility-first styling with CSS variables for theming
- Support for both dark and light modes with persistent theme selection
- Custom color palette system ("Paisley", "Venom", "Marina", "Cosmic", "Echo") using HSL color values

**Code Editor:**
- Monaco Editor integration via @monaco-editor/react
- Support for multiple programming languages (JavaScript, TypeScript, Python, Java, C/C++, HTML, CSS, JSON)
- Theme-aware editor that syncs with application theme

**Key Features:**
1. **View Modes:** Browser-only, Code-only, and Split view
2. **Browser Integration:** Embedded iframe with navigation controls and code extraction
3. **AI Tools:** Plain English code generation, AI assist panel, and agent creator
4. **Deployment:** GitHub integration via Octokit REST API
5. **Builders:** APK builder for Android apps and workflow automation creator
6. **Self-Editing:** Tool to modify the application's own source code

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript running on Node.js
- Custom Vite middleware for development HMR
- Session-based architecture (infrastructure ready with connect-pg-simple)

**API Design:**
- RESTful API pattern with `/api` prefix
- JSON request/response format
- Centralized error handling middleware

**Data Layer:**
- Drizzle ORM for type-safe database operations
- PostgreSQL-compatible schema (configured for Neon serverless)
- In-memory storage implementation (MemStorage) as fallback
- Database schema includes user authentication foundation (users table with username/password)

### External Dependencies

**AI & Code Generation:**
- Hugging Face API (configured via user settings) for AI-assisted code generation and assistance
- GitHub API via @octokit/rest for repository operations and deployments

**Database:**
- Neon Serverless PostgreSQL (@neondatabase/serverless) for production data storage
- Drizzle ORM for schema management and migrations
- PostgreSQL session store (connect-pg-simple) for session persistence

**UI & Styling:**
- Google Fonts (Inter for UI, JetBrains Mono/Fira Code for code)
- Extensive Radix UI component library for accessible UI primitives
- Tailwind CSS with custom configuration for design system

**Developer Tools:**
- Monaco Editor for in-browser code editing
- Source map support via @jridgewell/trace-mapping
- Replit-specific plugins for development environment integration (cartographer, dev-banner, runtime-error-modal)

**Key Integration Points:**
- Settings panel stores API keys in localStorage (Hugging Face API key, GitHub token, GitHub username)
- All external service integrations are user-configured rather than server-side
- Browser sandbox restrictions using iframe sandbox attributes (allow-scripts, allow-same-origin, allow-forms)
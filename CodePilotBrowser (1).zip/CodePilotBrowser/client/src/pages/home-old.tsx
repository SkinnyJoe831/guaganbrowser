import { useState } from "react";
import { Menu, LayoutDashboard, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ThemePalette } from "@/components/ThemePalette";
import { BrowserToolbar } from "@/components/BrowserToolbar";
import { BrowserView } from "@/components/BrowserView";
import { DeveloperPanel } from "@/components/DeveloperPanel";
import { Dashboard } from "@/components/Dashboard";
import { CodeEditor } from "@/components/CodeEditor";
import { ViewModeToggle, ViewMode } from "@/components/ViewModeToggle";
import { SettingsPanel } from "@/components/SettingsPanel";
import { DeployModal } from "@/components/DeployModal";
import { AIAssistPanel } from "@/components/AIAssistPanel";
import { TemplateLibrary } from "@/components/TemplateLibrary";
import { AgentCreator } from "@/components/AgentCreator";
import { APKBuilder } from "@/components/APKBuilder";
import { PlainEnglishBuilder } from "@/components/PlainEnglishBuilder";
import { SelfEditingTool } from "@/components/SelfEditingTool";
import { WorkflowCreator } from "@/components/WorkflowCreator";
import { FileExplorer } from "@/components/FileExplorer";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetDescription
} from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { getTemplateCode } from "@/lib/templates";

export default function Home() {
  const [viewMode, setViewMode] = useState<ViewMode>("browser");
  const [currentUrl, setCurrentUrl] = useState("https://www.example.com");
  const [showSettings, setShowSettings] = useState(false);
  const [showDeploy, setShowDeploy] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showAgentCreator, setShowAgentCreator] = useState(false);
  const [showAPKBuilder, setShowAPKBuilder] = useState(false);
  const [showPlainEnglish, setShowPlainEnglish] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isDevMode, setIsDevMode] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const [showSelfEdit, setShowSelfEdit] = useState(false);
  const [showWorkflow, setShowWorkflow] = useState(false);
  const [showFileExplorer, setShowFileExplorer] = useState(true);
  const [tabs, setTabs] = useState([
    { id: '1', name: 'Untitled', code: "// Start coding here...\n", language: 'javascript' }
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const { toast } = useToast();

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  const updateActiveTabCode = (code: string) => {
    setTabs(tabs.map(t => t.id === activeTabId ? { ...t, code } : t));
  };

  const updateActiveTabLanguage = (language: string) => {
    setTabs(tabs.map(t => t.id === activeTabId ? { ...t, language } : t));
  };

  const addNewTab = () => {
    const newId = Date.now().toString();
    setTabs([...tabs, {
      id: newId,
      name: `Untitled ${tabs.length + 1}`,
      code: "// New file\n",
      language: 'javascript'
    }]);
    setActiveTabId(newId);
    toast({
      title: "✨ New Tab Created",
      description: "Start coding in your new file!",
    });
  };

  const closeTab = (id: string) => {
    if (tabs.length === 1) {
      toast({
        title: "Cannot close last tab",
        description: "You must have at least one tab open.",
        variant: "destructive"
      });
      return;
    }
    const tabIndex = tabs.findIndex(t => t.id === id);
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    if (activeTabId === id) {
      setActiveTabId(newTabs[Math.max(0, tabIndex - 1)].id);
    }
  };

  const handleNavigate = (url: string) => {
    setCurrentUrl(url);
  };

  const handleCodeDetected = (code: string) => {
    console.log("Code extracted:", code);
    setViewMode("code");
  };

  const handleExport = () => {
    console.log("Export project");
  };

  const handleSelectTemplate = (template: any) => {
    const templateCode = getTemplateCode(template.id);
    if (templateCode) {
      setTabs(tabs.map(t => t.id === activeTabId ? {
        ...t,
        name: template.name,
        code: templateCode.code,
        language: templateCode.language
      } : t));
      setShowTemplates(false);
      setViewMode("code");
      toast({
        title: `✨ ${template.name} Loaded!`,
        description: `Template code is ready in the editor. Start customizing!`,
      });
    }
  };

  const handleGenerateCode = (description: string) => {
    console.log("Generating code from:", description);
    setShowPlainEnglish(false);
    setViewMode("code");
    toast({
      title: "Code Generated! 🎉",
      description: "Your app is ready to customize in the code editor.",
    });
  };

  const handleAddToHome = () => {
    if ('beforeinstallprompt' in window) {
      toast({
        title: "Add to Home Screen",
        description: "Tap the share button and select 'Add to Home Screen'",
      });
    } else {
      toast({
        title: "Install YOU-N-I-VERSE 🌌",
        description: "Open this in your mobile browser to install it on your home screen!",
      });
    }
  };

  const handleFileSelect = (file: any) => {
    const existingTab = tabs.find(t => t.name === file.name);
    if (existingTab) {
      setActiveTabId(existingTab.id);
    } else {
      const newId = Date.now().toString();
      setTabs([...tabs, {
        id: newId,
        name: file.name,
        code: file.content || "// New file\n",
        language: file.language || 'javascript'
      }]);
      setActiveTabId(newId);
    }
  };

  const handleCreateFile = (parentId?: string) => {
    const newId = Date.now().toString();
    const fileName = `new-file-${tabs.length + 1}.js`;
    setTabs([...tabs, {
      id: newId,
      name: fileName,
      code: "// New file\n",
      language: 'javascript'
    }]);
    setActiveTabId(newId);
    toast({
      title: "File Created",
      description: fileName,
    });
  };

  const handleCreateFolder = (parentId?: string) => {
    toast({
      title: "Folder Created",
      description: "New folder added to explorer",
    });
  };

  const handleDeleteFile = (id: string) => {
    toast({
      title: "File Deleted",
      description: "File removed from explorer",
    });
  };

  return (
    <div className="h-screen w-full flex flex-col bg-background">
      {/* App Header - Only on Mobile */}
      <header className="lg:hidden flex items-center justify-between gap-2 p-2 border-b bg-card">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center">
            <span className="text-lg">🌌</span>
          </div>
          <h1 className="text-sm font-semibold">YOU-N-I-VERSE</h1>
        </div>
        
        <div className="flex items-center gap-1">
          <ThemePalette />
          <ThemeToggle />
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] sm:w-[320px] overflow-y-auto">
              <SheetTitle>Developer Menu</SheetTitle>
              <SheetDescription>Access development tools and features</SheetDescription>
              <div className="mt-4 space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => { setShowDashboard(true); setMobileMenuOpen(false); }}
                  data-testid="button-mobile-dashboard"
                >
                  <LayoutDashboard className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => { handleAddToHome(); setMobileMenuOpen(false); }}
                  data-testid="button-mobile-add-home"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add to Home
                </Button>
              </div>
              <div className="mt-4">
                <DeveloperPanel
                  onDeploy={() => { setShowDeploy(true); setMobileMenuOpen(false); }}
                  onTemplates={() => { setShowTemplates(true); setMobileMenuOpen(false); }}
                  onAgentCreator={() => { setShowAgentCreator(true); setMobileMenuOpen(false); }}
                  onAPKBuilder={() => { setShowAPKBuilder(true); setMobileMenuOpen(false); }}
                  onSettings={() => { setShowSettings(true); setMobileMenuOpen(false); }}
                  onPlainEnglish={() => { setShowPlainEnglish(true); setMobileMenuOpen(false); }}
                  onExport={handleExport}
                  onSelfEdit={() => { setShowSelfEdit(true); setMobileMenuOpen(false); }}
                  onWorkflowCreator={() => { setShowWorkflow(true); setMobileMenuOpen(false); }}
                />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* File Explorer - Shows when in code or split view */}
        {(viewMode === "code" || viewMode === "split") && showFileExplorer && (
          <div className="w-64 hidden md:block">
            <FileExplorer
              onFileSelect={handleFileSelect}
              onCreateFile={handleCreateFile}
              onCreateFolder={handleCreateFolder}
              onDelete={handleDeleteFile}
            />
          </div>
        )}
        
        {/* Browser & Code Editor */}
        <div className="flex-1 flex flex-col">
          <BrowserToolbar 
            currentUrl={currentUrl} 
            onNavigate={handleNavigate}
            onDevMode={() => setIsDevMode(!isDevMode)}
            isDevMode={isDevMode}
            onDashboard={() => setShowDashboard(true)}
            onAddToHome={handleAddToHome}
            tabs={tabs}
            activeTabId={activeTabId}
            onTabChange={setActiveTabId}
            onNewTab={addNewTab}
            onCloseTab={closeTab}
          />
          <div className="flex items-center gap-2 px-4 py-2 border-b bg-card">
            <ViewModeToggle mode={viewMode} onChange={setViewMode} />
            {(viewMode === "code" || viewMode === "split") && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowFileExplorer(!showFileExplorer)}
                data-testid="button-toggle-explorer"
                className="ml-auto hidden md:flex"
              >
                {showFileExplorer ? "Hide" : "Show"} Files
              </Button>
            )}
          </div>
          <div className="flex-1 overflow-hidden">
            {viewMode === "browser" && (
              <BrowserView 
                url={currentUrl} 
                onCodeDetected={handleCodeDetected}
                htmlCode={activeTab.language === 'html' ? activeTab.code : undefined}
              />
            )}
            {viewMode === "code" && (
              <CodeEditor
                onDeploy={() => setShowDeploy(true)}
                onExport={handleExport}
                onAIAssist={() => setShowAI(true)}
                code={activeTab.code}
                language={activeTab.language}
                onCodeChange={updateActiveTabCode}
                onLanguageChange={updateActiveTabLanguage}
              />
            )}
            {viewMode === "split" && (
              <div className="flex h-full">
                <div className="flex-1 border-r">
                  <BrowserView 
                    url={currentUrl} 
                    onCodeDetected={handleCodeDetected}
                    htmlCode={activeTab.language === 'html' ? activeTab.code : undefined}
                  />
                </div>
                <div className="flex-1">
                  <CodeEditor
                    onDeploy={() => setShowDeploy(true)}
                    onExport={handleExport}
                    onAIAssist={() => setShowAI(true)}
                    code={activeTab.code}
                    language={activeTab.language}
                    onCodeChange={updateActiveTabCode}
                    onLanguageChange={updateActiveTabLanguage}
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Developer Panel - Desktop Only */}
        {isDevMode && (
          <div className="hidden lg:block w-80">
            <DeveloperPanel
              onDeploy={() => setShowDeploy(true)}
              onTemplates={() => setShowTemplates(true)}
              onAgentCreator={() => setShowAgentCreator(true)}
              onAPKBuilder={() => setShowAPKBuilder(true)}
              onSettings={() => setShowSettings(true)}
              onPlainEnglish={() => setShowPlainEnglish(true)}
              onExport={handleExport}
              onSelfEdit={() => setShowSelfEdit(true)}
              onWorkflowCreator={() => setShowWorkflow(true)}
            />
          </div>
        )}
      </div>

      {/* Modals & Panels */}
      <SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} />
      <DeployModal isOpen={showDeploy} onClose={() => setShowDeploy(false)} />
      <AIAssistPanel isOpen={showAI} onClose={() => setShowAI(false)} />
      <TemplateLibrary
        isOpen={showTemplates}
        onClose={() => setShowTemplates(false)}
        onSelectTemplate={handleSelectTemplate}
      />
      <AgentCreator isOpen={showAgentCreator} onClose={() => setShowAgentCreator(false)} />
      <APKBuilder isOpen={showAPKBuilder} onClose={() => setShowAPKBuilder(false)} />
      
      {/* Plain English Builder Modal */}
      {showPlainEnglish && (
        <>
          <div
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
            onClick={() => setShowPlainEnglish(false)}
            data-testid="plain-english-backdrop"
          />
          <div className="fixed inset-x-4 sm:left-1/2 sm:-translate-x-1/2 top-4 sm:top-1/2 sm:-translate-y-1/2 w-auto sm:w-full sm:max-w-2xl h-[calc(100vh-2rem)] sm:h-[85vh] bg-card border rounded-lg z-50 overflow-hidden">
            <PlainEnglishBuilder 
              onGenerateCode={handleGenerateCode}
              onClose={() => setShowPlainEnglish(false)}
            />
          </div>
        </>
      )}

      {/* Dashboard Modal */}
      {showDashboard && (
        <>
          <div
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
            onClick={() => setShowDashboard(false)}
            data-testid="dashboard-backdrop"
          />
          <div className="fixed inset-4 sm:inset-8 bg-card border rounded-lg z-50 overflow-hidden">
            <Dashboard
              onPlainEnglish={() => { setShowPlainEnglish(true); setShowDashboard(false); }}
              onTemplates={() => { setShowTemplates(true); setShowDashboard(false); }}
              onAgentCreator={() => { setShowAgentCreator(true); setShowDashboard(false); }}
              onDeploy={() => { setShowDeploy(true); setShowDashboard(false); }}
              onAPKBuilder={() => { setShowAPKBuilder(true); setShowDashboard(false); }}
            />
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4"
              onClick={() => setShowDashboard(false)}
              data-testid="button-close-dashboard"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </>
      )}

      {/* Self-Editing Tool */}
      <SelfEditingTool isOpen={showSelfEdit} onClose={() => setShowSelfEdit(false)} />

      {/* Workflow Creator */}
      <WorkflowCreator isOpen={showWorkflow} onClose={() => setShowWorkflow(false)} />
    </div>
  );
}

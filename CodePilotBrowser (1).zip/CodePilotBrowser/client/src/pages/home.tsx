import { useState } from "react";
import { 
  Home as HomeIcon, Search, RefreshCw, Lock, Star, Settings, X, ChevronLeft, 
  ChevronRight, Plus, Code, Zap, FileText, Wrench, Palette, Download, 
  Package, Terminal, GitBranch, Play, Globe, Layers, Share2, MoreVertical,
  Sparkles
} from 'lucide-react';
import { CodeEditor } from "@/components/CodeEditor";
import { BrowserView } from "@/components/BrowserView";
import { TemplateLibrary } from "@/components/TemplateLibrary";
import { PlainEnglishBuilder } from "@/components/PlainEnglishBuilder";
import { SelfEditingTool } from "@/components/SelfEditingTool";
import { WorkflowCreator } from "@/components/WorkflowCreator";
import { AgentCreator } from "@/components/AgentCreator";
import { DeployModal } from "@/components/DeployModal";
import { SettingsPanel } from "@/components/SettingsPanel";
import { APKBuilder } from "@/components/APKBuilder";
import { FileExplorer } from "@/components/FileExplorer";
import { AIAssistPanel } from "@/components/AIAssistPanel";
import { useToast } from "@/hooks/use-toast";
import { getTemplateCode } from "@/lib/templates";

const themes = {
  cosmic: {
    name: 'Cosmic',
    bg: 'bg-slate-900',
    secondary: 'bg-slate-800',
    tertiary: 'bg-slate-700',
    accent: 'bg-purple-600',
    text: 'text-slate-100',
    textSec: 'text-slate-400',
    border: 'border-slate-700'
  },
  forest: {
    name: 'Forest',
    bg: 'bg-emerald-950',
    secondary: 'bg-emerald-900',
    tertiary: 'bg-emerald-800',
    accent: 'bg-emerald-600',
    text: 'text-emerald-50',
    textSec: 'text-emerald-400',
    border: 'border-emerald-800'
  },
  ocean: {
    name: 'Ocean',
    bg: 'bg-cyan-950',
    secondary: 'bg-cyan-900',
    tertiary: 'bg-cyan-800',
    accent: 'bg-cyan-500',
    text: 'text-cyan-50',
    textSec: 'text-cyan-300',
    border: 'border-cyan-700'
  },
  sunset: {
    name: 'Sunset',
    bg: 'bg-orange-950',
    secondary: 'bg-orange-900',
    tertiary: 'bg-orange-800',
    accent: 'bg-orange-500',
    text: 'text-orange-50',
    textSec: 'text-orange-300',
    border: 'border-orange-700'
  },
  midnight: {
    name: 'Midnight',
    bg: 'bg-indigo-950',
    secondary: 'bg-indigo-900',
    tertiary: 'bg-indigo-800',
    accent: 'bg-pink-500',
    text: 'text-indigo-50',
    textSec: 'text-indigo-300',
    border: 'border-indigo-700'
  }
};

export default function Home() {
  const [url, setUrl] = useState('https://www.example.com');
  const [showDevMenu, setShowDevMenu] = useState(false);
  const [showBrowserMenu, setShowBrowserMenu] = useState(false);
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [activeView, setActiveView] = useState('browser');
  const [theme, setTheme] = useState('cosmic');
  const [devMode, setDevMode] = useState(false);
  const [tabs, setTabs] = useState([
    { id: '1', name: 'Untitled', code: "// Start coding here...\n", language: 'javascript' }
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [showSettings, setShowSettings] = useState(false);
  const [showDeploy, setShowDeploy] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showPlainEnglish, setShowPlainEnglish] = useState(false);
  const [showSelfEdit, setShowSelfEdit] = useState(false);
  const [showWorkflow, setShowWorkflow] = useState(false);
  const [showAgentCreator, setShowAgentCreator] = useState(false);
  const [showAPKBuilder, setShowAPKBuilder] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [showFileExplorer, setShowFileExplorer] = useState(true);
  const { toast } = useToast();

  const t = themes[theme as keyof typeof themes];
  const activeTab = tabs.find(tab => tab.id === activeTabId) || tabs[0];

  const updateActiveTabCode = (code: string) => {
    setTabs(tabs.map(t => t.id === activeTabId ? { ...t, code } : t));
  };

  const updateActiveTabLanguage = (language: string) => {
    setTabs(tabs.map(t => t.id === activeTabId ? { ...t, language } : t));
  };

  const addTab = () => {
    const newId = Date.now().toString();
    setTabs([...tabs, {
      id: newId,
      name: `Untitled ${tabs.length + 1}`,
      code: "// New file\n",
      language: 'javascript'
    }]);
    setActiveTabId(newId);
  };

  const closeTab = (id: string) => {
    if (tabs.length === 1) return;
    const newTabs = tabs.filter(tab => tab.id !== id);
    setTabs(newTabs);
    if (activeTabId === id && newTabs.length > 0) {
      setActiveTabId(newTabs[0].id);
    }
  };

  const handleSelectTemplate = (template: any) => {
    const templateCode = getTemplateCode(template.id);
    if (templateCode) {
      setTabs(tabs.map(t => t.id === activeTabId ? {
        ...t,
        name: template.name,
        code: templateCode.code,
        language: templateCode.language
      } : t));
      setShowTemplates(false);
      setActiveView('source');
      toast({
        title: `✨ ${template.name} Loaded!`,
        description: `Template code is ready in the editor.`,
      });
    }
  };

  const handleFileSelect = (file: any) => {
    const existingTab = tabs.find(t => t.name === file.name);
    if (existingTab) {
      setActiveTabId(existingTab.id);
    } else {
      const newId = Date.now().toString();
      setTabs([...tabs, {
        id: newId,
        name: file.name,
        code: file.content || "// New file\n",
        language: file.language || 'javascript'
      }]);
      setActiveTabId(newId);
    }
  };

  const handleCreateFile = () => {
    addTab();
  };

  return (
    <div className={`h-screen flex flex-col ${t.bg} ${t.text}`}>
      {/* Top Browser Bar */}
      <div className={`${t.secondary} border-b ${t.border} px-3 py-2 flex items-center gap-3`}>
        <div className="flex items-center gap-2">
          <HomeIcon className="w-5 h-5" />
          <span className="text-xs font-bold">YOU-N-I-VERSE</span>
        </div>
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className={`flex-1 ${t.tertiary} rounded px-3 py-1.5 text-sm outline-none ${t.text}`}
          placeholder="Search or enter URL"
        />
        <div className="flex items-center gap-2">
          <button onClick={addTab} className={`p-1.5 rounded hover:${t.tertiary}`}>
            <Plus className="w-5 h-5" />
          </button>
          <button onClick={() => setShowBrowserMenu(!showBrowserMenu)} className={`p-1.5 rounded hover:${t.tertiary} relative`}>
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Browser Menu Dropdown */}
      {showBrowserMenu && (
        <div className={`absolute top-14 right-3 ${t.secondary} border ${t.border} rounded-lg shadow-xl w-64 z-50`}>
          <button onClick={() => { addTab(); setShowBrowserMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Plus className="w-5 h-5" />
            <span>New tab</span>
          </button>
          <button className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Globe className="w-5 h-5" />
            <span>New Incognito tab</span>
          </button>
          <button className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Star className="w-5 h-5" />
            <span>Bookmarks</span>
          </button>
          <button className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Download className="w-5 h-5" />
            <span>Downloads</span>
          </button>
          <button className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Share2 className="w-5 h-5" />
            <span>Share...</span>
          </button>
          <button className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <HomeIcon className="w-5 h-5" />
            <span>Add to Home screen</span>
          </button>
          <button onClick={() => { setShowThemePicker(!showThemePicker); setShowBrowserMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Palette className="w-5 h-5" />
            <span>Theme</span>
          </button>
          <button onClick={() => { setDevMode(!devMode); setShowBrowserMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border} ${devMode ? t.accent + ' text-white' : ''}`}>
            <Wrench className="w-5 h-5" />
            <span>Developer Mode</span>
          </button>
          <button onClick={() => { setShowSettings(true); setShowBrowserMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left`}>
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </button>
        </div>
      )}

      {/* Theme Picker Dropdown */}
      {showThemePicker && (
        <div className={`absolute top-14 right-3 ${t.secondary} border ${t.border} rounded-lg shadow-xl w-64 z-50`}>
          <div className={`px-4 py-3 border-b ${t.border} flex items-center justify-between`}>
            <h3 className="font-semibold">Choose Theme</h3>
            <button onClick={() => setShowThemePicker(false)}>
              <X className="w-5 h-5" />
            </button>
          </div>
          {Object.keys(themes).map(key => (
            <button
              key={key}
              onClick={() => { setTheme(key); setShowThemePicker(false); }}
              className={`w-full px-4 py-3 flex items-center justify-between hover:${t.tertiary} text-left border-b ${t.border} ${theme === key ? t.accent + ' text-white' : ''}`}
            >
              <span>{themes[key as keyof typeof themes].name}</span>
              {theme === key && <span>✓</span>}
            </button>
          ))}
        </div>
      )}

      {/* Dev Tools Menu */}
      {showDevMenu && devMode && (
        <div className={`absolute top-14 right-3 ${t.secondary} border ${t.border} rounded-lg shadow-xl w-72 z-50`}>
          <div className={`px-4 py-3 border-b ${t.border} flex items-center justify-between`}>
            <h3 className="font-semibold">Developer Tools</h3>
            <button onClick={() => setShowDevMenu(false)}>
              <X className="w-5 h-5" />
            </button>
          </div>
          <button onClick={() => { setShowPlainEnglish(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Zap className="w-5 h-5" />
            <span>AI Builder</span>
          </button>
          <button onClick={() => { setShowTemplates(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <FileText className="w-5 h-5" />
            <span>Templates</span>
          </button>
          <button onClick={() => { setShowSelfEdit(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Code className="w-5 h-5" />
            <span>Edit Source Code</span>
          </button>
          <button onClick={() => { setShowWorkflow(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <GitBranch className="w-5 h-5" />
            <span>Workflow Creator</span>
          </button>
          <button onClick={() => { setShowDeploy(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Play className="w-5 h-5" />
            <span>Deploy to GitHub</span>
          </button>
          <button onClick={() => { setShowAPKBuilder(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Package className="w-5 h-5" />
            <span>Build APK</span>
          </button>
          <button onClick={() => { setShowAgentCreator(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left border-b ${t.border}`}>
            <Terminal className="w-5 h-5" />
            <span>Agent Creator</span>
          </button>
          <button onClick={() => { setShowSettings(true); setShowDevMenu(false); }} className={`w-full px-4 py-3 flex items-center gap-3 hover:${t.tertiary} text-left`}>
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </button>
        </div>
      )}

      {/* Tabs Bar */}
      <div className={`${t.secondary} border-b ${t.border} flex items-center gap-1 px-2 overflow-x-auto scrollbar-hide`}>
        {tabs.map(tab => (
          <div
            key={tab.id}
            className={`flex items-center gap-2 px-3 py-2 rounded-t cursor-pointer group ${
              activeTabId === tab.id ? t.tertiary : 'opacity-60'
            }`}
            onClick={() => setActiveTabId(tab.id)}
          >
            <span className="text-sm whitespace-nowrap max-w-32 truncate">{tab.name}</span>
            <X
              className="w-3 h-3 opacity-0 group-hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                closeTab(tab.id);
              }}
            />
          </div>
        ))}
        <button onClick={addTab} className={`p-2 rounded hover:${t.tertiary}`}>
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation Bar */}
      <div className={`${t.secondary} border-b ${t.border} px-3 py-2 flex items-center gap-3`}>
        <div className="flex items-center gap-2">
          <button className={`p-1.5 rounded hover:${t.tertiary}`}>
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button className={`p-1.5 rounded hover:${t.tertiary}`}>
            <ChevronRight className="w-4 h-4" />
          </button>
          <button className={`p-1.5 rounded hover:${t.tertiary}`}>
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <div className={`flex-1 flex items-center gap-2 ${t.tertiary} rounded px-3 py-1.5`}>
          <Lock className="w-4 h-4 text-emerald-500" />
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className={`flex-1 bg-transparent outline-none ${t.text} text-sm`}
          />
          <Search className={`w-4 h-4 ${t.textSec}`} />
        </div>

        <div className="flex items-center gap-2">
          <button className={`p-1.5 rounded hover:${t.tertiary}`}>
            <Star className="w-4 h-4" />
          </button>
          <button onClick={() => setShowThemePicker(!showThemePicker)} className={`p-1.5 rounded hover:${t.tertiary}`}>
            <Palette className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* View Switcher */}
      {devMode && (
        <div className={`${t.secondary} border-b ${t.border} px-3 py-2 flex items-center gap-2 overflow-x-auto`}>
          <button
            onClick={() => setActiveView('browser')}
            className={`px-3 py-1.5 rounded text-sm flex items-center gap-2 whitespace-nowrap ${
              activeView === 'browser' ? `${t.accent} text-white` : t.tertiary
            }`}
          >
            <Globe className="w-4 h-4" />
            Browser
          </button>
          <button
            onClick={() => setActiveView('source')}
            className={`px-3 py-1.5 rounded text-sm flex items-center gap-2 whitespace-nowrap ${
              activeView === 'source' ? `${t.accent} text-white` : t.tertiary
            }`}
          >
            <Code className="w-4 h-4" />
            Code
          </button>
          <button
            onClick={() => setShowFileExplorer(!showFileExplorer)}
            className={`px-3 py-1.5 rounded text-sm flex items-center gap-2 whitespace-nowrap ${t.tertiary}`}
          >
            <Layers className="w-4 h-4" />
            {showFileExplorer ? 'Hide' : 'Show'} Files
          </button>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex">
        {/* File Explorer */}
        {activeView === 'source' && showFileExplorer && devMode && (
          <div className={`w-64 ${t.secondary} border-r ${t.border}`}>
            <FileExplorer
              onFileSelect={handleFileSelect}
              onCreateFile={handleCreateFile}
              onCreateFolder={() => {}}
              onDelete={() => {}}
            />
          </div>
        )}

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          {activeView === 'browser' && (
            <BrowserView 
              url={url} 
              onCodeDetected={() => {}}
              htmlCode={activeTab.language === 'html' ? activeTab.code : undefined}
            />
          )}

          {activeView === 'source' && devMode && (
            <div className="h-full">
              <CodeEditor
                onDeploy={() => setShowDeploy(true)}
                onExport={() => {}}
                onAIAssist={() => setShowAI(true)}
                code={activeTab.code}
                language={activeTab.language}
                onCodeChange={updateActiveTabCode}
                onLanguageChange={updateActiveTabLanguage}
              />
            </div>
          )}
        </div>
      </div>

      {/* Bottom Toolbar */}
      {devMode && (
        <div className={`${t.secondary} border-t ${t.border} px-4 py-2 flex items-center justify-between`}>
          <div className="flex items-center gap-4 text-sm">
            <button onClick={() => setShowDevMenu(true)} className={`flex items-center gap-2 ${t.textSec} hover:${t.text}`}>
              <Package className="w-4 h-4" />
              DevTools
            </button>
            <div className={t.textSec}>Ready</div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowSettings(true)} className={`p-1.5 rounded hover:${t.tertiary}`}>
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      <SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} />
      <DeployModal isOpen={showDeploy} onClose={() => setShowDeploy(false)} />
      {showTemplates && <TemplateLibrary isOpen={showTemplates} onClose={() => setShowTemplates(false)} onSelectTemplate={handleSelectTemplate} />}
      {showPlainEnglish && <PlainEnglishBuilder onClose={() => setShowPlainEnglish(false)} onGenerateCode={() => {}} />}
      <SelfEditingTool isOpen={showSelfEdit} onClose={() => setShowSelfEdit(false)} />
      <WorkflowCreator isOpen={showWorkflow} onClose={() => setShowWorkflow(false)} />
      <AgentCreator isOpen={showAgentCreator} onClose={() => setShowAgentCreator(false)} />
      <APKBuilder isOpen={showAPKBuilder} onClose={() => setShowAPKBuilder(false)} />
      <AIAssistPanel isOpen={showAI} onClose={() => setShowAI(false)} />
    </div>
  );
}

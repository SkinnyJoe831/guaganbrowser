import { useState, useEffect } from "react";
import { AlertCircle, Code } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BrowserViewProps {
  url: string;
  onCodeDetected: (code: string) => void;
  htmlCode?: string;
}

export function BrowserView({ url, onCodeDetected, htmlCode }: BrowserViewProps) {
  const [hasCodeSnippets, setHasCodeSnippets] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // If we have HTML code to render, use that instead of the URL
  const isPreviewMode = !!htmlCode;

  useEffect(() => {
    if (isPreviewMode) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
      // Simulate code detection
      const randomDetection = Math.random() > 0.5;
      setHasCodeSnippets(randomDetection);
    }, 1000);

    return () => clearTimeout(timer);
  }, [url, isPreviewMode]);

  const handleExtractCode = () => {
    const sampleCode = `// Extracted code snippet
function example() {
  console.log("Code detected on the page");
  return true;
}`;
    onCodeDetected(sampleCode);
    setHasCodeSnippets(false);
  };

  return (
    <div className="relative h-full w-full bg-background" data-testid="browser-view">
      {isLoading ? (
        <div className="flex items-center justify-center h-full">
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span>Loading...</span>
          </div>
        </div>
      ) : (
        <>
          {isPreviewMode ? (
            <iframe
              srcDoc={htmlCode}
              className="w-full h-full border-0 bg-white"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
              title="Code Preview"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          ) : (
            <iframe
              src={url}
              className="w-full h-full border-0"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
              referrerPolicy="no-referrer"
              title="Browser View"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          )}
          
          {hasCodeSnippets && !isPreviewMode && (
            <div className="absolute top-4 right-4 animate-in fade-in slide-in-from-top-2">
              <Button
                variant="default"
                size="sm"
                onClick={handleExtractCode}
                className="shadow-lg"
                data-testid="button-extract-code"
              >
                <Code className="h-4 w-4 mr-2" />
                Code Detected - Extract
              </Button>
            </div>
          )}
        </>
      )}
      
      {!isLoading && !url && (
        <div className="flex items-center justify-center h-full">
          <div className="text-center space-y-2">
            <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto" />
            <p className="text-muted-foreground">Enter a URL to browse</p>
          </div>
        </div>
      )}
    </div>
  );
}

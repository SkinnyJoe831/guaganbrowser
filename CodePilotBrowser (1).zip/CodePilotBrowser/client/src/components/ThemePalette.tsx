import { useState, useEffect } from "react";
import { Palette } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

const palettes = [
  { 
    name: "Paisley", 
    primary: "330 81% 60%", // Pink
    ring: "330 81% 60%",
    chart1: "330 81% 60%",
    chart2: "340 75% 55%",
    chart3: "320 70% 65%",
    chart4: "310 65% 70%",
  },
  { 
    name: "Venom", 
    primary: "142 76% 36%", // Dark green
    ring: "142 76% 36%",
    chart1: "142 76% 36%",
    chart2: "152 71% 45%",
    chart3: "160 84% 39%",
    chart4: "135 80% 42%",
  },
  { 
    name: "Marina", 
    primary: "180 65% 55%", // Aquamarine
    ring: "180 65% 55%",
    chart1: "180 65% 55%",
    chart2: "185 72% 56%",
    chart3: "175 77% 47%",
    chart4: "190 68% 60%",
  },
  { 
    name: "Cosmic", 
    primary: "265 89% 65%", // Purple/violet
    ring: "265 89% 65%",
    chart1: "265 89% 65%",
    chart2: "275 85% 70%",
    chart3: "255 95% 60%",
    chart4: "285 80% 68%",
  },
  { 
    name: "Echo", 
    primary: "200 82% 55%", // Bright blue
    ring: "200 82% 55%",
    chart1: "200 82% 55%",
    chart2: "210 90% 60%",
    chart3: "190 85% 65%",
    chart4: "215 78% 58%",
  },
  { 
    name: "Dream", 
    primary: "290 70% 65%", // Lavender/purple
    ring: "290 70% 65%",
    chart1: "290 70% 65%",
    chart2: "280 75% 70%",
    chart3: "300 65% 68%",
    chart4: "270 72% 63%",
  },
];

export function ThemePalette() {
  const [currentPalette, setCurrentPalette] = useState("Paisley");
  const { toast } = useToast();

  useEffect(() => {
    const saved = localStorage.getItem("color-palette");
    if (saved) {
      setCurrentPalette(saved);
      applyPalette(saved);
    }
  }, []);

  const applyPalette = (paletteName: string) => {
    const palette = palettes.find(p => p.name === paletteName);
    if (palette) {
      const root = document.documentElement;
      root.style.setProperty("--primary", palette.primary);
      root.style.setProperty("--ring", palette.ring);
      root.style.setProperty("--sidebar-primary", palette.primary);
      root.style.setProperty("--sidebar-ring", palette.ring);
      root.style.setProperty("--chart-1", palette.chart1);
      root.style.setProperty("--chart-2", palette.chart2);
      root.style.setProperty("--chart-3", palette.chart3);
      root.style.setProperty("--chart-4", palette.chart4);
    }
  };

  const handlePaletteChange = (paletteName: string) => {
    setCurrentPalette(paletteName);
    applyPalette(paletteName);
    localStorage.setItem("color-palette", paletteName);
    
    toast({
      title: `${paletteName} Theme Applied! 🎨`,
      description: "Your app colors have been updated",
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" data-testid="button-palette-toggle" title="Color Palette">
          <Palette className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        {palettes.map((palette) => (
          <DropdownMenuItem
            key={palette.name}
            onClick={() => handlePaletteChange(palette.name)}
            data-testid={`palette-${palette.name.toLowerCase()}`}
          >
            <div className="flex items-center gap-2 w-full">
              <div
                className="h-4 w-4 rounded-full flex-shrink-0"
                style={{ backgroundColor: `hsl(${palette.primary})` }}
              />
              <span className={currentPalette === palette.name ? "font-semibold" : ""}>
                {palette.name}
              </span>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

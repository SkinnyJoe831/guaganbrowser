import { useRef, useState } from "react";
import Editor from "@monaco-editor/react";
import { Button } from "@/components/ui/button";
import { Upload, Clipboard, Sparkles, Rocket, Download, ChevronDown } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface CodeEditorProps {
  onDeploy: () => void;
  onExport: () => void;
  onAIAssist: () => void;
  code?: string;
  language?: string;
  onCodeChange?: (code: string) => void;
  onLanguageChange?: (language: string) => void;
}

export function CodeEditor({ 
  onDeploy, 
  onExport, 
  onAIAssist,
  code: externalCode,
  language: externalLanguage,
  onCodeChange,
  onLanguageChange
}: CodeEditorProps) {
  const { theme } = useTheme();
  const [internalCode, setInternalCode] = useState("// Start coding here...\n");
  const [internalLanguage, setInternalLanguage] = useState("javascript");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const code = externalCode !== undefined ? externalCode : internalCode;
  const language = externalLanguage !== undefined ? externalLanguage : internalLanguage;

  const handleCodeChange = (value: string | undefined) => {
    const newCode = value || "";
    if (onCodeChange) {
      onCodeChange(newCode);
    } else {
      setInternalCode(newCode);
    }
  };

  const handleLanguageChange = (newLanguage: string) => {
    if (onLanguageChange) {
      onLanguageChange(newLanguage);
    } else {
      setInternalLanguage(newLanguage);
    }
  };

  const handleUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        handleCodeChange(content);
        
        const ext = file.name.split('.').pop()?.toLowerCase();
        const langMap: Record<string, string> = {
          'js': 'javascript',
          'ts': 'typescript',
          'tsx': 'typescript',
          'jsx': 'javascript',
          'py': 'python',
          'java': 'java',
          'cpp': 'cpp',
          'c': 'c',
          'html': 'html',
          'css': 'css',
          'json': 'json',
        };
        if (ext && langMap[ext]) {
          handleLanguageChange(langMap[ext]);
        }
      };
      reader.readAsText(file);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      handleCodeChange(text);
    } catch (err) {
      console.error('Failed to read clipboard:', err);
    }
  };

  const handleFormat = () => {
    console.log('Format code triggered');
  };

  return (
    <div className="relative flex flex-col h-full bg-card">
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleFileChange}
        accept=".js,.ts,.tsx,.jsx,.py,.java,.cpp,.c,.html,.css,.json,.txt"
      />
      
      <div className="flex items-center justify-between gap-2 p-3 border-b overflow-x-auto">
        <div className="flex items-center gap-2 flex-shrink-0">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleUpload}
            data-testid="button-upload"
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handlePaste}
            data-testid="button-paste"
          >
            <Clipboard className="h-4 w-4 mr-2" />
            Paste
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleFormat}
            data-testid="button-format"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Format
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" data-testid="button-language">
                {language}
                <ChevronDown className="h-4 w-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => handleLanguageChange('javascript')}>JavaScript</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange('typescript')}>TypeScript</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange('python')}>Python</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange('html')}>HTML</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange('css')}>CSS</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange('json')}>JSON</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="flex items-center gap-2 flex-shrink-0">
          <Button
            variant="ghost"
            size="sm"
            onClick={onExport}
            data-testid="button-export"
          >
            <Download className="h-4 w-4 sm:mr-2" />
            <span className="hidden sm:inline">Export</span>
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={onDeploy}
            data-testid="button-deploy"
          >
            <Rocket className="h-4 w-4 sm:mr-2" />
            <span className="hidden sm:inline">Deploy</span>
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        <Editor
          height="100%"
          language={language}
          value={code}
          onChange={handleCodeChange}
          theme={theme === "dark" ? "vs-dark" : "light"}
          options={{
            minimap: { enabled: false },
            fontSize: 13,
            lineNumbers: "on",
            scrollBeyondLastLine: false,
            automaticLayout: true,
          }}
        />
      </div>
      
      <Button
        variant="ghost"
        size="icon"
        className="absolute bottom-4 right-4 h-12 w-12 rounded-full bg-chart-3 hover:bg-chart-3 text-white shadow-lg z-10"
        onClick={onAIAssist}
        data-testid="button-ai-assist"
      >
        <Sparkles className="h-5 w-5" />
      </Button>
    </div>
  );
}

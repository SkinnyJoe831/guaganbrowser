import { useState } from "react";
import { 
  ArrowLeft, 
  ArrowRight, 
  RotateCw, 
  Home, 
  Lock,
  Star,
  Plus,
  X,
  Code2,
  LayoutDashboard
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ThemePalette } from "@/components/ThemePalette";
import { useToast } from "@/hooks/use-toast";

interface Tab {
  id: string;
  name: string;
  code: string;
  language: string;
}

interface BrowserToolbarProps {
  currentUrl: string;
  onNavigate: (url: string) => void;
  onDevMode: () => void;
  isDevMode: boolean;
  onDashboard?: () => void;
  onAddToHome?: () => void;
  tabs?: Tab[];
  activeTabId?: string;
  onTabChange?: (id: string) => void;
  onNewTab?: () => void;
  onCloseTab?: (id: string) => void;
}

export function BrowserToolbar({ 
  currentUrl, 
  onNavigate, 
  onDevMode, 
  isDevMode, 
  onDashboard, 
  onAddToHome,
  tabs = [],
  activeTabId,
  onTabChange,
  onNewTab,
  onCloseTab
}: BrowserToolbarProps) {
  const [urlInput, setUrlInput] = useState(currentUrl);
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let formattedUrl = urlInput.trim();
    
    // If it doesn't start with http:// or https://, add https://
    if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
      formattedUrl = 'https://' + formattedUrl;
    }
    
    setUrlInput(formattedUrl);
    onNavigate(formattedUrl);
    
    toast({
      title: "Navigating...",
      description: `Loading ${formattedUrl}`,
    });
  };

  const handleRefresh = () => {
    onNavigate(currentUrl);
  };

  const handleHome = () => {
    const homeUrl = "https://www.example.com";
    setUrlInput(homeUrl);
    onNavigate(homeUrl);
  };

  return (
    <div className="border-b bg-card">
      {/* Tab Bar */}
      {tabs.length > 0 && (
        <div className="flex items-center gap-1 px-2 pt-2 border-b overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <div 
              key={tab.id}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-t-md border border-b-0 cursor-pointer transition-colors ${
                tab.id === activeTabId ? 'bg-background' : 'bg-muted/50 hover:bg-muted'
              }`}
              onClick={() => onTabChange?.(tab.id)}
              data-testid={`tab-${tab.id}`}
            >
              <span className="text-xs font-medium max-w-[100px] truncate">{tab.name}</span>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-4 w-4 p-0 hover:bg-muted"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTab?.(tab.id);
                }}
                data-testid={`button-close-tab-${tab.id}`}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7"
            onClick={onNewTab}
            data-testid="button-new-tab"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Navigation Bar */}
      <div className="flex items-center gap-2 p-2">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            disabled={!canGoBack}
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            disabled={!canGoForward}
            data-testid="button-forward"
          >
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleRefresh}
            data-testid="button-refresh"
          >
            <RotateCw className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleHome}
            data-testid="button-home"
          >
            <Home className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-1.5 bg-muted/50 rounded-md border">
            <Lock className="h-4 w-4 text-muted-foreground" />
            <Input
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              className="flex-1 border-0 bg-transparent p-0 h-auto focus-visible:ring-0 focus-visible:ring-offset-0"
              placeholder="Search or enter website"
              data-testid="input-url"
            />
          </div>
        </form>

        <div className="flex items-center gap-1">
          {onDashboard && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={onDashboard}
              data-testid="button-dashboard"
              title="Dashboard"
            >
              <LayoutDashboard className="h-4 w-4" />
            </Button>
          )}
          {onAddToHome && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 hidden sm:flex"
              onClick={onAddToHome}
              data-testid="button-add-to-home"
              title="Add to Home Screen"
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            data-testid="button-bookmark"
          >
            <Star className="h-4 w-4" />
          </Button>
          <div className="hidden lg:flex items-center gap-1">
            <ThemePalette />
            <ThemeToggle />
          </div>
          <Button
            variant={isDevMode ? "default" : "ghost"}
            size="icon"
            className="h-8 w-8"
            onClick={onDevMode}
            data-testid="button-dev-mode"
            title="Developer Mode"
          >
            <Code2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

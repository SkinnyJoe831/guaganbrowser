import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface DeveloperPanelProps {
  onDeploy: () => void;
  onTemplates: () => void;
  onAgentCreator: () => void;
  onAPKBuilder: () => void;
  onSettings: () => void;
  onPlainEnglish: () => void;
  onExport: () => void;
  onSelfEdit: () => void;
  onWorkflowCreator: () => void;
}

export function DeveloperPanel({
  onDeploy,
  onTemplates,
  onAgentCreator,
  onAPKBuilder,
  onSettings,
  onPlainEnglish,
  onExport,
  onSelfEdit,
  onWorkflowCreator
}: DeveloperPanelProps) {
  return (
    <div className="h-full flex flex-col bg-card border-l">
      <div className="p-4 border-b">
        <h2 className="font-semibold">Developer Tools</h2>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          <Button 
            onClick={onPlainEnglish} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-plain-english"
          >
            AI Builder
          </Button>

          <Button 
            onClick={onTemplates} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-templates"
          >
            Templates
          </Button>

          <Button 
            onClick={onSelfEdit} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-self-edit"
          >
            Edit Source Code
          </Button>

          <Button 
            onClick={onWorkflowCreator} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-workflow"
          >
            Workflow Creator
          </Button>

          <div className="h-px bg-border my-2" />

          <Button 
            onClick={onDeploy} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-web-deploy"
          >
            Deploy to Web
          </Button>

          <Button 
            onClick={onDeploy}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-github"
          >
            Push to GitHub
          </Button>

          <Button 
            onClick={onAPKBuilder}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-apk"
          >
            Build APK
          </Button>

          <div className="h-px bg-border my-2" />

          <Button 
            onClick={onAgentCreator}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-agent-creator"
          >
            Agent Creator
          </Button>

          <Button 
            onClick={onExport} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-export"
          >
            Download Project
          </Button>

          <Button 
            onClick={onSettings}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-settings"
          >
            Settings
          </Button>
        </div>
      </ScrollArea>
    </div>
  );
}

import { useState } from "react";
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  FolderOpen,
  Plus,
  FilePlus,
  FolderPlus,
  Trash2,
  MoreVertical
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  content?: string;
  language?: string;
}

interface FileExplorerProps {
  onFileSelect: (file: FileNode) => void;
  onCreateFile: (parentId?: string) => void;
  onCreateFolder: (parentId?: string) => void;
  onDelete: (id: string) => void;
}

export function FileExplorer({ 
  onFileSelect, 
  onCreateFile, 
  onCreateFolder,
  onDelete 
}: FileExplorerProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['root']));
  const [files, setFiles] = useState<FileNode[]>([
    {
      id: 'root',
      name: 'src',
      type: 'folder',
      children: [
        { 
          id: '1', 
          name: 'index.js', 
          type: 'file',
          content: '// Main entry point\nconsole.log("Hello World");',
          language: 'javascript'
        },
        { 
          id: '2', 
          name: 'styles.css', 
          type: 'file',
          content: '/* Global styles */\nbody { margin: 0; }',
          language: 'css'
        },
        {
          id: 'components',
          name: 'components',
          type: 'folder',
          children: [
            { 
              id: '3', 
              name: 'App.jsx', 
              type: 'file',
              content: '// App component\nexport default function App() {\n  return <h1>Hello!</h1>;\n}',
              language: 'javascript'
            }
          ]
        }
      ]
    }
  ]);

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderId)) {
        next.delete(folderId);
      } else {
        next.add(folderId);
      }
      return next;
    });
  };

  const renderFileTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map(node => (
      <div key={node.id}>
        <div 
          className={`flex items-center gap-1 px-2 py-1 hover-elevate active-elevate-2 cursor-pointer group ${
            depth > 0 ? 'ml-' + (depth * 4) : ''
          }`}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          {node.type === 'folder' ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 p-0"
                onClick={() => toggleFolder(node.id)}
                data-testid={`button-toggle-folder-${node.id}`}
              >
                {expandedFolders.has(node.id) ? (
                  <ChevronDown className="h-3 w-3" />
                ) : (
                  <ChevronRight className="h-3 w-3" />
                )}
              </Button>
              {expandedFolders.has(node.id) ? (
                <FolderOpen className="h-4 w-4 text-primary" />
              ) : (
                <Folder className="h-4 w-4 text-primary" />
              )}
              <span 
                className="flex-1 text-sm"
                onClick={() => toggleFolder(node.id)}
              >
                {node.name}
              </span>
            </>
          ) : (
            <>
              <div className="w-4" />
              <File className="h-4 w-4 text-muted-foreground" />
              <span 
                className="flex-1 text-sm"
                onClick={() => onFileSelect(node)}
              >
                {node.name}
              </span>
            </>
          )}
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100"
                data-testid={`button-menu-${node.id}`}
              >
                <MoreVertical className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {node.type === 'folder' && (
                <>
                  <DropdownMenuItem onClick={() => onCreateFile(node.id)}>
                    <FilePlus className="h-4 w-4 mr-2" />
                    New File
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onCreateFolder(node.id)}>
                    <FolderPlus className="h-4 w-4 mr-2" />
                    New Folder
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuItem 
                onClick={() => onDelete(node.id)}
                className="text-destructive"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {node.type === 'folder' && expandedFolders.has(node.id) && node.children && (
          renderFileTree(node.children, depth + 1)
        )}
      </div>
    ));
  };

  return (
    <div className="h-full flex flex-col bg-card border-r">
      <div className="flex items-center justify-between p-2 border-b">
        <h3 className="text-sm font-semibold">FILES</h3>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => onCreateFile()}
            data-testid="button-new-file"
          >
            <FilePlus className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => onCreateFolder()}
            data-testid="button-new-folder"
          >
            <FolderPlus className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="py-1">
          {renderFileTree(files)}
        </div>
      </ScrollArea>
    </div>
  );
}

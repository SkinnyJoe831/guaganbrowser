import { useState } from "react";
import { X, Play, Plus, Trash2, GitBranch, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface WorkflowCreatorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface WorkflowStep {
  id: string;
  type: "action" | "condition" | "loop";
  description: string;
  config: any;
}

export function WorkflowCreator({ isOpen, onClose }: WorkflowCreatorProps) {
  const { toast } = useToast();
  const [workflowName, setWorkflowName] = useState("");
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [newStepDesc, setNewStepDesc] = useState("");

  const stepTypes = [
    { type: "action", label: "Action", icon: Play, description: "Execute a task" },
    { type: "condition", label: "Condition", icon: GitBranch, description: "Branch logic" },
    { type: "loop", label: "Loop", icon: Sparkles, description: "Repeat steps" },
  ];

  const handleAddStep = (type: WorkflowStep["type"]) => {
    if (!newStepDesc.trim()) {
      toast({
        title: "Description Required",
        description: "Please enter a step description",
        variant: "destructive",
      });
      return;
    }

    const newStep: WorkflowStep = {
      id: Date.now().toString(),
      type,
      description: newStepDesc,
      config: {}
    };

    setSteps([...steps, newStep]);
    setNewStepDesc("");
    toast({
      title: "Step Added ✨",
      description: `${type} step added to workflow`,
    });
  };

  const handleRemoveStep = (id: string) => {
    setSteps(steps.filter(step => step.id !== id));
  };

  const handleSaveWorkflow = () => {
    if (!workflowName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a workflow name",
        variant: "destructive",
      });
      return;
    }

    if (steps.length === 0) {
      toast({
        title: "No Steps",
        description: "Add at least one step to your workflow",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Workflow Created! 🎉",
      description: `${workflowName} saved with ${steps.length} steps`,
    });

    console.log("Workflow saved:", { name: workflowName, steps });
    
    // Reset form
    setWorkflowName("");
    setSteps([]);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
        onClick={onClose}
        data-testid="workflow-backdrop"
      />
      <div className="fixed inset-4 sm:inset-8 bg-card border rounded-lg z-50 flex flex-col" data-testid="workflow-creator">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-gradient-to-br from-chart-3 to-chart-4 flex items-center justify-center">
              <GitBranch className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">Workflow Creator</h2>
              <p className="text-xs text-muted-foreground">Build automated workflows visually</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            data-testid="button-close-workflow"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden flex">
          {/* Main Editor */}
          <div className="flex-1 flex flex-col">
            <ScrollArea className="flex-1">
              <div className="p-6 space-y-6">
                {/* Workflow Name */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Workflow Name</label>
                  <Input
                    value={workflowName}
                    onChange={(e) => setWorkflowName(e.target.value)}
                    placeholder="e.g., Deploy to Production, Data Processing Pipeline"
                    data-testid="input-workflow-name"
                  />
                </div>

                {/* Add Step */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Add Step</label>
                  <Textarea
                    value={newStepDesc}
                    onChange={(e) => setNewStepDesc(e.target.value)}
                    placeholder="Describe what this step should do..."
                    rows={2}
                    data-testid="input-step-description"
                  />
                  <div className="flex gap-2">
                    {stepTypes.map(({ type, label, icon: Icon }) => (
                      <Button
                        key={type}
                        variant="outline"
                        onClick={() => handleAddStep(type as WorkflowStep["type"])}
                        data-testid={`button-add-${type}`}
                      >
                        <Icon className="h-4 w-4 mr-2" />
                        {label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Steps List */}
                {steps.length > 0 && (
                  <div className="space-y-3">
                    <label className="text-sm font-medium">Workflow Steps</label>
                    <div className="space-y-2">
                      {steps.map((step, index) => {
                        const StepIcon = stepTypes.find(t => t.type === step.type)?.icon || Play;
                        return (
                          <Card key={step.id} data-testid={`step-${index}`}>
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                                  <StepIcon className="h-4 w-4 text-primary" />
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Badge variant="secondary" className="text-xs">
                                      Step {index + 1}
                                    </Badge>
                                    <Badge variant="outline" className="text-xs">
                                      {step.type}
                                    </Badge>
                                  </div>
                                  <p className="text-sm">{step.description}</p>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleRemoveStep(step.id)}
                                  data-testid={`button-remove-step-${index}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Footer */}
            <div className="p-4 border-t flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {steps.length} step{steps.length !== 1 ? 's' : ''} added
              </p>
              <Button
                onClick={handleSaveWorkflow}
                data-testid="button-save-workflow"
              >
                <Play className="h-4 w-4 mr-2" />
                Save Workflow
              </Button>
            </div>
          </div>

          {/* Side Panel - Quick Guide */}
          <div className="w-80 border-l bg-muted/30 p-4 hidden lg:block">
            <h3 className="font-medium mb-3">Quick Guide</h3>
            <div className="space-y-3">
              <Card>
                <CardHeader className="p-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Play className="h-4 w-4 text-chart-1" />
                    Action Steps
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <p className="text-xs text-muted-foreground">
                    Execute tasks like API calls, database operations, or file processing
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <GitBranch className="h-4 w-4 text-chart-2" />
                    Conditions
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <p className="text-xs text-muted-foreground">
                    Create if/else logic to branch your workflow based on conditions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-chart-3" />
                    Loops
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <p className="text-xs text-muted-foreground">
                    Repeat steps multiple times or iterate over collections
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

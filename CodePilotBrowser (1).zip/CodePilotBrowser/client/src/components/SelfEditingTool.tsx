import { useState } from "react";
import { X, FileCode, Folder, Save, RefreshCw, Code2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Editor from "@monaco-editor/react";
import { useToast } from "@/hooks/use-toast";

interface SelfEditingToolProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SourceFile {
  path: string;
  name: string;
  content: string;
  language: string;
}

export function SelfEditingTool({ isOpen, onClose }: SelfEditingToolProps) {
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState<SourceFile | null>(null);
  const [editedContent, setEditedContent] = useState("");

  // Mock source files - in a real implementation, these would be fetched from the filesystem
  const sourceFiles: SourceFile[] = [
    {
      path: "client/src/pages/home.tsx",
      name: "home.tsx",
      content: `// Main application entry point
import { useState } from "react";
import { BrowserToolbar } from "@/components/BrowserToolbar";

export default function Home() {
  return (
    <div className="h-screen w-full flex flex-col">
      <h1>YOU-N-I-VERSE 🌌</h1>
    </div>
  );
}`,
      language: "typescript"
    },
    {
      path: "client/src/components/BrowserToolbar.tsx",
      name: "BrowserToolbar.tsx",
      content: `// Browser toolbar component
import { Button } from "@/components/ui/button";

export function BrowserToolbar() {
  return (
    <div className="border-b bg-card">
      {/* Toolbar content */}
    </div>
  );
}`,
      language: "typescript"
    },
    {
      path: "client/src/App.tsx",
      name: "App.tsx",
      content: `// App root component
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      {/* Router and app content */}
    </QueryClientProvider>
  );
}`,
      language: "typescript"
    },
    {
      path: "client/src/index.css",
      name: "index.css",
      content: `/* Global styles */
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
}`,
      language: "css"
    },
    {
      path: "server/routes.ts",
      name: "routes.ts",
      content: `// API routes
import { Router } from "express";

const router = Router();

router.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

export default router;`,
      language: "typescript"
    }
  ];

  const handleFileSelect = (file: SourceFile) => {
    setSelectedFile(file);
    setEditedContent(file.content);
  };

  const handleSave = () => {
    if (selectedFile) {
      toast({
        title: "Changes Saved ✨",
        description: `${selectedFile.name} has been updated. Refresh to see changes.`,
      });
      // In a real implementation, this would save to the filesystem
      console.log("Saving file:", selectedFile.path, editedContent);
    }
  };

  const handleRevert = () => {
    if (selectedFile) {
      setEditedContent(selectedFile.content);
      toast({
        title: "Changes Reverted",
        description: "File restored to original state",
      });
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
        onClick={onClose}
        data-testid="self-edit-backdrop"
      />
      <div className="fixed inset-4 sm:inset-8 bg-card border rounded-lg z-50 flex flex-col" data-testid="self-editing-tool">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
              <Code2 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">Self-Editing Tool</h2>
              <p className="text-xs text-muted-foreground">Modify the app's source code</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {selectedFile && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRevert}
                  data-testid="button-revert"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Revert
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleSave}
                  data-testid="button-save-file"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
              </>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-self-edit"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* File List */}
          <div className="w-64 border-r flex flex-col">
            <div className="p-3 border-b">
              <h3 className="text-sm font-medium flex items-center gap-2">
                <Folder className="h-4 w-4 text-primary" />
                Source Files
              </h3>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-2 space-y-1">
                {sourceFiles.map((file) => (
                  <Card
                    key={file.path}
                    className={`cursor-pointer hover-elevate ${
                      selectedFile?.path === file.path ? 'border-primary' : ''
                    }`}
                    onClick={() => handleFileSelect(file)}
                    data-testid={`file-${file.name}`}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center gap-2">
                        <FileCode className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{file.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{file.path}</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="mt-2 text-xs">
                        {file.language}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Editor */}
          <div className="flex-1 flex flex-col">
            {selectedFile ? (
              <>
                <div className="p-3 border-b bg-muted/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">{selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">{selectedFile.path}</p>
                    </div>
                    <Badge>{selectedFile.language}</Badge>
                  </div>
                </div>
                <div className="flex-1">
                  <Editor
                    height="100%"
                    language={selectedFile.language}
                    value={editedContent}
                    onChange={(value) => setEditedContent(value || "")}
                    theme="vs-dark"
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                      lineNumbers: "on",
                      scrollBeyondLastLine: false,
                      automaticLayout: true,
                      tabSize: 2,
                    }}
                  />
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <FileCode className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-sm">Select a file to edit</p>
                  <p className="text-xs mt-1">Choose from the source files on the left</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Info Banner */}
        <div className="p-3 border-t bg-muted/50">
          <p className="text-xs text-muted-foreground text-center">
            ⚠️ Changes are saved in-memory only. Refresh the page to see live updates.
          </p>
        </div>
      </div>
    </>
  );
}

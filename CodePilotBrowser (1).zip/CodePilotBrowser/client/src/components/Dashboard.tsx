import { useState } from "react";
import { 
  Sparkles, 
  FileCode, 
  Bot, 
  Rocket,
  Clock,
  Zap,
  Globe,
  Smartphone
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

interface DashboardProps {
  onPlainEnglish: () => void;
  onTemplates: () => void;
  onAgentCreator: () => void;
  onDeploy: () => void;
  onAPKBuilder: () => void;
}

export function Dashboard({
  onPlainEnglish,
  onTemplates,
  onAgentCreator,
  onDeploy,
  onAPKBuilder
}: DashboardProps) {
  const recentProjects = [
    { name: "Todo App", type: "Web App", color: "bg-chart-1" },
    { name: "Chat Bot", type: "AI Agent", color: "bg-chart-2" },
    { name: "Portfolio", type: "Website", color: "bg-chart-3" },
  ];

  const quickActions = [
    { 
      icon: Sparkles, 
      label: "Describe Idea", 
      description: "Build with AI",
      onClick: onPlainEnglish,
      testId: "dashboard-plain-english"
    },
    { 
      icon: FileCode, 
      label: "Templates", 
      description: "Start from template",
      onClick: onTemplates,
      testId: "dashboard-templates"
    },
    { 
      icon: Bot, 
      label: "Create Agent", 
      description: "AI assistant",
      onClick: onAgentCreator,
      testId: "dashboard-agent"
    },
    { 
      icon: Rocket, 
      label: "Deploy", 
      description: "Publish app",
      onClick: onDeploy,
      testId: "dashboard-deploy"
    },
    { 
      icon: Smartphone, 
      label: "Build APK", 
      description: "Android app",
      onClick: onAPKBuilder,
      testId: "dashboard-apk"
    },
  ];

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="p-6 border-b">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center">
            <span className="text-2xl">🌌</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold">YOU-N-I-VERSE</h1>
            <p className="text-sm text-muted-foreground">Cross-Platform Development Hub</p>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {/* Quick Actions */}
          <div>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Zap className="h-5 w-5 text-chart-3" />
              Quick Start
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {quickActions.map((action) => {
                const Icon = action.icon;
                return (
                  <Card 
                    key={action.label}
                    className="hover-elevate active-elevate-2 cursor-pointer transition-all"
                    onClick={action.onClick}
                    data-testid={action.testId}
                  >
                    <CardContent className="p-4 flex items-start gap-3">
                      <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">{action.label}</h3>
                        <p className="text-xs text-muted-foreground">{action.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Recent Projects */}
          <div>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Recent Projects
            </h2>
            <div className="grid gap-3">
              {recentProjects.map((project, idx) => (
                <Card key={idx} className="hover-elevate cursor-pointer">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className={`h-10 w-10 rounded-md ${project.color} flex items-center justify-center`}>
                      <Globe className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{project.name}</h3>
                      <p className="text-xs text-muted-foreground">{project.type}</p>
                    </div>
                    <Button variant="ghost" size="sm" data-testid={`project-${idx}`}>
                      Open
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Getting Started */}
          <Card className="bg-gradient-to-br from-primary/10 to-chart-2/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                Getting Started
              </CardTitle>
              <CardDescription>
                Build anything - from simple websites to complex AI-powered apps
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p>✨ Describe your idea in plain English</p>
              <p>🎨 Choose from beautiful color palettes</p>
              <p>🚀 Deploy to web, mobile, or download</p>
              <p>🤖 Create AI agents to help you build</p>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>
    </div>
  );
}

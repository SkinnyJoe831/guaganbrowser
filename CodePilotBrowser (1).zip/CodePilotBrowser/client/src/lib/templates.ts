// Template code library for different project types

export interface TemplateCode {
  id: string;
  code: string;
  language: string;
}

export const templateCodes: Record<string, TemplateCode> = {
  "game-2d": {
    id: "game-2d",
    language: "html",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>2D Platformer Game</title>
  <style>
    body { margin: 0; padding: 0; overflow: hidden; background: #1a1a2e; font-family: Arial, sans-serif; }
    canvas { display: block; margin: 0 auto; background: linear-gradient(to bottom, #87CEEB 0%, #E0F6FF 100%); }
    #ui { position: absolute; top: 20px; left: 20px; color: white; font-size: 18px; }
  </style>
</head>
<body>
  <div id="ui">Score: <span id="score">0</span> | Lives: <span id="lives">3</span></div>
  <canvas id="gameCanvas"></canvas>
  <script>
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 800;
    canvas.height = 600;

    // Game state
    let score = 0;
    let lives = 3;

    // Player
    const player = {
      x: 100, y: 450, width: 40, height: 40,
      velocityY: 0, jumping: false,
      speed: 5, jumpPower: 15
    };

    // Platforms
    const platforms = [
      { x: 0, y: 550, width: 800, height: 50 },
      { x: 200, y: 450, width: 150, height: 20 },
      { x: 400, y: 350, width: 150, height: 20 },
      { x: 600, y: 250, width: 150, height: 20 }
    ];

    // Coins
    const coins = [
      { x: 250, y: 410, collected: false },
      { x: 450, y: 310, collected: false },
      { x: 650, y: 210, collected: false }
    ];

    // Input
    const keys = {};
    document.addEventListener('keydown', (e) => keys[e.key] = true);
    document.addEventListener('keyup', (e) => keys[e.key] = false);

    // Game loop
    function update() {
      // Movement
      if (keys['ArrowLeft']) player.x -= player.speed;
      if (keys['ArrowRight']) player.x += player.speed;
      if (keys['ArrowUp'] && !player.jumping) {
        player.velocityY = -player.jumpPower;
        player.jumping = true;
      }

      // Gravity
      player.velocityY += 0.8;
      player.y += player.velocityY;

      // Platform collision
      player.jumping = true;
      platforms.forEach(platform => {
        if (player.x < platform.x + platform.width &&
            player.x + player.width > platform.x &&
            player.y + player.height > platform.y &&
            player.y + player.height < platform.y + platform.height) {
          player.y = platform.y - player.height;
          player.velocityY = 0;
          player.jumping = false;
        }
      });

      // Coin collection
      coins.forEach(coin => {
        if (!coin.collected && 
            Math.abs(player.x - coin.x) < 30 && 
            Math.abs(player.y - coin.y) < 30) {
          coin.collected = true;
          score += 10;
          document.getElementById('score').textContent = score;
        }
      });

      // Boundary check
      if (player.x < 0) player.x = 0;
      if (player.x + player.width > canvas.width) player.x = canvas.width - player.width;
      if (player.y > canvas.height) {
        lives--;
        document.getElementById('lives').textContent = lives;
        player.x = 100;
        player.y = 450;
        player.velocityY = 0;
        if (lives <= 0) alert('Game Over! Score: ' + score);
      }
    }

    function draw() {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw platforms
      ctx.fillStyle = '#2d4a2b';
      platforms.forEach(platform => {
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      });

      // Draw coins
      coins.forEach(coin => {
        if (!coin.collected) {
          ctx.fillStyle = '#FFD700';
          ctx.beginPath();
          ctx.arc(coin.x, coin.y, 10, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Draw player
      ctx.fillStyle = '#FF6347';
      ctx.fillRect(player.x, player.y, player.width, player.height);
    }

    function gameLoop() {
      update();
      draw();
      requestAnimationFrame(gameLoop);
    }

    gameLoop();
  </script>
</body>
</html>`
  },

  "game-3d": {
    id: "game-3d",
    language: "html",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>3D Adventure Game</title>
  <style>
    body { margin: 0; overflow: hidden; font-family: Arial; }
    canvas { display: block; }
    #info { position: absolute; top: 10px; left: 10px; color: white; }
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
</head>
<body>
  <div id="info">Use WASD to move, Mouse to look around</div>
  <script>
    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB);
    scene.fog = new THREE.Fog(0x87CEEB, 50, 200);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 50, 50);
    scene.add(directionalLight);

    // Ground
    const groundGeometry = new THREE.PlaneGeometry(200, 200);
    const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x3a9d23 });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    scene.add(ground);

    // Player (cube)
    const playerGeometry = new THREE.BoxGeometry(1, 2, 1);
    const playerMaterial = new THREE.MeshStandardMaterial({ color: 0xff0000 });
    const player = new THREE.Mesh(playerGeometry, playerMaterial);
    player.position.y = 1;
    scene.add(player);

    // Camera follow player
    camera.position.set(0, 5, 10);
    camera.lookAt(player.position);

    // Add some obstacles
    for (let i = 0; i < 10; i++) {
      const box = new THREE.Mesh(
        new THREE.BoxGeometry(2, 3, 2),
        new THREE.MeshStandardMaterial({ color: Math.random() * 0xffffff })
      );
      box.position.set(
        Math.random() * 50 - 25,
        1.5,
        Math.random() * 50 - 25
      );
      scene.add(box);
    }

    // Input handling
    const keys = {};
    document.addEventListener('keydown', (e) => keys[e.key.toLowerCase()] = true);
    document.addEventListener('keyup', (e) => keys[e.key.toLowerCase()] = false);

    // Animation loop
    function animate() {
      requestAnimationFrame(animate);

      // Movement
      const speed = 0.1;
      if (keys['w']) player.position.z -= speed;
      if (keys['s']) player.position.z += speed;
      if (keys['a']) player.position.x -= speed;
      if (keys['d']) player.position.x += speed;

      // Camera follows player
      camera.position.x = player.position.x;
      camera.position.z = player.position.z + 10;
      camera.position.y = player.position.y + 5;
      camera.lookAt(player.position);

      renderer.render(scene, camera);
    }

    animate();

    // Handle window resize
    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    });
  </script>
</body>
</html>`
  },

  "app-mobile": {
    id: "app-mobile",
    language: "html",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mobile App Framework</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    
    .app { max-width: 500px; margin: 0 auto; height: 100vh; display: flex; flex-direction: column; }
    .header { background: #007AFF; color: white; padding: 16px; display: flex; align-items: center; gap: 12px; }
    .content { flex: 1; overflow-y: auto; padding: 16px; background: #f5f5f5; }
    .nav { display: flex; background: white; border-top: 1px solid #ddd; }
    .nav-item { flex: 1; padding: 12px; text-align: center; cursor: pointer; transition: background 0.2s; }
    .nav-item:hover { background: #f0f0f0; }
    .nav-item.active { color: #007AFF; border-top: 2px solid #007AFF; }
    
    .card { background: white; border-radius: 12px; padding: 16px; margin-bottom: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .button { background: #007AFF; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; }
    .button:active { background: #0051D5; }
    .input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; margin: 8px 0; }
  </style>
</head>
<body>
  <div class="app">
    <div class="header">
      <h1>📱 My App</h1>
    </div>
    
    <div class="content" id="content">
      <!-- Content changes based on active tab -->
    </div>
    
    <div class="nav">
      <div class="nav-item active" onclick="switchTab('home')">🏠 Home</div>
      <div class="nav-item" onclick="switchTab('search')">🔍 Search</div>
      <div class="nav-item" onclick="switchTab('profile')">👤 Profile</div>
    </div>
  </div>

  <script>
    const views = {
      home: \`
        <div class="card">
          <h2>Welcome!</h2>
          <p>This is a mobile app framework with navigation and state management.</p>
        </div>
        <div class="card">
          <h3>Quick Actions</h3>
          <button class="button" onclick="alert('Button clicked!')">Get Started</button>
        </div>
        <div class="card">
          <h3>Recent Activity</h3>
          <p>• Task completed</p>
          <p>• New message received</p>
          <p>• Profile updated</p>
        </div>
      \`,
      search: \`
        <div class="card">
          <h2>Search</h2>
          <input class="input" type="text" placeholder="Search for anything..." onkeyup="handleSearch(this.value)">
          <div id="results"></div>
        </div>
      \`,
      profile: \`
        <div class="card">
          <h2>Profile Settings</h2>
          <input class="input" type="text" placeholder="Name" value="John Doe">
          <input class="input" type="email" placeholder="Email" value="john@example.com">
          <button class="button">Save Changes</button>
        </div>
        <div class="card">
          <h3>Preferences</h3>
          <label><input type="checkbox" checked> Enable notifications</label><br>
          <label><input type="checkbox"> Dark mode</label><br>
          <label><input type="checkbox" checked> Auto-sync</label>
        </div>
      \`
    };

    function switchTab(tab) {
      document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
      });
      event.target.classList.add('active');
      document.getElementById('content').innerHTML = views[tab];
    }

    function handleSearch(query) {
      const results = document.getElementById('results');
      if (query.length > 0) {
        results.innerHTML = \`<p>Searching for: \${query}...</p>\`;
      }
    }

    // Initialize
    document.getElementById('content').innerHTML = views.home;
  </script>
</body>
</html>`
  },

  "app-dashboard": {
    id: "app-dashboard",
    language: "html",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Analytics Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
    
    .dashboard { padding: 24px; max-width: 1400px; margin: 0 auto; }
    .header { margin-bottom: 24px; }
    .header h1 { color: #2c3e50; }
    
    .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .stat-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .stat-value { font-size: 32px; font-weight: bold; color: #2c3e50; }
    .stat-label { color: #7f8c8d; margin-top: 4px; }
    .stat-change { color: #27ae60; font-size: 14px; margin-top: 8px; }
    
    .charts { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 16px; }
    .chart-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .chart-title { font-weight: bold; margin-bottom: 16px; color: #2c3e50; }
  </style>
</head>
<body>
  <div class="dashboard">
    <div class="header">
      <h1>📊 Analytics Dashboard</h1>
      <p>Real-time metrics and insights</p>
    </div>

    <div class="stats">
      <div class="stat-card">
        <div class="stat-value">12,459</div>
        <div class="stat-label">Total Users</div>
        <div class="stat-change">↑ 12% from last month</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">$45,231</div>
        <div class="stat-label">Revenue</div>
        <div class="stat-change">↑ 8% from last month</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">892</div>
        <div class="stat-label">Active Projects</div>
        <div class="stat-change">↑ 23% from last month</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">98.5%</div>
        <div class="stat-label">Success Rate</div>
        <div class="stat-change">↑ 2% from last month</div>
      </div>
    </div>

    <div class="charts">
      <div class="chart-card">
        <div class="chart-title">User Growth</div>
        <canvas id="userChart"></canvas>
      </div>
      <div class="chart-card">
        <div class="chart-title">Revenue by Category</div>
        <canvas id="revenueChart"></canvas>
      </div>
    </div>
  </div>

  <script>
    // User Growth Chart
    const userCtx = document.getElementById('userChart').getContext('2d');
    new Chart(userCtx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Users',
          data: [8000, 9200, 10100, 10800, 11500, 12459],
          borderColor: '#3498db',
          backgroundColor: 'rgba(52, 152, 219, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } }
      }
    });

    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
      type: 'doughnut',
      data: {
        labels: ['Products', 'Services', 'Subscriptions'],
        datasets: [{
          data: [25231, 12000, 8000],
          backgroundColor: ['#3498db', '#2ecc71', '#f39c12']
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } }
      }
    });
  </script>
</body>
</html>`
  },

  "web-ecommerce": {
    id: "web-ecommerce",
    language: "html",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>E-Commerce Store</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; }
    
    header { background: #333; color: white; padding: 16px; display: flex; justify-content: space-between; align-items: center; }
    header h1 { font-size: 24px; }
    .cart-icon { cursor: pointer; position: relative; }
    .cart-count { position: absolute; top: -8px; right: -8px; background: #e74c3c; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 12px; }
    
    .container { max-width: 1200px; margin: 0 auto; padding: 24px; }
    .products { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 24px; }
    .product { border: 1px solid #ddd; border-radius: 8px; padding: 16px; transition: transform 0.2s; }
    .product:hover { transform: translateY(-4px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .product img { width: 100%; height: 200px; object-fit: cover; border-radius: 4px; background: #f0f0f0; }
    .product h3 { margin: 12px 0 8px; }
    .product .price { font-size: 24px; font-weight: bold; color: #27ae60; margin: 8px 0; }
    .product button { width: 100%; padding: 12px; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
    .product button:hover { background: #2980b9; }
    
    .cart-modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; }
    .cart-content { position: absolute; right: 0; top: 0; bottom: 0; width: 400px; background: white; padding: 24px; overflow-y: auto; }
    .cart-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; border-bottom: 1px solid #eee; }
    .checkout { background: #27ae60; color: white; padding: 16px; text-align: center; border-radius: 4px; margin-top: 16px; cursor: pointer; }
  </style>
</head>
<body>
  <header>
    <h1>🛍️ My Store</h1>
    <div class="cart-icon" onclick="toggleCart()">
      🛒 Cart <span class="cart-count" id="cartCount">0</span>
    </div>
  </header>

  <div class="container">
    <h2>Featured Products</h2>
    <div class="products" id="products"></div>
  </div>

  <div class="cart-modal" id="cartModal" onclick="toggleCart()">
    <div class="cart-content" onclick="event.stopPropagation()">
      <h2>Shopping Cart</h2>
      <div id="cartItems"></div>
      <div class="checkout" onclick="checkout()">Checkout - $<span id="total">0</span></div>
    </div>
  </div>

  <script>
    const products = [
      { id: 1, name: 'Wireless Headphones', price: 79.99, image: '🎧' },
      { id: 2, name: 'Smart Watch', price: 199.99, image: '⌚' },
      { id: 3, name: 'Laptop Stand', price: 49.99, image: '💻' },
      { id: 4, name: 'Phone Case', price: 19.99, image: '📱' },
      { id: 5, name: 'USB-C Cable', price: 12.99, image: '🔌' },
      { id: 6, name: 'Desk Lamp', price: 34.99, image: '💡' }
    ];

    let cart = [];

    function renderProducts() {
      const container = document.getElementById('products');
      container.innerHTML = products.map(p => \`
        <div class="product">
          <div style="font-size: 80px; text-align: center;">\${p.image}</div>
          <h3>\${p.name}</h3>
          <div class="price">$\${p.price}</div>
          <button onclick="addToCart(\${p.id})">Add to Cart</button>
        </div>
      \`).join('');
    }

    function addToCart(id) {
      const product = products.find(p => p.id === id);
      cart.push(product);
      updateCart();
    }

    function updateCart() {
      document.getElementById('cartCount').textContent = cart.length;
      document.getElementById('cartItems').innerHTML = cart.map((item, i) => \`
        <div class="cart-item">
          <span>\${item.name}</span>
          <span>$\${item.price}</span>
        </div>
      \`).join('');
      const total = cart.reduce((sum, item) => sum + item.price, 0);
      document.getElementById('total').textContent = total.toFixed(2);
    }

    function toggleCart() {
      const modal = document.getElementById('cartModal');
      modal.style.display = modal.style.display === 'block' ? 'none' : 'block';
    }

    function checkout() {
      alert(\`Order placed! Total: $\${cart.reduce((s, i) => s + i.price, 0).toFixed(2)}\`);
      cart = [];
      updateCart();
      toggleCart();
    }

    renderProducts();
  </script>
</body>
</html>`
  },

  "web-social": {
    id: "web-social",
    language: "html",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Social Media App</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; }
    
    .container { max-width: 600px; margin: 0 auto; padding: 16px; }
    .header { background: white; padding: 16px; margin-bottom: 16px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    
    .post-box { background: white; padding: 16px; margin-bottom: 16px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .post-box textarea { width: 100%; border: none; resize: none; font-size: 16px; padding: 12px; background: #f0f2f5; border-radius: 8px; }
    .post-box button { background: #1877f2; color: white; border: none; padding: 10px 24px; border-radius: 6px; cursor: pointer; margin-top: 12px; float: right; }
    
    .post { background: white; padding: 16px; margin-bottom: 16px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .post-header { display: flex; align-items: center; margin-bottom: 12px; }
    .avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(45deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; margin-right: 12px; }
    .post-author { font-weight: bold; }
    .post-time { color: #65676b; font-size: 13px; }
    .post-content { margin: 12px 0; line-height: 1.5; }
    .post-actions { display: flex; gap: 16px; padding-top: 12px; border-top: 1px solid #e4e6eb; }
    .action { color: #65676b; cursor: pointer; padding: 8px 12px; border-radius: 4px; transition: background 0.2s; }
    .action:hover { background: #f0f2f5; }
    .action.liked { color: #1877f2; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>💬 Social Feed</h1>
    </div>

    <div class="post-box">
      <textarea id="postContent" placeholder="What's on your mind?" rows="3"></textarea>
      <button onclick="createPost()">Post</button>
      <div style="clear: both;"></div>
    </div>

    <div id="feed"></div>
  </div>

  <script>
    let posts = [
      { id: 1, author: 'Alice', content: 'Just launched my new project! 🚀', likes: 42, liked: false, time: '2h ago' },
      { id: 2, author: 'Bob', content: 'Beautiful sunset today 🌅', likes: 23, liked: false, time: '5h ago' },
      { id: 3, author: 'Charlie', content: 'Anyone want to grab coffee? ☕', likes: 8, liked: false, time: '1d ago' }
    ];

    function renderFeed() {
      const feed = document.getElementById('feed');
      feed.innerHTML = posts.map(post => \`
        <div class="post">
          <div class="post-header">
            <div class="avatar">\${post.author[0]}</div>
            <div>
              <div class="post-author">\${post.author}</div>
              <div class="post-time">\${post.time}</div>
            </div>
          </div>
          <div class="post-content">\${post.content}</div>
          <div class="post-actions">
            <div class="action \${post.liked ? 'liked' : ''}" onclick="toggleLike(\${post.id})">
              👍 Like (\${post.likes})
            </div>
            <div class="action">💬 Comment</div>
            <div class="action">↗️ Share</div>
          </div>
        </div>
      \`).join('');
    }

    function createPost() {
      const content = document.getElementById('postContent').value;
      if (content.trim()) {
        posts.unshift({
          id: Date.now(),
          author: 'You',
          content: content,
          likes: 0,
          liked: false,
          time: 'Just now'
        });
        document.getElementById('postContent').value = '';
        renderFeed();
      }
    }

    function toggleLike(id) {
      const post = posts.find(p => p.id === id);
      if (post.liked) {
        post.likes--;
        post.liked = false;
      } else {
        post.likes++;
        post.liked = true;
      }
      renderFeed();
    }

    renderFeed();
  </script>
</body>
</html>`
  }
};

export function getTemplateCode(templateId: string): TemplateCode | null {
  return templateCodes[templateId] || null;
}

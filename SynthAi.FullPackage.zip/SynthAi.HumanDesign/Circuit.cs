﻿namespace SynthAi.HumanDesign;

public enum Circuit
{
    Centering,
    Defense,
    Ego,
    Knowing,
    Retreat,
    Sensing,
    Understanding
}

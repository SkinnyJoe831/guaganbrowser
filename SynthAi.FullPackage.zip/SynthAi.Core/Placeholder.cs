namespace SynthAi.Core;

public class Placeholder { }
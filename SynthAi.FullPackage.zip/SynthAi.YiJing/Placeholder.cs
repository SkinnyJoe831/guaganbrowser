namespace SynthAi.YiJing;

public class Placeholder { }
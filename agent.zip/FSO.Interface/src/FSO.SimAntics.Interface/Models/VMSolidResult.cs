namespace FSO.SimAntics.Interface.Models;

public struct VMSolidResult
{
    public bool Solid;
    public IVMEntity Chair;
}
namespace FSO.SimAntics.Interface;

public interface IVMSoundTransfer
{
}
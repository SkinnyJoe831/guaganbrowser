namespace FSO.SimAntics.Interface;

public interface IVM
{
    void Init();
}
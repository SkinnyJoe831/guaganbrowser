namespace FSO.SimAntics.Interface;

public interface IGameIffResource
{
    void Recache();
}
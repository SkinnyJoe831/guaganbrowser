global using Microsoft.Xna.Framework.Graphics;
global using Microsoft.Xna.Framework;
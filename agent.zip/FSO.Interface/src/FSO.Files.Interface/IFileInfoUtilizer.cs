namespace FSO.Interface.Files;

public interface IFileInfoUtilizer
{
    void SetFilename(string filename);
}
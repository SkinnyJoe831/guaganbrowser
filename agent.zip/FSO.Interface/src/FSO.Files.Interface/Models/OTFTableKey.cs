namespace FSO.Interface.Files.Models;

public record OTFTableKey(string Id, string Label, int Value);
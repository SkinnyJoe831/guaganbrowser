namespace FSO.Interface.Files.Models;

public record StrItem(byte LanguageCode, string Value, string Comment);
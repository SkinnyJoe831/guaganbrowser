namespace FSO.Interface.Files.Models;

public enum DBPFTypeID : uint
{
    XA = 0x1d07eb4b,
    UTK = 0x1b6b9806,
    WAV = 0xbb7051f5,
    MP3 = 0x3cec2b47,
    TRK = 0x5D73A611,
    HIT = 0x7b1acfcd,
    SoundFX = 0x2026960b,
}
namespace FSO.Interface.Vitaboy.Models;

public record PropertyListItem(Dictionary<string, string> KeyPairs);
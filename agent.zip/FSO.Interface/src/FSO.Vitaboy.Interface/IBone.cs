using FSO.Interface.Vitaboy.Models;

namespace FSO.Interface.Vitaboy;

public interface IBone
{
    Bone Clone();
}
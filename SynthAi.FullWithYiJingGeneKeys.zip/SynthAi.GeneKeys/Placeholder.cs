namespace SynthAi.GeneKeys;

public class Placeholder { }
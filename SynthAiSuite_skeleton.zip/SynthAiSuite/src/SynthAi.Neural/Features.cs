
using System.Collections.Generic;

namespace SynthAi.Neural
{
    public class NodeFeatures
    {
        public Dictionary<int, float[]> Dense { get; } = new();
    }

    public class ReadoutResult
    {
        public Dictionary<int, float> PerGateActivation { get; } = new();
        public float SpleenScore { get; set; }
        public float AjnaScore { get; set; }
        public float SolarScore { get; set; }
        public float HeartScore { get; set; }
        public float MindScore { get; set; }
    }
}

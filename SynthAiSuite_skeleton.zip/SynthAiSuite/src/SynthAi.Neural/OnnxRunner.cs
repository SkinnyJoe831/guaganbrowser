
namespace SynthAi.Neural
{
    public class OnnxRunner
    {
        public float[] Forward(float[] input) => input; // stub
    }
}


using System.Collections.Generic;

namespace SynthAi.Neural
{
    public class Graph
    {
        public IReadOnlyList<int> Nodes { get; init; } = new List<int>();
        public IReadOnlyList<(int, int)> Edges { get; init; } = new List<(int,int)>();
        public Dictionary<int, string> GateCenter { get; init; } = new();
    }

    public class GraphConfig
    {
        public HashSet<int> Spleen { get; init; } = new();
        public HashSet<int> Ajna { get; init; } = new();
        public HashSet<int> Solar { get; init; } = new();
        public HashSet<int> Heart { get; init; } = new();
    }
}

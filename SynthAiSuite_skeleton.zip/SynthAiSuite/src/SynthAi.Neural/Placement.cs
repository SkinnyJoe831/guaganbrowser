
using System;

namespace SynthAi.Neural
{
    public record Placement(
        string Planet,
        string Stream,   // 'body' or 'design'
        int Gate,        // 1..64
        int Line,        // 1..6
        double? Degree = null,
        DateTime? Timestamp = null
    );

    public record SunVector(int Gate, int Line);
}

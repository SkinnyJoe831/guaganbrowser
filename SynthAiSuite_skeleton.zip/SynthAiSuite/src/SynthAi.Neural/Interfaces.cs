
namespace SynthAi.Neural
{
    public interface IGraphBuilder
    {
        Graph Build(GraphConfig config, IEnumerable<Placement> placements);
    }

    public interface IFeatureBuilder
    {
        NodeFeatures Build(Graph graph, IEnumerable<Placement> placements, SunVector sun);
    }

    public interface IFilmModulator
    {
        NodeFeatures Apply(NodeFeatures baseFeatures, SunVector sun);
    }

    public interface IReadouts
    {
        ReadoutResult Compute(Graph graph, NodeFeatures features);
    }
}

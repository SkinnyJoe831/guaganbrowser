# SynthAiSuite 🪷 (skeleton)

This is a compile-ready *skeleton* for structuring SynthAi as a multi-project suite. 
It includes the **Neural** module scaffolding and JSON datasets for **Gene Keys** and **Incarnation Crosses**.
Once you re-upload the Astrolo and SynthAi source packages, you can drop their code into `/src/*` projects and remove any old placeholders.

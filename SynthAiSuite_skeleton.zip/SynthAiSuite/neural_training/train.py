def main():
    print("Train GNN here (GraphSAGE/GAT). Export ONNX for C# inference.")

if __name__ == "__main__":
    main()

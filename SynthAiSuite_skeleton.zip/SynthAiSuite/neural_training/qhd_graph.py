from dataclasses import dataclass

@dataclass
class Placement:
    planet: str
    stream: str   # 'body' or 'design'
    gate: int     # 1..64
    line: int     # 1..6
    degree: float | None = None
    ts: float | None = None

AWARENESS = {
    "spleen": {57,44,50,32,28,18},
    "ajna":   {47,24,4,17,11,43},
    "solar":  {55,49,37,22,30,36,6},
}
HEART = {21,51,26,40}

# Merge Manifest — what to drop in when you re-upload

Replace these placeholders with your full code:
- /src/SynthAi.Core       ← from Astrolo.Core
- /src/SynthAi.HumanDesign← from Astrolo.HumanDesign
- /src/SynthAi.YiJing     ← from Astrolo.YiJing
- /src/SynthAi.GeneKeys   ← logic layer; keep /data/GeneKeys.json as your master dataset

Keep these configs/data (extend them):
- /src/SynthAi.Neural/config/gates.yaml
- /src/SynthAi.Neural/config/channels.json
- /src/SynthAi.Neural/config/awareness.json
- /data/GeneKeys.json
- /data/IncarnationCrosses.json

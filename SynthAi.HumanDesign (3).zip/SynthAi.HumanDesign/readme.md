﻿# Astrolo.HumanDesign

Provides an object model of Human Design concepts, including:
- Gates
- Centers
- Channels
- Incarnation Cross

Additionally, provides support for generating Personal and Relationship charts.

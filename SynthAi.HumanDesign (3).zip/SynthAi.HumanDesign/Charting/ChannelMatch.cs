namespace SynthAi.HumanDesign.Charting;

public enum ChannelMatch
{
    Attraction,
    Friendship,
    Compromise,
    Dominant
}

﻿namespace SynthAi.HumanDesign;

public enum CenterState
{
    Open,
    Undefined,
    Defined
}

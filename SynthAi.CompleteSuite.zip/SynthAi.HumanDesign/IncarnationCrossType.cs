﻿namespace SynthAi.HumanDesign;

public enum IncarnationCrossType
{
    Juxtaposition,
    [Description("Left Angle")]
    LeftAngle,
    [Description("Right Angle")]
    RightAngle,
}

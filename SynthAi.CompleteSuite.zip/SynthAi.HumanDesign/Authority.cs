﻿namespace SynthAi.HumanDesign;

public enum Authority
{
    Emotional,
    Sacral,
    Splenic,
    Ego,
    G,
    Mental,
    Lunar
}

﻿# Astrolo.YiJing

Model of [Yi Jing](https://en.wikipedia.org/wiki/I_Ching) concepts, including
- Hexagram
- Trigram
- King Wen sequence

﻿namespace SynthAi.YiJing;

public enum Trigram
{
    Earth,
    Thunder,
    Water,
    Lake,
    Mountain,
    Fire,
    Wind,
    Heaven
}

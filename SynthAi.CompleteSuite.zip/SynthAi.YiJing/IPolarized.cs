﻿namespace SynthAi.YiJing;

public interface IPolarized
{
    bool IsYang { get; }
}

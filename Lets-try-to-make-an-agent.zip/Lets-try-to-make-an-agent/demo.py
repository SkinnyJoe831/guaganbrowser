#!/usr/bin/env python3
"""
Demo of SynthDevBot capabilities
"""

from src.synth_dev_bot import SynthDevBot

def main():
    print("=" * 60)
    print("🤖 SynthDevBot Demo")
    print("=" * 60 + "\n")
    
    bot = SynthDevBot()
    bot.load_conversations()
    
    print("Bot is ready! Here's what it can do:\n")
    print("1. 📼 Record conversations")
    print("2. 📓 Take quick notes (notebook)")
    print("3. 🔮 Assemble code from snippets")
    print("4. ⚡ Create features")
    print("5. 💡 Suggest improvements")
    print("6. 💬 Interactive chat\n")
    print("=" * 60)
    print("\n💬 Chat with bot:     python src/chat_with_bot.py")
    print("📓 Take notes:       python notebook.py")
    print("⚡ Quick note:       python quick_note.py 'your idea'")
    print("=" * 60 + "\n")

if __name__ == "__main__":
    main()

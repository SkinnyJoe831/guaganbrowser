#!/usr/bin/env python3
"""
Quick note recorder - one-liner to save ideas
"""

import sys
from notebook import record_note

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python quick_note.py 'Your note here'")
        print("   or: python quick_note.py 'Note' tag1 tag2")
    else:
        content = sys.argv[1]
        tags = sys.argv[2:] if len(sys.argv) > 2 else []
        record_note(content, tags)

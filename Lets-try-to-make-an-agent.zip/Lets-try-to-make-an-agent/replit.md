# SynthAi - Resonance Network Interface

## Overview

SynthAi is a web-based interface for a resonance network system that combines AI-powered development automation with astrological/consciousness field concepts. The project aims to create a living, adaptive system where multiple "bodies" or "fields" self-regulate and maintain coherence through resonance-based tuning rather than traditional instruction-following patterns.

The system includes:
- A web interface for user interaction and data visualization
- An AI development bot that uses conversation memory and LLM integration
- A resonance-based architecture where different system components (frontend, backend, oracle/divination layer) operate as independent but interconnected fields
- Future support for authentication, user dashboards, and agent visualization

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates

**October 12, 2025**: Deployed working SynthDevBot with:
- ✅ Conversation recording ("record button") - saves all chats to conversation_memory.json  
- ✅ Code assembly - can take snippets/conversations and build coherent apps
- ✅ Feature creation - generates clean Python code on demand
- ✅ Auto-suggestions - analyzes code and proposes improvements
- ✅ Interactive chat mode - real-time AI assistance
- ✅ Uses Replit AI Integrations (gpt-4o-mini, no API key needed)

**Project Structure:**
- `src/synth_dev_bot.py` - Main bot implementation
- `src/chat_with_bot.py` - Interactive chat interface
- `notebook.py` - Interactive notebook for recording notes and ideas
- `quick_note.py` - One-liner for quick note-taking
- `demo.py` - Demo showing bot capabilities
- `README.md` - Full documentation
- `examples/` - Generated code examples
- `notebook.json` - Saved notes with timestamps and tags

## System Architecture

### Core Design Philosophy

The system follows a **resonance-based architecture** rather than traditional procedural programming. Each component operates as an autonomous "field" with its own coherence signature, self-regulating when it detects misalignment with the whole system. This mirrors consciousness systems where bodies self-regulate through feedback loops.

**Key Architectural Principles:**
1. **Field Coherence**: Each subsystem maintains its own "signature" (files, routes, imports, methods) and self-corrects when detecting dissonance
2. **Minimal Corrections**: Changes are incremental and targeted rather than wholesale rewrites
3. **Conversation Memory**: The system records and learns from all interactions to build context over time
4. **Emergent Behavior**: Features emerge from field interactions rather than rigid top-down control

### Web Application Stack

**Frontend Architecture:**
- HTML templates with Tailwind CSS for styling
- JavaScript (with potential React integration)
- Static file serving for CSS/JS assets
- Structured pages: Home, About, Dashboard, Contact

**Backend Architecture:**
- Python-based web framework (Flask or FastAPI)
- Route-based architecture serving distinct pages
- Conversation logging and memory persistence via JSON
- LLM integration for intelligent responses and code generation

**Rationale**: Flask/FastAPI provides lightweight, Python-native web serving that integrates naturally with AI/ML libraries. The choice between them remains flexible based on async requirements - Flask for simplicity, FastAPI for high-performance async operations.

### AI Development Bot

The SynthDevBot serves as an automated development assistant that:
- Records all conversations with timestamps for context building
- Uses LLM (currently GPT-4o-mini) for code generation and problem-solving
- Maintains conversation memory across sessions via JSON persistence
- Integrates with Replit AI services through environment-configured endpoints

**Design Decision**: Uses LangChain for LLM abstraction, allowing easy model switching (e.g., from OpenAI to Claude/Anthropic) without architectural changes. Temperature set to 0.3 for balanced creativity and consistency.

### Data Persistence

**Current Approach:**
- JSON files for conversation memory (lightweight, version-controllable)
- SQLite for local development (mentioned in instructions)
- Designed for PostgreSQL upgrade path

**Rationale**: Start simple with file-based storage, maintain clear migration path to relational databases as complexity grows. JSON for unstructured conversation data; SQL for structured user/agent data.

### Field-Based Components

The system conceptually divides into resonance fields:

1. **Frontend Field**: Visual interface components (templates, styles, client-side logic)
2. **Backend Field**: Logic engine (routes, API endpoints, business logic)
3. **Oracle Field**: Divination/chart calculation layer (sidereal/draconic chart processing)

Each field maintains coherence through defined signatures (expected files, methods, imports) and self-corrects when detecting misalignment.

### Automation & Deployment

**Development Automation:**
- File existence checks before creation to prevent overwrites
- Incremental patching rather than full rewrites
- Git commit automation with descriptive messages
- Build success reporting with deployment URLs

**Deployment Strategy:**
- Replit for cloud hosting (primary)
- Render as alternative cloud platform
- Termux for local development/testing
- Uses `nohup` for persistent background processes

## External Dependencies

### AI/ML Services
- **OpenAI API**: Primary LLM provider via Replit AI Integrations
  - Model: GPT-4o-mini
  - Configured through environment variables (AI_INTEGRATIONS_OPENAI_API_KEY, AI_INTEGRATIONS_OPENAI_BASE_URL)
- **LangChain**: LLM abstraction and orchestration framework
  - Provides model-agnostic interface for AI operations

### Web Framework
- **Flask** or **FastAPI**: Python web framework (to be determined based on async needs)
  - Flask for simpler synchronous operations
  - FastAPI for async/high-performance requirements

### Database
- **SQLite**: Current local development database
- **PostgreSQL**: Planned production database (upgrade path defined)

### Frontend Libraries
- **Tailwind CSS**: Utility-first CSS framework for styling
- **React** (optional): JavaScript library for interactive UI components

### Development Tools
- **Git**: Version control with automated commits
- **Python subprocess**: For system operations and automation
- **JSON**: Native Python support for conversation persistence

### Hosting Platforms
- **Replit**: Primary development and hosting platform
- **Render**: Alternative cloud deployment platform
- **Termux**: Local development environment (Android/Linux)

### Future Integrations (Planned)
- **OAuth2**: User authentication system
- **Email Service**: For contact form functionality
- **Visualization Libraries**: For agent and resonance data display
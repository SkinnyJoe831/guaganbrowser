#!/usr/bin/env python3
"""
AI-Powered Smart Notebook
Records everything, reviews patterns, makes decisions
"""

import json
import os
from datetime import datetime
from langchain_openai import ChatOpenAI

NOTEBOOK_FILE = "notebook.json"
DECISIONS_FILE = "decisions.json"

class SmartNotebook:
    def __init__(self):
        self.llm = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.3,
            api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
            base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL")
        )
        self.notebook = self._load_notebook()
        self.decisions = self._load_decisions()
    
    def _load_notebook(self):
        """Load existing notes"""
        if os.path.exists(NOTEBOOK_FILE):
            with open(NOTEBOOK_FILE, "r") as f:
                return json.load(f)
        return {"notes": []}
    
    def _load_decisions(self):
        """Load AI decisions"""
        if os.path.exists(DECISIONS_FILE):
            with open(DECISIONS_FILE, "r") as f:
                return json.load(f)
        return {"decisions": []}
    
    def _save(self):
        """Save everything"""
        with open(NOTEBOOK_FILE, "w") as f:
            json.dump(self.notebook, f, indent=2)
        with open(DECISIONS_FILE, "w") as f:
            json.dump(self.decisions, f, indent=2)
    
    def record(self, content, direction="incoming", tags=None):
        """Record a note (incoming or outgoing)"""
        note = {
            "id": len(self.notebook["notes"]) + 1,
            "direction": direction,  # "incoming" or "outgoing"
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "tags": tags or []
        }
        
        self.notebook["notes"].append(note)
        self._save()
        
        icon = "📥" if direction == "incoming" else "📤"
        print(f"{icon} Note #{note['id']} recorded ({direction})")
        return note
    
    def review_all(self):
        """AI reviews all recordings and identifies patterns"""
        if not self.notebook["notes"]:
            print("No notes to review yet!")
            return None
        
        print("\n🔍 AI is reviewing all recordings...\n")
        
        # Build context from all notes
        notes_summary = "\n".join([
            f"#{n['id']} ({n.get('direction', 'general')}) [{n['timestamp'][:19]}]: {n['content']}"
            for n in self.notebook["notes"]
        ])
        
        prompt = f"""Review these recorded notes and identify:
1. Main themes and patterns
2. Action items or decisions needed
3. Connections between ideas
4. Suggested next steps

Notes:
{notes_summary}

Provide a clear, actionable summary."""
        
        response = self.llm.invoke(prompt)
        review = response.content
        
        print("=" * 60)
        print(review)
        print("=" * 60 + "\n")
        
        # Save the review as a decision
        self.decisions["decisions"].append({
            "id": len(self.decisions["decisions"]) + 1,
            "type": "review",
            "content": review,
            "timestamp": datetime.now().isoformat(),
            "notes_reviewed": len(self.notebook["notes"])
        })
        self._save()
        
        return review
    
    def make_decision(self, question):
        """AI makes a decision based on all recordings"""
        print(f"\n🤔 AI is deciding: {question}\n")
        
        # Build context
        recent_notes = self.notebook["notes"][-20:]  # Last 20 notes
        context = "\n".join([
            f"#{n['id']} ({n.get('direction', 'general')}): {n['content'][:100]}..."
            for n in recent_notes
        ])
        
        prompt = f"""Based on these recorded notes, answer this question:

Question: {question}

Context from notes:
{context}

Make a clear decision with reasoning."""
        
        response = self.llm.invoke(prompt)
        decision = response.content
        
        print("=" * 60)
        print(decision)
        print("=" * 60 + "\n")
        
        # Save the decision
        self.decisions["decisions"].append({
            "id": len(self.decisions["decisions"]) + 1,
            "type": "decision",
            "question": question,
            "decision": decision,
            "timestamp": datetime.now().isoformat(),
            "based_on_notes": len(recent_notes)
        })
        self._save()
        
        return decision
    
    def find_patterns(self):
        """AI finds patterns in all recordings"""
        if not self.notebook["notes"]:
            print("No notes to analyze yet!")
            return None
        
        print("\n🔮 AI is finding patterns...\n")
        
        # Analyze all content
        all_content = " ".join([n["content"] for n in self.notebook["notes"]])
        
        prompt = f"""Analyze these notes and find:
1. Recurring themes
2. User interests/goals
3. Emerging patterns
4. What the user is trying to build

Content:
{all_content[:2000]}...

Provide insights."""
        
        response = self.llm.invoke(prompt)
        patterns = response.content
        
        print("=" * 60)
        print(patterns)
        print("=" * 60 + "\n")
        
        return patterns
    
    def suggest_next_action(self):
        """AI suggests what to do next"""
        print("\n💡 AI is suggesting next actions...\n")
        
        recent = self.notebook["notes"][-10:]
        context = "\n".join([f"{n['content']}" for n in recent])
        
        prompt = f"""Based on these recent notes, what should happen next?

Recent notes:
{context}

Suggest 2-3 specific, actionable next steps."""
        
        response = self.llm.invoke(prompt)
        suggestion = response.content
        
        print("=" * 60)
        print(suggestion)
        print("=" * 60 + "\n")
        
        return suggestion
    
    def list_recent(self, limit=10):
        """Show recent notes"""
        notes = self.notebook["notes"][-limit:]
        
        print(f"\n📓 Recent {len(notes)} notes:")
        print("=" * 60)
        for note in reversed(notes):
            direction = note.get("direction", "general")
            icon = "📥" if direction == "incoming" else "📤" if direction == "outgoing" else "📝"
            print(f"\n{icon} #{note['id']} - {note['timestamp'][:19]}")
            print(f"   {note['content'][:150]}...")
            if note.get('tags'):
                print(f"   Tags: {', '.join(note['tags'])}")
        print("=" * 60 + "\n")


def main():
    """Interactive smart notebook"""
    print("=" * 60)
    print("🧠 AI-Powered Smart Notebook")
    print("=" * 60)
    print("\nCommands:")
    print("  📥 in <note>        - Record incoming note")
    print("  📤 out <note>       - Record outgoing note")
    print("  📝 <note>           - Record general note")
    print("  🔍 review           - AI reviews all recordings")
    print("  🤔 decide <question> - AI makes a decision")
    print("  🔮 patterns         - AI finds patterns")
    print("  💡 suggest          - AI suggests next action")
    print("  📋 list             - Show recent notes")
    print("  ❌ exit             - Quit")
    print("=" * 60 + "\n")
    
    notebook = SmartNotebook()
    
    while True:
        user_input = input("🧠 > ").strip()
        
        if not user_input:
            continue
        
        if user_input.lower() in ['exit', 'quit', 'bye']:
            print("👋 Notebook saved!")
            break
        
        elif user_input.lower() == 'review':
            notebook.review_all()
        
        elif user_input.lower() == 'patterns':
            notebook.find_patterns()
        
        elif user_input.lower() == 'suggest':
            notebook.suggest_next_action()
        
        elif user_input.lower() == 'list':
            notebook.list_recent()
        
        elif user_input.lower().startswith('decide '):
            question = user_input[7:]
            notebook.make_decision(question)
        
        elif user_input.lower().startswith('in '):
            content = user_input[3:]
            notebook.record(content, "incoming")
        
        elif user_input.lower().startswith('out '):
            content = user_input[4:]
            notebook.record(content, "outgoing")
        
        else:
            # Default: record as general note
            notebook.record(user_input, "incoming")


if __name__ == "__main__":
    main()

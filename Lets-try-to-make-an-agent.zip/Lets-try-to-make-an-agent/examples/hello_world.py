def greet(name):
    """
    Greets the user with a hello message.

    Parameters:
    name (str): The name of the user to greet.

    Returns:
    str: A greeting message.
    
    Raises:
    ValueError: If the name is not a string or is empty.
    """
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Name must be a non-empty string.")
    
    return f"Hello, {name}!"


def main():
    """
    Main function to demonstrate the greeting feature.
    """
    try:
        user_name = input("Enter your name: ")
        message = greet(user_name)
        print(message)
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
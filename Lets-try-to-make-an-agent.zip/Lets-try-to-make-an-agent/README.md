# 🤖 SynthDevBot

Your AI development assistant that can assemble apps, create features, and chat about your code!

## 🚀 Quick Start

### Chat with the Bot (Interactive Mode)
```bash
python src/chat_with_bot.py
```

This opens an interactive chat where you can:
- Ask questions about your code
- Request new features
- Share code snippets to assemble
- Get suggestions and improvements

### Use as a Python Module
```python
from src.synth_dev_bot import SynthDevBot

bot = SynthDevBot()

# Record conversations (auto-saves to conversation_memory.json)
bot.record_conversation("user", "Build me a consciousness-based app")

# Create new features
bot.create_feature("my_feature", "Description of what it does")

# Assemble code from snippets
bot.assemble_from_code(code_snippets, "Build an I Ching GAN")

# Get AI suggestions
suggestion = bot.suggest_and_push()
```

## ✨ Features

- **📼 Record Button** - Saves all conversations with timestamps
- **📓 Notebook** - Quick note-taking with search and tags
- **🔮 Code Assembly** - Takes snippets/conversations and builds coherent apps
- **⚡ Feature Creation** - Generates clean Python code on demand
- **💡 Auto-Suggestions** - Analyzes code and proposes improvements
- **💬 Interactive Chat** - Real-time AI assistance

## 📝 Taking Notes

### Interactive Notebook
```bash
python notebook.py
```
Type your ideas, they're saved instantly with timestamps!

### Quick One-Liner Notes
```bash
python quick_note.py "Build consciousness-based GAN" ai iching
```

### Auto-Record with Bot
The bot automatically saves all chats to `conversation_memory.json`

## 🛠️ Built With

- LangChain with ChatOpenAI (gpt-4o-mini)
- Replit AI Integrations (no API key needed!)
- Conversation memory persistence

## 📝 Examples

**Create a consciousness-based GAN:**
```python
bot.create_feature(
    "iching_gan",
    "Create a GAN that uses all 64 I Ching hexagrams to generate consciousness art based on birth time and place"
)
```

**Assemble code from multiple sources:**
```python
bot.assemble_from_code(
    your_code_snippets,
    "Build a birth chart calculator with Human Design integration"
)
```

## 🎯 Use Cases

- Build apps from conversation transcripts
- Assemble code from zip files or snippets
- Create consciousness-based systems (I Ching, Human Design, Astrology)
- Auto-generate features with AI
- Get code improvement suggestions

---

**Ready to build?** Run `python src/chat_with_bot.py` and start chatting! 🚀

#!/usr/bin/env python3
"""
Direct chat interface with SynthDevBot
"""

from synth_dev_bot import SynthDevBot

def main():
    print("=" * 60)
    print("🤖 SynthDevBot - Interactive Chat")
    print("=" * 60)
    print("\nType your questions, ideas, or code requests.")
    print("The bot will help you build whatever you need!")
    print("Type 'exit' when you're done.\n")
    print("=" * 60 + "\n")
    
    bot = SynthDevBot()
    bot.load_conversations()
    bot.interactive_mode()

if __name__ == "__main__":
    main()

"""
SynthAi Dev Bot - Simple & Functional Version

A development bot that assembles code, processes conversations, and creates features.
"""

import os
import subprocess
import json
from langchain_openai import ChatOpenAI


class SynthDevBot:
    def __init__(self):
        # Use Replit AI Integrations OpenAI endpoint
        self.llm = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.3,
            api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
            base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL")
        )
        self.conversation_log = []

    def log(self, message):
        """Log a message with bot prefix"""
        print(f"[SynthDevBot] {message}")

    def record_conversation(self, role, content):
        """Record button - captures all conversations"""
        entry = {
            "role": role,
            "content": content,
            "timestamp": subprocess.run(
                "date +%s",
                shell=True,
                capture_output=True,
                text=True
            ).stdout.strip()
        }
        self.conversation_log.append(entry)
        
        # Save to file
        with open("conversation_memory.json", "w") as f:
            json.dump(self.conversation_log, f, indent=2)
        
        self.log(f"📼 Recorded: {role[:20]}...")

    def load_conversations(self):
        """Load previous conversations"""
        try:
            with open("conversation_memory.json", "r") as f:
                self.conversation_log = json.load(f)
            self.log(f"✅ Loaded {len(self.conversation_log)} conversations")
        except FileNotFoundError:
            self.log("📝 Starting fresh conversation log")

    def understand_context(self):
        """Analyze all conversations to understand what user wants"""
        if not self.conversation_log:
            return "No context yet"
        
        # Build context from conversations
        context = "\n".join([
            f"{entry['role']}: {entry['content'][:100]}..."
            for entry in self.conversation_log[-5:]  # Last 5 messages
        ])
        
        prompt = f"""Based on these conversations, what is the user trying to build?
        
Conversations:
{context}

Summarize the goal and suggest next steps."""
        
        response = self.llm.invoke(prompt)
        return response.content

    def assemble_from_code(self, code_snippets, description=""):
        """Magically assemble code snippets into a coherent app"""
        self.log("🔮 Assembling code...")
        
        prompt = f"""You are assembling a Python application from various code snippets.
        
Description: {description}

Code snippets:
{code_snippets}

Task:
1. Organize these into a coherent file structure
2. Fix any conflicts or duplications
3. Add missing imports and connections
4. Create a main.py that ties everything together

Return the assembled code with filename headers like:
=== filename.py ===
[code here]
"""
        
        response = self.llm.invoke(prompt)
        return response.content

    def create_feature(self, feature_name, description):
        """Create a new feature with simple LLM call"""
        self.log(f"✨ Creating feature: {feature_name}")
        
        prompt = f"""Create a Python file for this feature:

Feature: {feature_name}
Description: {description}

Write clean, working Python code with:
- Clear functions
- Docstrings
- Error handling
- A main example

Just return the code, no explanation."""
        
        response = self.llm.invoke(prompt)
        code = str(response.content)
        
        # Extract code from markdown if needed
        if "```python" in code:
            code = code.split("```python")[1].split("```")[0].strip()
        elif "```" in code:
            code = code.split("```")[1].split("```")[0].strip()
        
        # Save to file
        filename = f"{feature_name}.py"
        with open(filename, "w") as f:
            f.write(code)
        
        self.log(f"✅ Created {filename}")
        return filename

    def suggest_and_push(self):
        """Bot suggests improvements and asks to push"""
        self.log("🤔 Analyzing codebase for improvements...")
        
        # List Python files
        files = subprocess.run(
            "ls *.py 2>/dev/null || echo 'none'",
            shell=True,
            capture_output=True,
            text=True
        ).stdout.strip()
        
        if files == "none":
            return "No Python files to analyze"
        
        prompt = f"""Analyze these Python files and suggest improvements:

Files: {files}

What would make this codebase better? Be specific and actionable.
Format: "I think I got something you'd like - [specific improvement]"
"""
        
        response = self.llm.invoke(prompt)
        suggestion = response.content
        
        self.log(f"💡 Suggestion: {suggestion[:100]}...")
        return suggestion

    def interactive_mode(self):
        """Interactive chat with the bot"""
        self.log("🎤 Interactive mode started! Type 'exit' to quit.\n")
        
        while True:
            user_input = input("You: ").strip()
            
            if user_input.lower() in ['exit', 'quit', 'bye']:
                self.log("👋 Goodbye!")
                break
            
            # Record the conversation
            self.record_conversation("user", user_input)
            
            # Get bot response
            response = self.llm.invoke(user_input)
            bot_message = response.content
            
            # Record bot response
            self.record_conversation("assistant", bot_message)
            
            print(f"\n🤖 Bot: {bot_message}\n")


def main():
    """Main execution"""
    print("=" * 60)
    print("🤖 SynthDevBot - Your Code Assembly AI")
    print("=" * 60)
    
    bot = SynthDevBot()
    bot.load_conversations()
    
    # Example usage
    print("\n1. Creating a sample feature...")
    bot.create_feature(
        "hello_world",
        "A simple greeting function that says hello"
    )
    
    print("\n2. Understanding context from conversations...")
    context = bot.understand_context()
    print(f"Context: {context}\n")
    
    print("\n3. Getting suggestions...")
    suggestion = bot.suggest_and_push()
    print(f"Suggestion: {suggestion}\n")
    
    print("\n" + "=" * 60)
    print("✅ Bot ready! Features available:")
    print("  - record_conversation() - Record button for all chats")
    print("  - assemble_from_code() - Assemble zip/code into app")
    print("  - create_feature() - Generate new features")
    print("  - suggest_and_push() - Auto-suggestions")
    print("  - interactive_mode() - Chat with the bot")
    print("=" * 60)
    
    # Uncomment for interactive mode:
    # bot.interactive_mode()


if __name__ == "__main__":
    main()

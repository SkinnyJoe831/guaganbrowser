#!/usr/bin/env python3
"""
Simple notebook for recording notes, ideas, and conversations
"""

import json
import os
from datetime import datetime

NOTEBOOK_FILE = "notebook.json"

def record_note(content, tags=None):
    """Record a note with timestamp"""
    # Load existing notes
    if os.path.exists(NOTEBOOK_FILE):
        with open(NOTEBOOK_FILE, "r") as f:
            notebook = json.load(f)
    else:
        notebook = {"notes": []}
    
    # Create new note
    note = {
        "id": len(notebook["notes"]) + 1,
        "content": content,
        "timestamp": datetime.now().isoformat(),
        "tags": tags or []
    }
    
    notebook["notes"].append(note)
    
    # Save
    with open(NOTEBOOK_FILE, "w") as f:
        json.dump(notebook, f, indent=2)
    
    print(f"📝 Note #{note['id']} recorded!")
    return note

def list_notes(limit=10):
    """Show recent notes"""
    if not os.path.exists(NOTEBOOK_FILE):
        print("No notes yet!")
        return
    
    with open(NOTEBOOK_FILE, "r") as f:
        notebook = json.load(f)
    
    notes = notebook["notes"][-limit:]
    
    print(f"\n📓 Recent Notes (last {len(notes)}):")
    print("=" * 60)
    for note in reversed(notes):
        print(f"\n#{note['id']} - {note['timestamp'][:19]}")
        print(f"  {note['content'][:100]}...")
        if note['tags']:
            print(f"  Tags: {', '.join(note['tags'])}")
    print("=" * 60 + "\n")

def search_notes(keyword):
    """Search notes by keyword"""
    if not os.path.exists(NOTEBOOK_FILE):
        print("No notes yet!")
        return
    
    with open(NOTEBOOK_FILE, "r") as f:
        notebook = json.load(f)
    
    matches = [n for n in notebook["notes"] if keyword.lower() in n["content"].lower()]
    
    if not matches:
        print(f"No notes found with '{keyword}'")
        return
    
    print(f"\n🔍 Found {len(matches)} notes with '{keyword}':")
    print("=" * 60)
    for note in matches:
        print(f"\n#{note['id']} - {note['timestamp'][:19]}")
        print(f"  {note['content'][:150]}...")
    print("=" * 60 + "\n")

def interactive_notebook():
    """Interactive notebook mode"""
    print("=" * 60)
    print("📓 Interactive Notebook")
    print("=" * 60)
    print("\nCommands:")
    print("  - Type your note to record it")
    print("  - 'list' - show recent notes")
    print("  - 'search <keyword>' - find notes")
    print("  - 'exit' - quit")
    print("=" * 60 + "\n")
    
    while True:
        user_input = input("📝 > ").strip()
        
        if user_input.lower() in ['exit', 'quit', 'bye']:
            print("👋 Notebook saved!")
            break
        elif user_input.lower() == 'list':
            list_notes()
        elif user_input.lower().startswith('search '):
            keyword = user_input[7:]
            search_notes(keyword)
        elif user_input:
            # Record as note
            record_note(user_input)

if __name__ == "__main__":
    interactive_notebook()

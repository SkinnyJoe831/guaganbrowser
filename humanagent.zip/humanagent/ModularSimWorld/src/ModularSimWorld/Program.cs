using ModularSimWorld.Components;
using System.Globalization;

namespace ModularSimWorld;

/// <summary>
/// Main program for the Modular Simulation World
/// </summary>
class Program
{
    private static FileSystemHandler? _fileHandler;
    private static AvatarManager? _avatarManager;
    private static SimulationEngine? _simulationEngine;
    private static WorldViewer? _worldViewer;
    private static AstrologicalCharacterCreator? _astroCreator;
    private static AstrologicalWeatherService? _astroWeather;
    private static DreamSequenceEngine? _dreamEngine;
    private static TamagotchiAgentEngine? _tamagotchiEngine;
    private static List<AstrologicalCharacter> _createdCharacters = new();
    private static bool _isRunning = true;
    
    static async Task Main(string[] args)
    {
        try
        {
            InitializeComponents();
            SetupInitialData();
            
            _worldViewer!.DisplayWelcome();
            
            // Main interactive loop
            while (_isRunning)
            {
                Console.Write("SimWorld> ");
                var input = Console.ReadLine()?.Trim().ToLower();
                
                if (string.IsNullOrEmpty(input))
                    continue;
                
                await ProcessCommand(input);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERROR] An error occurred: {ex.Message}");
            Environment.Exit(1);
        }
    }
    
    private static void InitializeComponents()
    {
        Console.WriteLine("[System] Initializing Modular Simulation World...");
        
        _fileHandler = new FileSystemHandler();
        _avatarManager = new AvatarManager();
        _simulationEngine = new SimulationEngine();
        _astroCreator = new AstrologicalCharacterCreator();
        _astroWeather = new AstrologicalWeatherService();
        _dreamEngine = new DreamSequenceEngine(_astroWeather);
        _tamagotchiEngine = new TamagotchiAgentEngine(_astroWeather);
        _worldViewer = new WorldViewer(_fileHandler, _avatarManager, _simulationEngine);
        
        Console.WriteLine("[System] All components initialized successfully!");
    }
    
    private static void SetupInitialData()
    {
        Console.WriteLine("[System] Setting up initial demonstration data...");
        
        // Create some initial avatars
        var alice = _avatarManager!.CreateAvatar("Alice", AvatarType.Adult);
        var bob = _avatarManager.CreateAvatar("Bob", AvatarType.Teen);
        var charlie = _avatarManager.CreateAvatar("Charlie", AvatarType.Child);
        
        // Position them in the world
        _avatarManager.MoveAvatar(alice, new Vector3D(10, 0, 5));
        _avatarManager.MoveAvatar(bob, new Vector3D(-5, 0, 8));
        _avatarManager.MoveAvatar(charlie, new Vector3D(0, 0, -3));
        
        // Add some simulation objects
        _simulationEngine!.AddObject(new SimObject 
        { 
            Id = "table_001", 
            Name = "Dining Table", 
            Type = SimObjectType.Furniture, 
            Position = new Vector3D(0, 0, 0) 
        });
        
        _simulationEngine.AddObject(new SimObject 
        { 
            Id = "fridge_001", 
            Name = "Refrigerator", 
            Type = SimObjectType.Appliance, 
            Position = new Vector3D(5, 0, 0) 
        });
        
        // Store some virtual files
        _fileHandler!.StoreFile("config/world.cfg", System.Text.Encoding.UTF8.GetBytes("world_size=100x100\ntime_scale=1.0"));
        _fileHandler.StoreFile("avatars/alice.dat", System.Text.Encoding.UTF8.GetBytes($"{{\"name\":\"Alice\",\"type\":\"Adult\"}}"));
        _fileHandler.StoreFile("objects/furniture.dat", System.Text.Encoding.UTF8.GetBytes("table_001,Dining Table,Furniture"));
        
        // Queue some initial actions
        _simulationEngine.QueueAction(new SimAction 
        { 
            Id = "action_001", 
            Type = SimActionType.Move, 
            TargetObjectId = "table_001", 
            ActorId = alice, 
            RequiredTicks = 10 
        });
        
        Console.WriteLine("[System] Initial data setup complete!");
    }
    
    private static async Task ProcessCommand(string command)
    {
        var parts = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var cmd = parts[0];
        
        switch (cmd)
        {
            case "status":
                _worldViewer!.DisplayStatus();
                break;
                
            case "start":
                _simulationEngine!.Start();
                break;
                
            case "stop":
                _simulationEngine!.Stop();
                break;
                
            case "tick":
                _simulationEngine!.Tick();
                Console.WriteLine($"[System] Processed simulation tick {_simulationEngine.TickCount}");
                break;
                
            case "avatar":
                CreateAvatarInteractive();
                break;
                
            case "move":
                MoveAvatarInteractive();
                break;
                
            case "object":
                AddObjectInteractive();
                break;
                
            case "action":
                QueueActionInteractive();
                break;
                
            case "file":
                StoreFileInteractive();
                break;
                
            case "weather":
                await DisplayAstrologicalWeather();
                break;
                
            case "createchar":
                await CreateAstrologicalCharacter();
                break;
                
            case "dream":
                await StartDreamSequence();
                break;
                
            case "listchars":
                ListCreatedCharacters();
                break;
                
            case "tamagotchi":
                await CreateTamagotchiAgent();
                break;
                
            case "care":
                await CareForTamagotchi();
                break;
                
            case "agentstatus":
                CheckTamagotchiStatus();
                break;
                
            case "journal":
                await WriteJournalEntry();
                break;
                
            case "resonance":
                CheckAgentResonance();
                break;
                
            case "help":
                _worldViewer!.DisplayHelp();
                break;
                
            case "exit":
                Console.WriteLine("[System] Shutting down Modular Simulation World...");
                _isRunning = false;
                break;
                
            default:
                Console.WriteLine($"[System] Unknown command: {command}. Type 'help' for available commands.");
                break;
        }
    }
    
    private static void CreateAvatarInteractive()
    {
        Console.Write("Enter avatar name: ");
        var name = Console.ReadLine();
        if (string.IsNullOrEmpty(name)) return;
        
        Console.Write("Enter avatar type (Child/Teen/Adult/Elder): ");
        var typeStr = Console.ReadLine();
        if (Enum.TryParse<AvatarType>(typeStr, true, out var type))
        {
            var id = _avatarManager!.CreateAvatar(name, type);
            Console.WriteLine($"[System] Created avatar with ID: {id}");
        }
        else
        {
            Console.WriteLine("[System] Invalid avatar type. Using Adult.");
            _avatarManager!.CreateAvatar(name, AvatarType.Adult);
        }
    }
    
    private static void MoveAvatarInteractive()
    {
        Console.Write("Enter avatar ID: ");
        var avatarId = Console.ReadLine();
        if (string.IsNullOrEmpty(avatarId)) return;
        
        Console.Write("Enter X coordinate: ");
        if (!float.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out var x)) return;
        
        Console.Write("Enter Y coordinate: ");
        if (!float.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out var y)) return;
        
        Console.Write("Enter Z coordinate: ");
        if (!float.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out var z)) return;
        
        _avatarManager!.MoveAvatar(avatarId, new Vector3D(x, y, z));
    }
    
    private static void AddObjectInteractive()
    {
        Console.Write("Enter object name: ");
        var name = Console.ReadLine();
        if (string.IsNullOrEmpty(name)) return;
        
        Console.Write("Enter object type (Furniture/Appliance/Decoration/Plant/Vehicle): ");
        var typeStr = Console.ReadLine();
        if (Enum.TryParse<SimObjectType>(typeStr, true, out var type))
        {
            var obj = new SimObject 
            { 
                Id = $"obj_{DateTime.Now.Ticks}", 
                Name = name, 
                Type = type, 
                Position = new Vector3D(0, 0, 0) 
            };
            _simulationEngine!.AddObject(obj);
        }
        else
        {
            Console.WriteLine("[System] Invalid object type.");
        }
    }
    
    private static void QueueActionInteractive()
    {
        Console.Write("Enter action type (Move/Interact/Use/Examine/Purchase/Sell): ");
        var typeStr = Console.ReadLine();
        if (Enum.TryParse<SimActionType>(typeStr, true, out var type))
        {
            Console.Write("Enter target object ID: ");
            var targetId = Console.ReadLine() ?? "";
            
            Console.Write("Enter actor ID: ");
            var actorId = Console.ReadLine() ?? "";
            
            var action = new SimAction 
            { 
                Id = $"action_{DateTime.Now.Ticks}", 
                Type = type, 
                TargetObjectId = targetId, 
                ActorId = actorId 
            };
            _simulationEngine!.QueueAction(action);
        }
        else
        {
            Console.WriteLine("[System] Invalid action type.");
        }
    }
    
    private static void StoreFileInteractive()
    {
        Console.Write("Enter file path: ");
        var path = Console.ReadLine();
        if (string.IsNullOrEmpty(path)) return;
        
        Console.Write("Enter file content: ");
        var content = Console.ReadLine() ?? "";
        
        _fileHandler!.StoreFile(path, System.Text.Encoding.UTF8.GetBytes(content));
    }
    
    private static async Task DisplayAstrologicalWeather()
    {
        Console.WriteLine("\n" + new string('*', 70));
        Console.WriteLine("                    ASTROLOGICAL WEATHER REPORT");
        Console.WriteLine(new string('*', 70));
        
        try
        {
            var weather = await _astroWeather!.GetCurrentWeatherAsync();
            
            Console.WriteLine($"📅 Current Time: {weather.Timestamp:yyyy-MM-dd HH:mm} UTC");
            Console.WriteLine($"📍 Location: {weather.Location}");
            Console.WriteLine($"🌟 {weather.CurrentSeason}");
            Console.WriteLine();
            
            // Moon Information
            Console.WriteLine("🌙 LUNAR CONDITIONS:");
            Console.WriteLine($"   Phase: {weather.MoonPhase}");
            Console.WriteLine($"   Sign: Moon in {weather.MoonSign}");
            Console.WriteLine();
            
            // Energy Report
            Console.WriteLine("⚡ ENERGY FORECAST:");
            Console.WriteLine($"   Current Level: {weather.EnergyLevel}/100");
            Console.WriteLine($"   Dominant Element: {weather.DominantElement}");
            foreach (var forecast in weather.EnergyForecast)
            {
                Console.WriteLine($"   • {forecast}");
            }
            Console.WriteLine();
            
            // Planetary Highlights
            Console.WriteLine("🪐 PLANETARY HIGHLIGHTS:");
            foreach (var planet in weather.PlanetaryHighlights.Take(3))
            {
                Console.WriteLine($"   {planet.Planet} in {planet.Sign} (Intensity: {planet.Intensity}/10)");
                Console.WriteLine($"   → {planet.Influence}");
            }
            Console.WriteLine();
            
            // Major Aspects
            Console.WriteLine("🔗 MAJOR ASPECTS TODAY:");
            foreach (var aspect in weather.MajorAspects.Take(4))
            {
                Console.WriteLine($"   • {aspect}");
            }
            Console.WriteLine();
            
            // Lucky Colors
            Console.WriteLine("🎨 LUCKY COLORS:");
            Console.WriteLine($"   {string.Join(", ", weather.LuckyColors)}");
            Console.WriteLine();
            
            // Recommended Activities
            Console.WriteLine("✨ RECOMMENDED ACTIVITIES:");
            foreach (var activity in weather.BestActivities.Take(4))
            {
                Console.WriteLine($"   • {activity}");
            }
            Console.WriteLine();
            
            // Caution Areas
            Console.WriteLine("⚠️  AREAS OF CAUTION:");
            foreach (var caution in weather.CautionAreas)
            {
                Console.WriteLine($"   • {caution}");
            }
            Console.WriteLine();
            
            // Spiritual Weather
            Console.WriteLine("🧘 SPIRITUAL CONDITIONS:");
            Console.WriteLine($"   {weather.SpiritualWeather}");
            Console.WriteLine();
            
            Console.WriteLine(new string('*', 70) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Could not retrieve astrological weather: {ex.Message}");
        }
    }
    
    private static async Task CreateAstrologicalCharacter()
    {
        Console.WriteLine("\n" + new string('=', 60));
        Console.WriteLine("              ASTROLOGICAL CHARACTER CREATION");
        Console.WriteLine(new string('=', 60));
        
        try
        {
            Console.Write("Enter character name: ");
            var name = Console.ReadLine();
            if (string.IsNullOrEmpty(name)) return;
            
            Console.Write("Enter birth date (YYYY-MM-DD): ");
            var birthDateStr = Console.ReadLine();
            if (!DateTime.TryParse(birthDateStr, out var birthDate)) return;
            
            Console.Write("Enter birth time (HH:MM): ");
            var birthTimeStr = Console.ReadLine();
            if (!TimeSpan.TryParse(birthTimeStr, out var birthTime)) return;
            
            Console.Write("Enter birth location: ");
            var birthLocation = Console.ReadLine() ?? "";
            
            var character = await _astroCreator!.CreateCharacterAsync(name, birthDate, birthTime, birthLocation);
            _createdCharacters.Add(character);
            
            Console.WriteLine($"\n✨ Created astrological character: {character.Name}");
            Console.WriteLine($"📊 Calculation Method: {character.CalculationMethod}");
            Console.WriteLine();
            
            // Body Traits (Tropical)
            Console.WriteLine("🌞 BODY CHARACTERISTICS (Tropical Astrology):");
            Console.WriteLine($"   Sign: {character.BodyTraits.ZodiacSign} ({character.BodyTraits.Element} {character.BodyTraits.Quality})");
            Console.WriteLine($"   Physical Strength: {character.BodyTraits.PhysicalStrength}/100");
            Console.WriteLine($"   Constitution: {character.BodyTraits.Constitution}/100");
            Console.WriteLine($"   Agility: {character.BodyTraits.Agility}/100");
            Console.WriteLine($"   Endurance: {character.BodyTraits.Endurance}/100");
            Console.WriteLine();
            
            // Mind Traits (Sidereal)
            Console.WriteLine("🧠 MIND CHARACTERISTICS (Sidereal Astrology):");
            Console.WriteLine($"   Sidereal Sign: {character.MindTraits.SiderealSign}");
            Console.WriteLine($"   Nakshatra: {character.MindTraits.Nakshatra}");
            Console.WriteLine($"   Current Dasha: {character.MindTraits.Dasha}");
            Console.WriteLine($"   Intellect: {character.MindTraits.Intellect}/100");
            Console.WriteLine($"   Intuition: {character.MindTraits.Intuition}/100");
            Console.WriteLine($"   Focus: {character.MindTraits.Focus}/100");
            Console.WriteLine($"   Creativity: {character.MindTraits.Creativity}/100");
            Console.WriteLine();
            
            // Heart Traits (Draconian)
            Console.WriteLine("💖 HEART CHARACTERISTICS (Draconian Astrology):");
            Console.WriteLine($"   North Node: {character.HeartTraits.NorthNode}");
            Console.WriteLine($"   South Node: {character.HeartTraits.SouthNode}");
            Console.WriteLine($"   Dragon Energy: {character.HeartTraits.DragonEnergy}");
            Console.WriteLine($"   Emotional Depth: {character.HeartTraits.EmotionalDepth}/100");
            Console.WriteLine($"   Passion: {character.HeartTraits.Passion}/100");
            Console.WriteLine($"   Empathy: {character.HeartTraits.Empathy}/100");
            Console.WriteLine($"   Soul Purpose: {character.HeartTraits.SoulPurpose}");
            Console.WriteLine();
            
            Console.WriteLine(new string('=', 60) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Could not create astrological character: {ex.Message}");
        }
    }
    
    private static void ListCreatedCharacters()
    {
        if (!_createdCharacters.Any())
        {
            Console.WriteLine("\n📖 No astrological characters have been created yet.");
            Console.WriteLine("Use 'createchar' to create your first character for dream experiences!\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('=', 50));
        Console.WriteLine("           CREATED ASTROLOGICAL CHARACTERS");
        Console.WriteLine(new string('=', 50));
        
        for (int i = 0; i < _createdCharacters.Count; i++)
        {
            var character = _createdCharacters[i];
            Console.WriteLine($"{i + 1}. {character.Name}");
            Console.WriteLine($"   Born: {character.BirthDate:yyyy-MM-dd} at {character.BirthTime}");
            Console.WriteLine($"   Location: {character.BirthLocation}");
            Console.WriteLine($"   Body: {character.BodyTraits.ZodiacSign} ({character.BodyTraits.Element})");
            Console.WriteLine($"   Mind: {character.MindTraits.Nakshatra} (Sidereal {character.MindTraits.SiderealSign})");
            Console.WriteLine($"   Heart: {character.HeartTraits.DragonEnergy}");
            Console.WriteLine();
        }
        Console.WriteLine(new string('=', 50) + "\n");
    }
    
    private static async Task StartDreamSequence()
    {
        if (!_createdCharacters.Any())
        {
            Console.WriteLine("\n🌙 No characters available for dream sequences.");
            Console.WriteLine("Create a character first with 'createchar' command.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('~', 60));
        Console.WriteLine("                 ENTER THE DREAM REALM");
        Console.WriteLine(new string('~', 60));
        
        try
        {
            // Let user choose a character
            Console.WriteLine("Available characters for dream experience:");
            for (int i = 0; i < _createdCharacters.Count; i++)
            {
                var character = _createdCharacters[i];
                Console.WriteLine($"{i + 1}. {character.Name} ({character.BodyTraits.ZodiacSign}/{character.MindTraits.Nakshatra}/{character.HeartTraits.DragonEnergy})");
            }
            
            Console.Write("\nSelect character (enter number): ");
            var selection = Console.ReadLine();
            
            if (!int.TryParse(selection, out var charIndex) || charIndex < 1 || charIndex > _createdCharacters.Count)
            {
                Console.WriteLine("Invalid selection. Dream fades away...\n");
                return;
            }
            
            var selectedCharacter = _createdCharacters[charIndex - 1];
            Console.WriteLine($"\n🌙 {selectedCharacter.Name} drifts into deep sleep...\n");
            
            // Generate the dream
            var dream = await _dreamEngine!.GenerateDreamSequence(selectedCharacter);
            
            // Display dream setting and narrative
            Console.WriteLine("═══ DREAM REALM OPENS ═══");
            Console.WriteLine($"✧ Dream Type: {dream.DreamType}");
            Console.WriteLine($"✧ Astrological Resonance: {dream.AstrologicalResonance}% ");
            Console.WriteLine();
            
            Console.WriteLine("🏺 SETTING:");
            Console.WriteLine($"   {dream.Setting.Description}");
            Console.WriteLine($"   Atmosphere: {dream.Setting.AmbientMood}");
            Console.WriteLine();
            
            Console.WriteLine("📜 COSMIC INFLUENCES:");
            foreach (var influence in dream.CosmicInfluences)
            {
                Console.WriteLine($"   ★ {influence}");
            }
            Console.WriteLine();
            
            // Show narrative
            Console.WriteLine("🌟 THE DREAM UNFOLDS:");
            foreach (var narrativeLine in dream.Narrative)
            {
                Console.WriteLine($"   {narrativeLine}");
                await Task.Delay(1000); // Pause for dramatic effect
            }
            Console.WriteLine();
            
            // Present choices
            Console.WriteLine("⚡ THE MOMENT OF CHOICE ARRIVES:");
            for (int i = 0; i < dream.AvailableChoices.Count; i++)
            {
                var choice = dream.AvailableChoices[i];
                Console.WriteLine($"{i + 1}. [{choice.ChoiceType}] {choice.Description}");
                Console.WriteLine($"   → {choice.PotentialOutcome}");
            }
            
            Console.Write("\nWhat does your character choose? (enter number): ");
            var choiceInput = Console.ReadLine();
            
            if (!int.TryParse(choiceInput, out var choiceIndex) || choiceIndex < 1 || choiceIndex > dream.AvailableChoices.Count)
            {
                Console.WriteLine("\nIndecision causes the dream to fade into mist...\n");
                return;
            }
            
            // Process the choice
            var consequence = _dreamEngine.ProcessDreamChoice(dream, choiceIndex - 1, selectedCharacter);
            
            Console.WriteLine("\n🌠 DREAM CONSEQUENCE:");
            Console.WriteLine($"   {consequence.Description}");
            Console.WriteLine($"   Effect: {consequence.EffectType}");
            Console.WriteLine($"   Resonance Gained: +{consequence.ResonanceGained}");
            Console.WriteLine($"   New Insight: {consequence.NewInsight}");
            Console.WriteLine();
            
            Console.WriteLine("🌄 The dream slowly fades as consciousness returns...");
            Console.WriteLine($"   {selectedCharacter.Name} awakens with new understanding.");
            Console.WriteLine(new string('~', 60) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Dream sequence interrupted: {ex.Message}");
        }
    }
    
    private static async Task CreateTamagotchiAgent()
    {
        if (!_createdCharacters.Any())
        {
            Console.WriteLine("\n🤖 No characters available to convert to agents.");
            Console.WriteLine("Create a character first with 'createchar' command.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('*', 60));
        Console.WriteLine("              CREATE TAMAGOTCHI AGENT");
        Console.WriteLine(new string('*', 60));
        
        try
        {
            Console.WriteLine("Available characters to convert to Tamagotchi agents:");
            for (int i = 0; i < _createdCharacters.Count; i++)
            {
                var character = _createdCharacters[i];
                Console.WriteLine($"{i + 1}. {character.Name} ({character.BodyTraits.ZodiacSign}/{character.MindTraits.Nakshatra}/{character.HeartTraits.DragonEnergy})");
            }
            
            Console.Write("\nSelect character to make into Tamagotchi (enter number): ");
            var selection = Console.ReadLine();
            
            if (!int.TryParse(selection, out var charIndex) || charIndex < 1 || charIndex > _createdCharacters.Count)
            {
                Console.WriteLine("Invalid selection. Agent creation cancelled.\n");
                return;
            }
            
            var selectedCharacter = _createdCharacters[charIndex - 1];
            var agent = _tamagotchiEngine!.CreateAgent(selectedCharacter);
            
            Console.WriteLine($"\n🐾 Created Tamagotchi agent: {agent.Name}");
            Console.WriteLine($"   Agent ID: {agent.Id[..8]}...");
            Console.WriteLine($"   DNA: {agent.DNA.PrimaryElement} + {agent.DNA.SecondaryElement}");
            Console.WriteLine($"   Energy: {agent.Energy}% | Happiness: {agent.Happiness}% | Health: {agent.Health}%");
            Console.WriteLine();
            Console.WriteLine("AGENT TRAITS:");
            foreach (var trait in agent.Traits)
            {
                Console.WriteLine($"   {trait.Key}: {trait.Value}/100");
            }
            Console.WriteLine();
            Console.WriteLine("ACTIVE GATES:");
            foreach (var gate in agent.Gates.Where(g => g.Value))
            {
                Console.WriteLine($"   ✨ {gate.Key.Replace("_", " ")}");
            }
            Console.WriteLine();
            Console.WriteLine("Your Tamagotchi is ready for care!");
            Console.WriteLine("Commands: 'care' to interact, 'status' to check wellbeing");
            Console.WriteLine(new string('*', 60) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Could not create Tamagotchi agent: {ex.Message}");
        }
    }
    
    private static async Task CareForTamagotchi()
    {
        var agents = _tamagotchiEngine!.GetActiveAgents();
        
        if (!agents.Any())
        {
            Console.WriteLine("\n🐾 No Tamagotchi agents available for care.");
            Console.WriteLine("Create one first with 'tamagotchi' command.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('=', 50));
        Console.WriteLine("                CARE FOR YOUR TAMAGOTCHI");
        Console.WriteLine(new string('=', 50));
        
        try
        {
            // Select agent
            Console.WriteLine("Your Tamagotchi agents:");
            for (int i = 0; i < agents.Count; i++)
            {
                var agent = agents[i];
                Console.WriteLine($"{i + 1}. {agent.Name} - {agent.CurrentMood} (E:{agent.Energy}% H:{agent.Happiness}% Hp:{agent.Health}%)");
            }
            
            Console.Write("\nSelect Tamagotchi to care for (enter number): ");
            var agentSelection = Console.ReadLine();
            
            if (!int.TryParse(agentSelection, out var agentIndex) || agentIndex < 1 || agentIndex > agents.Count)
            {
                Console.WriteLine("Invalid selection. Care cancelled.\n");
                return;
            }
            
            var selectedAgent = agents[agentIndex - 1];
            var status = _tamagotchiEngine.GetAgentStatus(selectedAgent.Id);
            
            if (status.Found)
            {
                Console.WriteLine($"\n{status.CurrentExpression}");
                Console.WriteLine($"{status.VoiceLine}");
                Console.WriteLine($"Aura: {status.MoodAura}");
                Console.WriteLine();
            }
            
            // Show care options
            Console.WriteLine("Care actions available:");
            Console.WriteLine("1. Feed - Restore energy and health");
            Console.WriteLine("2. Play - Increase happiness");
            Console.WriteLine("3. Rest - Restore energy");
            Console.WriteLine("4. Meditate - Increase cosmic resonance");
            Console.WriteLine("5. Learn - Boost evolution");
            
            Console.Write("\nWhat care do you want to give? (enter number): ");
            var careChoice = Console.ReadLine();
            
            var careAction = careChoice switch
            {
                "1" => CareAction.Feed,
                "2" => CareAction.Play,
                "3" => CareAction.Rest,
                "4" => CareAction.Meditate,
                "5" => CareAction.Learn,
                _ => CareAction.Play
            };
            
            Console.WriteLine($"\n💝 Giving {careAction} to {selectedAgent.Name}...");
            var result = await _tamagotchiEngine.CareForAgent(selectedAgent.Id, careAction);
            
            Console.WriteLine($"✨ {result.Message}");
            
            if (result.EnergyChange != 0) Console.WriteLine($"   Energy: {(result.EnergyChange > 0 ? "+" : "")}{result.EnergyChange}");
            if (result.HappinessChange != 0) Console.WriteLine($"   Happiness: {(result.HappinessChange > 0 ? "+" : "")}{result.HappinessChange}");
            if (result.HealthChange != 0) Console.WriteLine($"   Health: {(result.HealthChange > 0 ? "+" : "")}{result.HealthChange}");
            if (result.ResonanceChange != 0) Console.WriteLine($"   Resonance: {(result.ResonanceChange > 0 ? "+" : "")}{result.ResonanceChange}");
            if (result.EvolutionChange != 0) Console.WriteLine($"   Evolution: {(result.EvolutionChange > 0 ? "+" : "")}{result.EvolutionChange}");
            
            if (result.EvolutionOccurred)
            {
                Console.WriteLine($"\n🌟 EVOLUTION! 🌟");
                Console.WriteLine($"   {result.EvolutionDescription}");
            }
            
            Console.WriteLine(new string('=', 50) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Could not care for Tamagotchi: {ex.Message}");
        }
    }
    
    private static void CheckTamagotchiStatus()
    {
        var agents = _tamagotchiEngine!.GetActiveAgents();
        
        if (!agents.Any())
        {
            Console.WriteLine("\n🐾 No Tamagotchi agents to check.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('-', 60));
        Console.WriteLine("                  TAMAGOTCHI STATUS");
        Console.WriteLine(new string('-', 60));
        
        foreach (var agent in agents)
        {
            var status = _tamagotchiEngine.GetAgentStatus(agent.Id);
            
            if (status.Found && status.Agent != null)
            {
                Console.WriteLine($"🐾 {agent.Name} (Age: {agent.Age:F1} cosmic cycles)");
                Console.WriteLine($"   {status.CurrentExpression}");
                Console.WriteLine($"   \"{status.VoiceLine}\"");
                Console.WriteLine($"   Aura: {status.MoodAura}");
                Console.WriteLine($"   Stats: E:{agent.Energy}% H:{agent.Happiness}% Hp:{agent.Health}% R:{agent.Resonance}%");
                Console.WriteLine($"   Evolution: {agent.Evolution}/100 {(agent.Evolution >= 80 ? "⚡ Ready to evolve!" : "")}");
                Console.WriteLine($"   DNA: {agent.DNA.PrimaryElement} + {agent.DNA.SecondaryElement}");
                
                if (status.NeedsAttention)
                {
                    Console.WriteLine($"   ⚠️  Needs attention! (Last cared for {status.TimeSinceLastCare.TotalHours:F1}h ago)");
                }
                
                Console.WriteLine();
            }
        }
        
        Console.WriteLine(new string('-', 60) + "\n");
    }
    
    private static async Task WriteJournalEntry()
    {
        var agents = _tamagotchiEngine!.GetActiveAgents();
        
        if (!agents.Any())
        {
            Console.WriteLine("\n📓 No Tamagotchi agents to reflect with.");
            Console.WriteLine("Create one first with 'tamagotchi' command.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('~', 60));
        Console.WriteLine("             📓 CYNTHIA'S NOTEBOOK 📓");
        Console.WriteLine("        Journal entries affect your agent!");
        Console.WriteLine(new string('~', 60));
        
        try
        {
            // Select agent if multiple
            TamagotchiAgent selectedAgent;
            if (agents.Count == 1)
            {
                selectedAgent = agents[0];
            }
            else
            {
                Console.WriteLine("Which agent should reflect on your journal entry?");
                for (int i = 0; i < agents.Count; i++)
                {
                    var agent = agents[i];
                    Console.WriteLine($"{i + 1}. {agent.Name} (Resonance: {agent.Resonance}%)");
                }
                
                Console.Write("\nSelect agent (enter number): ");
                var selection = Console.ReadLine();
                
                if (!int.TryParse(selection, out var index) || index < 1 || index > agents.Count)
                {
                    Console.WriteLine("Invalid selection. Journal cancelled.\n");
                    return;
                }
                
                selectedAgent = agents[index - 1];
            }
            
            // Get journal entry
            Console.WriteLine($"\n✨ {selectedAgent.Name} awaits your words...");
            Console.WriteLine("Write your journal entry (your emotions will affect your agent):");
            Console.WriteLine("Examples: 'tired', 'love', 'dream', 'stressed', 'grateful'");
            Console.Write("\n📝 Your entry: ");
            
            var journalEntry = Console.ReadLine();
            
            if (string.IsNullOrWhiteSpace(journalEntry))
            {
                Console.WriteLine("Empty thoughts create no ripples. Try again.\n");
                return;
            }
            
            // Apply reflection
            Console.WriteLine($"\n🌟 {selectedAgent.Name} is reflecting on your words...");
            var result = _tamagotchiEngine.ApplyNotebookReflection(selectedAgent.Id, journalEntry);
            
            if (result.Success)
            {
                Console.WriteLine($"\n💫 {result.Message}");
                Console.WriteLine();
                
                // Show changes
                if (result.Changes.Any())
                {
                    Console.WriteLine("📊 Reflection Effects:");
                    foreach (var change in result.Changes)
                    {
                        Console.WriteLine($"   • {change}");
                    }
                }
                else
                {
                    Console.WriteLine("📊 Your agent acknowledges your words but remains stable.");
                }
                
                // Show current state
                var status = _tamagotchiEngine.GetAgentStatus(selectedAgent.Id);
                if (status.Found)
                {
                    Console.WriteLine($"\n{status.CurrentExpression}");
                    Console.WriteLine($"\"{status.VoiceLine}\"");
                    Console.WriteLine($"Aura: {status.MoodAura}");
                }
                
                Console.WriteLine($"\nReflection intensity: {result.Intensity}%");
            }
            else
            {
                Console.WriteLine($"❌ {result.Message}");
            }
            
            Console.WriteLine(new string('~', 60) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Journal reflection failed: {ex.Message}");
        }
    }
    
    private static void CheckAgentResonance()
    {
        var agents = _tamagotchiEngine!.GetActiveAgents();
        
        if (!agents.Any())
        {
            Console.WriteLine("\n🔮 No agents to check resonance.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('◦', 60));
        Console.WriteLine("               🔮 AGENT RESONANCE REPORT 🔮");
        Console.WriteLine(new string('◦', 60));
        
        foreach (var agent in agents)
        {
            var report = _tamagotchiEngine.GetResonanceReport(agent.Id);
            
            if (report.Success)
            {
                Console.WriteLine($"\n🌟 {report.AgentName}");
                Console.WriteLine($"   Resonance: {report.CurrentResonance}% - {report.ResonanceDescription}");
                Console.WriteLine($"   Emotional State: {report.EmotionalState}");
                Console.WriteLine($"   Aura: {report.ResonanceAura}");
                
                Console.WriteLine("\n   📝 Suggested journal themes:");
                foreach (var theme in report.SuggestedJournalThemes)
                {
                    Console.WriteLine($"      • {theme}");
                }
            }
        }
        
        Console.WriteLine("\n💡 Tip: Use 'journal' command to write entries that affect your agent!");
        Console.WriteLine(new string('◦', 60) + "\n");
    }
    
    private static async Task DropIntoScenario()
    {
        var agents = _agentEngine!.GetActiveAgents();
        if (!agents.Any())
        {
            Console.WriteLine("\n🎭 No autonomous agents available for scenarios.");
            Console.WriteLine("Create an agent first with 'createagent' command.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('#', 70));
        Console.WriteLine("                  SCENARIO INJECTION SYSTEM");
        Console.WriteLine("             (Drop Agent into Life Situation)");
        Console.WriteLine(new string('#', 70));
        
        try
        {
            // Select agent
            Console.WriteLine("Available autonomous agents:");
            for (int i = 0; i < agents.Count; i++)
            {
                var agent = agents[i];
                Console.WriteLine($"{i + 1}. {agent.Name} (Energy: {agent.Energy}%, State: {agent.CurrentState})");
            }
            
            Console.Write("\nSelect agent (enter number): ");
            var agentSelection = Console.ReadLine();
            
            if (!int.TryParse(agentSelection, out var agentIndex) || agentIndex < 1 || agentIndex > agents.Count)
            {
                Console.WriteLine("Invalid selection. Scenario cancelled.\n");
                return;
            }
            
            var selectedAgent = agents[agentIndex - 1];
            
            // Choose scenario type
            Console.WriteLine("\nAvailable scenario categories:");
            Console.WriteLine("1. Work Challenge (deadline pressure, team conflicts)");
            Console.WriteLine("2. Relationship Test (conflict resolution, communication)"); 
            Console.WriteLine("3. Personal Crisis (major decision, life change)");
            Console.WriteLine("4. Financial Pressure (resource management, tough choices)");
            Console.WriteLine("5. Creative Challenge (innovation under constraints)");
            Console.WriteLine("6. Custom Scenario (enter your own)");
            
            Console.Write("\nSelect scenario type (enter number): ");
            var scenarioChoice = Console.ReadLine();
            
            LifeScenario scenario = scenarioChoice switch
            {
                "1" => CreateWorkScenario(),
                "2" => CreateRelationshipScenario(),
                "3" => CreatePersonalCrisisScenario(),
                "4" => CreateFinancialScenario(),
                "5" => CreateCreativeScenario(),
                "6" => CreateCustomScenario(),
                _ => CreateWorkScenario()
            };
            
            Console.WriteLine($"\n🎬 DROPPING {selectedAgent.Name.ToUpper()} INTO SCENARIO...");
            Console.WriteLine($"📋 Scenario: {scenario.Title}");
            Console.WriteLine($"📝 Description: {scenario.Description}");
            Console.WriteLine($"⚡ Difficulty: {scenario.DifficultyLevel}/100");
            Console.WriteLine($"🎯 Target Skills: {string.Join(", ", scenario.TargetSkills)}");
            Console.WriteLine();
            
            // Start autonomous experience
            var experience = await _agentEngine.DropAgentIntoScenario(selectedAgent.Id, scenario);
            
            Console.WriteLine("🤖 AGENT IS NOW ACTING AUTONOMOUSLY!");
            Console.WriteLine("The agent will make decisions based on their astrological traits.");
            Console.WriteLine("You can provide guidance but cannot control directly.");
            Console.WriteLine();
            Console.WriteLine("Available commands while agent is active:");
            Console.WriteLine("  'guidance' - Provide nudging guidance to the agent");
            Console.WriteLine("  'agents'   - Check agent status");
            Console.WriteLine();
            Console.WriteLine("Watch the console for autonomous decision updates...");
            Console.WriteLine(new string('#', 70) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Could not start scenario: {ex.Message}");
        }
    }
    
    private static async Task ProvideAgentGuidance()
    {
        var agents = _agentEngine!.GetActiveAgents().Where(a => a.CurrentState == AgentState.InScenario).ToList();
        
        if (!agents.Any())
        {
            Console.WriteLine("\n💭 No agents currently in scenarios to guide.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('-', 50));
        Console.WriteLine("           PROVIDE AGENT GUIDANCE");
        Console.WriteLine(new string('-', 50));
        
        try
        {
            // Select agent to guide
            Console.WriteLine("Agents currently in scenarios:");
            for (int i = 0; i < agents.Count; i++)
            {
                var agent = agents[i];
                Console.WriteLine($"{i + 1}. {agent.Name} - {agent.CurrentScenario?.Title}");
                Console.WriteLine($"   Receptivity: {agent.GuidanceReceptivity}% | Energy: {agent.Energy}%");
            }
            
            Console.Write("\nSelect agent to guide (enter number): ");
            var agentSelection = Console.ReadLine();
            
            if (!int.TryParse(agentSelection, out var agentIndex) || agentIndex < 1 || agentIndex > agents.Count)
            {
                Console.WriteLine("Invalid selection. Guidance cancelled.\n");
                return;
            }
            
            var selectedAgent = agents[agentIndex - 1];
            
            // Choose guidance type
            Console.WriteLine("\nGuidance types:");
            Console.WriteLine("1. Suggestion - Gentle recommendation");
            Console.WriteLine("2. Warning - Alert about potential risks");
            Console.WriteLine("3. Encouragement - Boost confidence");
            Console.WriteLine("4. Redirection - Suggest different approach");
            
            Console.Write("\nSelect guidance type (enter number): ");
            var guidanceTypeChoice = Console.ReadLine();
            
            var guidanceType = guidanceTypeChoice switch
            {
                "1" => GuidanceType.Suggestion,
                "2" => GuidanceType.Warning,
                "3" => GuidanceType.Encouragement,
                "4" => GuidanceType.Redirection,
                _ => GuidanceType.Suggestion
            };
            
            Console.Write("\nEnter your guidance message: ");
            var guidanceText = Console.ReadLine() ?? "";
            
            if (string.IsNullOrEmpty(guidanceText))
            {
                Console.WriteLine("No guidance provided. Cancelled.\n");
                return;
            }
            
            // Provide guidance
            var result = _agentEngine.ProvideGuidance(selectedAgent.Id, guidanceText, guidanceType);
            
            Console.WriteLine($"\n📡 GUIDANCE SENT TO {selectedAgent.Name}:");
            Console.WriteLine($"   Your message: \"{guidanceText}\"");
            Console.WriteLine($"   Compliance Level: {result.ComplianceLevel}%");
            Console.WriteLine($"   Agent Response: \"{result.Message}\"");
            Console.WriteLine();
            
            if (result.ComplianceLevel > 70)
            {
                Console.WriteLine("✅ The agent is likely to follow your guidance.");
            }
            else if (result.ComplianceLevel > 40)
            {
                Console.WriteLine("⚠️  The agent may partially consider your guidance.");
            }
            else
            {
                Console.WriteLine("❌ The agent is likely to ignore your guidance and follow their instincts.");
            }
            
            Console.WriteLine("\nRemember: You can guide, but the agent maintains autonomy!");
            Console.WriteLine(new string('-', 50) + "\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Could not provide guidance: {ex.Message}");
        }
    }
    
    private static void ListActiveAgents()
    {
        var agents = _agentEngine!.GetActiveAgents();
        
        if (!agents.Any())
        {
            Console.WriteLine("\n🤖 No active autonomous agents.\n");
            return;
        }
        
        Console.WriteLine("\n" + new string('=', 60));
        Console.WriteLine("                ACTIVE AUTONOMOUS AGENTS");
        Console.WriteLine(new string('=', 60));
        
        foreach (var agent in agents)
        {
            Console.WriteLine($"Agent: {agent.Name} (ID: {agent.Id[..8]}...)");
            Console.WriteLine($"  State: {agent.CurrentState} | Energy: {agent.Energy}% | Experience: {agent.TotalExperience}");
            Console.WriteLine($"  Guidance Receptivity: {agent.GuidanceReceptivity}% | Autonomy: {agent.Autonomy}%");
            
            if (agent.CurrentScenario != null)
            {
                Console.WriteLine($"  Current Scenario: {agent.CurrentScenario.Title}");
                Console.WriteLine($"  Difficulty: {agent.CurrentScenario.DifficultyLevel}/100");
            }
            
            Console.WriteLine($"  Top Skills: " + string.Join(", ", 
                agent.Skills.OrderByDescending(s => s.Value).Take(3).Select(s => $"{s.Key}:{s.Value}")));
            Console.WriteLine();
        }
        
        Console.WriteLine(new string('=', 60) + "\n");
    }
    
    #region Scenario Creation Methods
    
    private static LifeScenario CreateWorkScenario()
    {
        return new LifeScenario
        {
            Title = "Critical Project Deadline Crisis",
            Description = "Your most important project is behind schedule, the client is demanding answers, and your team is overwhelmed. Multiple stakeholders are pulling you in different directions.",
            Category = "Work",
            DifficultyLevel = 75,
            TargetSkills = new List<SkillType> { SkillType.Leadership, SkillType.ProblemSolving, SkillType.Communication },
            TimeLimit = TimeSpan.FromMinutes(15),
            SuccessMetrics = new List<string> { "Team morale maintained", "Deadline negotiated", "Quality preserved" },
            Challenges = new List<string> { "Conflicting priorities", "Resource constraints", "Stakeholder pressure" },
            ContextualFactors = new Dictionary<string, string>
            {
                {"TimeOfDay", "Late evening"},
                {"StressLevel", "Extremely high"},
                {"TeamMorale", "Low"},
                {"ClientExpectation", "Unrealistic"}
            }
        };
    }
    
    private static LifeScenario CreateRelationshipScenario()
    {
        return new LifeScenario
        {
            Title = "Major Relationship Conflict Resolution",
            Description = "A significant disagreement with someone important to you has escalated. Both sides feel misunderstood and hurt. The relationship hangs in the balance.",
            Category = "Relationships", 
            DifficultyLevel = 80,
            TargetSkills = new List<SkillType> { SkillType.EmotionalIntelligence, SkillType.Communication, SkillType.Empathy },
            TimeLimit = TimeSpan.FromMinutes(20),
            SuccessMetrics = new List<string> { "Mutual understanding achieved", "Emotions managed", "Path forward agreed" },
            Challenges = new List<string> { "High emotions", "Past grievances", "Communication breakdown" },
            ContextualFactors = new Dictionary<string, string>
            {
                {"EmotionalIntensity", "Very high"},
                {"HistoryTogether", "Long-term"},
                {"SupportSystem", "Limited"},
                {"PublicVisibility", "Private but significant"}
            }
        };
    }
    
    private static LifeScenario CreatePersonalCrisisScenario()
    {
        return new LifeScenario
        {
            Title = "Life-Changing Decision Point",
            Description = "You face a major life decision that will impact your future dramatically. Multiple paths are available, each with significant pros and cons. Time is running out to choose.",
            Category = "Personal",
            DifficultyLevel = 85,
            TargetSkills = new List<SkillType> { SkillType.ProblemSolving, SkillType.Resilience, SkillType.Adaptability },
            TimeLimit = TimeSpan.FromMinutes(25),
            SuccessMetrics = new List<string> { "Decision aligned with values", "Future consequences considered", "Peace with choice" },
            Challenges = new List<string> { "Uncertainty about outcomes", "Conflicting advice", "Fear of regret" },
            ContextualFactors = new Dictionary<string, string>
            {
                {"Stakes", "Life-altering"},
                {"TimeToDecide", "Very limited"},
                {"Information", "Incomplete"},
                {"SupportLevel", "Mixed opinions"}
            }
        };
    }
    
    private static LifeScenario CreateFinancialScenario()
    {
        return new LifeScenario
        {
            Title = "Financial Crisis Management",
            Description = "Unexpected financial pressures have created a crisis. Resources are scarce, obligations are mounting, and tough decisions must be made quickly.",
            Category = "Financial",
            DifficultyLevel = 70,
            TargetSkills = new List<SkillType> { SkillType.ProblemSolving, SkillType.Resilience, SkillType.Leadership },
            TimeLimit = TimeSpan.FromMinutes(18),
            SuccessMetrics = new List<string> { "Essential needs secured", "Long-term impact minimized", "Dignity maintained" },
            Challenges = new List<string> { "Limited resources", "Multiple obligations", "Time pressure" },
            ContextualFactors = new Dictionary<string, string>
            {
                {"FinancialPressure", "Extreme"},
                {"Options", "Limited"},
                {"Timeline", "Urgent"},
                {"ImpactOnOthers", "Significant"}
            }
        };
    }
    
    private static LifeScenario CreateCreativeScenario()
    {
        return new LifeScenario
        {
            Title = "Creative Block Breakthrough Challenge",
            Description = "You're facing a creative challenge with high stakes. Innovation is required, but inspiration feels blocked. Traditional solutions won't work.",
            Category = "Creative",
            DifficultyLevel = 65,
            TargetSkills = new List<SkillType> { SkillType.Creativity, SkillType.ProblemSolving, SkillType.Adaptability },
            TimeLimit = TimeSpan.FromMinutes(22),
            SuccessMetrics = new List<string> { "Original solution found", "Creative flow restored", "Innovation achieved" },
            Challenges = new List<string> { "Mental blocks", "Pressure to perform", "Unconventional requirements" },
            ContextualFactors = new Dictionary<string, string>
            {
                {"CreativePressure", "High"},
                {"Originality", "Required"},
                {"Resources", "Unlimited imagination, limited tools"},
                {"Audience", "Expecting brilliance"}
            }
        };
    }
    
    private static LifeScenario CreateCustomScenario()
    {
        Console.Write("Enter scenario title: ");
        var title = Console.ReadLine() ?? "Custom Challenge";
        
        Console.Write("Enter description: ");
        var description = Console.ReadLine() ?? "A personalized challenge";
        
        Console.Write("Enter difficulty (1-100): ");
        var difficultyStr = Console.ReadLine();
        var difficulty = int.TryParse(difficultyStr, out var d) ? Math.Max(1, Math.Min(100, d)) : 50;
        
        return new LifeScenario
        {
            Title = title,
            Description = description,
            Category = "Custom",
            DifficultyLevel = difficulty,
            TargetSkills = new List<SkillType> { SkillType.Adaptability, SkillType.ProblemSolving },
            TimeLimit = TimeSpan.FromMinutes(20),
            SuccessMetrics = new List<string> { "Challenge overcome", "Growth achieved" },
            Challenges = new List<string> { "Unique circumstances", "Personal adaptation required" },
            ContextualFactors = new Dictionary<string, string>
            {
                {"CustomChallenge", "User-defined"},
                {"PersonalRelevance", "High"}
            }
        };
    }
    
    #endregion
}
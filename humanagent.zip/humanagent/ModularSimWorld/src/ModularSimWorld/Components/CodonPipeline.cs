using System.Text.Json;

namespace ModularSimWorld.Components;

/// <summary>
/// 64-Codon "Elephant in the Fridge" Pipeline System
/// Each codon represents a spectrum of life events broken into simple archetypal steps
/// Using elemental codon logic for gaming mechanics
/// </summary>
public class CodonPipelineEngine
{
    private readonly Dictionary<int, CodonQuest> _codonQuests;
    private readonly Dictionary<ElementalType, CodonElement> _elementalLogic;
    private readonly Random _random;

    public CodonPipelineEngine()
    {
        _random = new Random();
        _codonQuests = InitializeCodonQuests();
        _elementalLogic = InitializeElementalLogic();
        Console.WriteLine("[Codon] 64-Codon Pipeline initialized with elemental logic");
    }

    /// <summary>
    /// Triggers a codon quest based on agent's current state and cosmic alignment
    /// Uses "elephant in the fridge" logic - simple sequential steps
    /// </summary>
    public CodonQuestResult TriggerCodonQuest(TamagotchiAgent agent, int? specificCodon = null)
    {
        // Determine which codon to activate
        var codonNumber = specificCodon ?? SelectCodonFromAgent(agent);
        var quest = _codonQuests[codonNumber];
        
        // Apply elemental logic based on agent's DNA
        var elementalModifier = GetElementalModifier(agent, quest);
        
        var result = new CodonQuestResult
        {
            CodonNumber = codonNumber,
            QuestTitle = quest.Title,
            Archetype = quest.Archetype,
            ElementalAlignment = agent.DNA.PrimaryElement,
            Steps = quest.Steps.ToList(),
            CurrentStep = 0,
            ElementalBonus = elementalModifier.Bonus,
            Difficulty = CalculateQuestDifficulty(agent, quest, elementalModifier),
            Description = quest.Description,
            Success = false
        };

        Console.WriteLine($"[Codon] Agent {agent.Name} triggered Codon {codonNumber}: {quest.Title}");
        Console.WriteLine($"[Codon] Elemental alignment: {elementalModifier.Description}");
        
        return result;
    }

    /// <summary>
    /// Processes a quest step - the "elephant in fridge" action
    /// </summary>
    public CodonStepResult ProcessQuestStep(string agentId, CodonQuestResult quest, QuestAction action)
    {
        if (quest.CurrentStep >= quest.Steps.Count)
            return new CodonStepResult { Success = false, Message = "Quest already completed!" };

        var currentStep = quest.Steps[quest.CurrentStep];
        var stepResult = ExecuteElephantStep(currentStep, action, quest.ElementalAlignment);
        
        if (stepResult.Success)
        {
            quest.CurrentStep++;
            quest.CompletedSteps.Add(currentStep.Description + " ✓");
            
            if (quest.CurrentStep >= quest.Steps.Count)
            {
                quest.Success = true;
                stepResult.QuestComplete = true;
                stepResult.QuestReward = CalculateQuestReward(quest);
            }
        }

        return stepResult;
    }

    /// <summary>
    /// Get available quest actions for current step
    /// </summary>
    public List<QuestAction> GetAvailableActions(CodonQuestResult quest)
    {
        if (quest.CurrentStep >= quest.Steps.Count) return new List<QuestAction>();
        
        var step = quest.Steps[quest.CurrentStep];
        return step.AvailableActions;
    }

    #region Codon Quest Initialization

    private Dictionary<int, CodonQuest> InitializeCodonQuests()
    {
        var quests = new Dictionary<int, CodonQuest>();
        
        // Fire Element Codons (1-16): Action & Transformation
        quests[1] = new CodonQuest
        {
            Number = 1,
            Title = "The Creative Force",
            Archetype = "Right Angle Cross of the Four Ways",
            Element = ElementalType.Fire,
            Description = "Your agent must ignite their creative fire through structured action.",
            Steps = new List<QuestStep>
            {
                new() { Description = "Gather scattered creative materials", ActionType = "Collect", AvailableActions = [QuestAction.Gather, QuestAction.Organize] },
                new() { Description = "Combine materials into unified vision", ActionType = "Create", AvailableActions = [QuestAction.Combine, QuestAction.Focus] },
                new() { Description = "Share creation with the world", ActionType = "Express", AvailableActions = [QuestAction.Share, QuestAction.Celebrate] }
            }
        };

        quests[13] = new CodonQuest
        {
            Number = 13,
            Title = "Fellowship of Universal Love",
            Archetype = "Left Angle Cross of Masks",
            Element = ElementalType.Fire,
            Description = "Your agent must learn authentic connection through the dance of masks.",
            Steps = new List<QuestStep>
            {
                new() { Description = "Put on the mask of the role you must play", ActionType = "Transform", AvailableActions = [QuestAction.Disguise, QuestAction.Adapt] },
                new() { Description = "Navigate challenge while wearing the mask", ActionType = "Navigate", AvailableActions = [QuestAction.Persist, QuestAction.Learn] },
                new() { Description = "Drop the mask and reveal authentic self", ActionType = "Reveal", AvailableActions = [QuestAction.Release, QuestAction.Embrace] }
            }
        };

        // Water Element Codons (17-32): Emotion & Flow
        quests[6] = new CodonQuest
        {
            Number = 6,
            Title = "Conflict Resolution",
            Archetype = "Cross of Sleeping Phoenix", 
            Element = ElementalType.Water,
            Description = "Your agent must navigate conflict to find deeper truth.",
            Steps = new List<QuestStep>
            {
                new() { Description = "Allow the old pattern to collapse gracefully", ActionType = "Release", AvailableActions = [QuestAction.Surrender, QuestAction.Accept] },
                new() { Description = "Enter the void of not-knowing", ActionType = "Wait", AvailableActions = [QuestAction.Rest, QuestAction.Reflect] },
                new() { Description = "Spark new understanding from the ashes", ActionType = "Rebirth", AvailableActions = [QuestAction.Create, QuestAction.Inspire] }
            }
        };

        // Earth Element Codons (33-48): Structure & Manifestation
        quests[52] = new CodonQuest
        {
            Number = 52,
            Title = "Keeping Still (Mountain)",
            Archetype = "Right Angle Cross of Planning",
            Element = ElementalType.Earth,
            Description = "Your agent must organize chaos into stable structure.",
            Steps = new List<QuestStep>
            {
                new() { Description = "Assess the chaotic situation calmly", ActionType = "Observe", AvailableActions = [QuestAction.Examine, QuestAction.Measure] },
                new() { Description = "Create a practical organizing system", ActionType = "Structure", AvailableActions = [QuestAction.Plan, QuestAction.Build] },
                new() { Description = "Implement the system with others", ActionType = "Collaborate", AvailableActions = [QuestAction.Teach, QuestAction.Guide] }
            }
        };

        // Air Element Codons (49-64): Mind & Communication
        quests[31] = new CodonQuest
        {
            Number = 31,
            Title = "Influence (Wooing)", 
            Archetype = "Cross of Alpha",
            Element = ElementalType.Air,
            Description = "Your agent must learn to influence through authentic magnetism.",
            Steps = new List<QuestStep>
            {
                new() { Description = "Align with your natural magnetic field", ActionType = "Attune", AvailableActions = [QuestAction.Meditate, QuestAction.Center] },
                new() { Description = "Attract what resonates with your frequency", ActionType = "Magnetize", AvailableActions = [QuestAction.Radiate, QuestAction.Welcome] },
                new() { Description = "Guide attracted elements into harmony", ActionType = "Harmonize", AvailableActions = [QuestAction.Balance, QuestAction.Unite] }
            }
        };

        // Fill in more codons...
        for (int i = 2; i <= 64; i++)
        {
            if (!quests.ContainsKey(i))
            {
                quests[i] = GenerateCodonTemplate(i);
            }
        }

        return quests;
    }

    private CodonQuest GenerateCodonTemplate(int codonNumber)
    {
        var element = GetElementFromCodonNumber(codonNumber);
        var archetypes = GetArchetypesForElement(element);
        
        return new CodonQuest
        {
            Number = codonNumber,
            Title = $"Codon {codonNumber}: {GetCodonName(codonNumber)}",
            Archetype = archetypes[_random.Next(archetypes.Length)],
            Element = element,
            Description = GetCodonDescription(codonNumber, element),
            Steps = GenerateElephantSteps(element)
        };
    }

    private ElementalType GetElementFromCodonNumber(int codon)
    {
        return codon switch
        {
            >= 1 and <= 16 => ElementalType.Fire,
            >= 17 and <= 32 => ElementalType.Water, 
            >= 33 and <= 48 => ElementalType.Earth,
            >= 49 and <= 64 => ElementalType.Air,
            _ => ElementalType.Fire
        };
    }

    private string[] GetArchetypesForElement(ElementalType element)
    {
        return element switch
        {
            ElementalType.Fire => ["Cross of the Four Ways", "Cross of Contagion", "Cross of Penetration", "Cross of Maya"],
            ElementalType.Water => ["Cross of Sleeping Phoenix", "Cross of the Vessel of Love", "Cross of Healing", "Cross of Service"], 
            ElementalType.Earth => ["Cross of Planning", "Cross of the Unexpected", "Cross of Rulership", "Cross of the Sphinx"],
            ElementalType.Air => ["Cross of Alpha", "Cross of Consciousness", "Cross of Explanation", "Cross of the Clarion"],
            _ => ["Cross of the Four Ways"]
        };
    }

    private List<QuestStep> GenerateElephantSteps(ElementalType element)
    {
        return element switch
        {
            ElementalType.Fire => new List<QuestStep>
            {
                new() { Description = "Ignite the spark of possibility", ActionType = "Initiate", AvailableActions = [QuestAction.Ignite, QuestAction.Begin] },
                new() { Description = "Channel energy into focused action", ActionType = "Direct", AvailableActions = [QuestAction.Focus, QuestAction.Act] },
                new() { Description = "Transform through the fire of experience", ActionType = "Transform", AvailableActions = [QuestAction.Change, QuestAction.Evolve] }
            },
            ElementalType.Water => new List<QuestStep>
            {
                new() { Description = "Flow around the obstacle", ActionType = "Adapt", AvailableActions = [QuestAction.Flow, QuestAction.Yield] },
                new() { Description = "Deepen into emotional truth", ActionType = "Feel", AvailableActions = [QuestAction.Embrace, QuestAction.Accept] },
                new() { Description = "Nourish all that touches you", ActionType = "Nurture", AvailableActions = [QuestAction.Heal, QuestAction.Support] }
            },
            ElementalType.Earth => new List<QuestStep>
            {
                new() { Description = "Build solid foundation", ActionType = "Ground", AvailableActions = [QuestAction.Build, QuestAction.Stabilize] },
                new() { Description = "Grow step by step", ActionType = "Develop", AvailableActions = [QuestAction.Cultivate, QuestAction.Progress] },
                new() { Description = "Manifest tangible results", ActionType = "Materialize", AvailableActions = [QuestAction.Complete, QuestAction.Deliver] }
            },
            ElementalType.Air => new List<QuestStep>
            {
                new() { Description = "Gather information and perspectives", ActionType = "Learn", AvailableActions = [QuestAction.Research, QuestAction.Question] },
                new() { Description = "Connect ideas into new patterns", ActionType = "Synthesize", AvailableActions = [QuestAction.Link, QuestAction.Innovate] },
                new() { Description = "Communicate insights clearly", ActionType = "Express", AvailableActions = [QuestAction.Teach, QuestAction.Share] }
            },
            _ => new List<QuestStep>()
        };
    }

    private Dictionary<ElementalType, CodonElement> InitializeElementalLogic()
    {
        return new Dictionary<ElementalType, CodonElement>
        {
            [ElementalType.Fire] = new CodonElement
            {
                Name = "Fire",
                Qualities = ["Initiating", "Transformative", "Energizing", "Pioneering"],
                Strengths = ["Quick action", "Creative breakthroughs", "Leadership", "Innovation"],
                Challenges = ["Impulsiveness", "Burnout", "Impatience", "Conflict"],
                BestActions = [QuestAction.Ignite, QuestAction.Lead, QuestAction.Create, QuestAction.Transform],
                Bonus = 1.3f
            },
            [ElementalType.Water] = new CodonElement
            {
                Name = "Water", 
                Qualities = ["Flowing", "Emotional", "Intuitive", "Healing"],
                Strengths = ["Adaptability", "Empathy", "Emotional intelligence", "Healing"],
                Challenges = ["Overwhelm", "Boundary issues", "Mood swings", "Indecision"],
                BestActions = [QuestAction.Flow, QuestAction.Heal, QuestAction.Feel, QuestAction.Nurture],
                Bonus = 1.2f
            },
            [ElementalType.Earth] = new CodonElement
            {
                Name = "Earth",
                Qualities = ["Grounding", "Practical", "Stable", "Nurturing"],
                Strengths = ["Reliability", "Persistence", "Planning", "Manifestation"],
                Challenges = ["Stubbornness", "Resistance to change", "Over-caution", "Materialism"],
                BestActions = [QuestAction.Build, QuestAction.Plan, QuestAction.Stabilize, QuestAction.Complete],
                Bonus = 1.25f
            },
            [ElementalType.Air] = new CodonElement
            {
                Name = "Air",
                Qualities = ["Mental", "Communicative", "Flexible", "Innovative"],
                Strengths = ["Communication", "Analysis", "Networking", "Innovation"],
                Challenges = ["Over-thinking", "Detachment", "Inconsistency", "Mental scatter"],
                BestActions = [QuestAction.Think, QuestAction.Communicate, QuestAction.Connect, QuestAction.Innovate],
                Bonus = 1.15f
            }
        };
    }

    #endregion

    #region Helper Methods

    private int SelectCodonFromAgent(TamagotchiAgent agent)
    {
        // Select codon based on agent's current state, DNA, and cosmic alignment
        var elementWeight = agent.DNA.PrimaryElement.ToLower() switch
        {
            "fire" => _random.Next(1, 17),
            "water" => _random.Next(17, 33), 
            "earth" => _random.Next(33, 49),
            "air" => _random.Next(49, 65),
            _ => _random.Next(1, 65)
        };
        
        // Add resonance modifier
        var resonanceModifier = agent.Resonance / 10;
        var finalCodon = Math.Max(1, Math.Min(64, elementWeight + resonanceModifier));
        
        return finalCodon;
    }

    private ElementalModifier GetElementalModifier(TamagotchiAgent agent, CodonQuest quest)
    {
        var agentElement = Enum.Parse<ElementalType>(agent.DNA.PrimaryElement);
        var questElement = quest.Element;
        
        if (agentElement == questElement)
        {
            return new ElementalModifier
            {
                Bonus = _elementalLogic[agentElement].Bonus,
                Description = $"Perfect elemental alignment! {agentElement} agent with {questElement} quest."
            };
        }
        
        // Check complementary elements
        var isComplementary = (agentElement, questElement) switch
        {
            (ElementalType.Fire, ElementalType.Air) or (ElementalType.Air, ElementalType.Fire) => true,
            (ElementalType.Earth, ElementalType.Water) or (ElementalType.Water, ElementalType.Earth) => true,
            _ => false
        };
        
        if (isComplementary)
        {
            return new ElementalModifier
            {
                Bonus = 1.1f,
                Description = $"Complementary elements - {agentElement} supports {questElement}."
            };
        }
        
        return new ElementalModifier
        {
            Bonus = 0.9f, 
            Description = $"Challenging alignment - {agentElement} learning from {questElement}."
        };
    }

    private int CalculateQuestDifficulty(TamagotchiAgent agent, CodonQuest quest, ElementalModifier modifier)
    {
        var baseDifficulty = quest.Steps.Count * 20;
        var agentLevel = (agent.Age * 10) + (agent.Evolution / 5);
        var adjustedDifficulty = (int)(baseDifficulty / modifier.Bonus);
        
        return Math.Max(10, Math.Min(100, adjustedDifficulty - (int)agentLevel));
    }

    private CodonStepResult ExecuteElephantStep(QuestStep step, QuestAction action, string agentElement)
    {
        var success = step.AvailableActions.Contains(action);
        var elementalBonus = IsElementalMatch(step.ActionType, agentElement);
        
        var result = new CodonStepResult
        {
            Success = success,
            ActionTaken = action.ToString(),
            StepDescription = step.Description,
            ElementalBonus = elementalBonus
        };
        
        if (success)
        {
            result.Message = $"✨ Successfully {action}! {step.Description}";
            if (elementalBonus)
            {
                result.Message += $" (Elemental bonus from {agentElement} energy!)";
            }
        }
        else
        {
            result.Message = $"❌ {action} doesn't align with this step. Available: {string.Join(", ", step.AvailableActions)}";
        }
        
        return result;
    }

    private bool IsElementalMatch(string actionType, string agentElement)
    {
        return (actionType.ToLower(), agentElement.ToLower()) switch
        {
            ("initiate", "fire") or ("transform", "fire") => true,
            ("adapt", "water") or ("feel", "water") => true,
            ("ground", "earth") or ("develop", "earth") => true,
            ("learn", "air") or ("synthesize", "air") => true,
            _ => false
        };
    }

    private QuestReward CalculateQuestReward(CodonQuestResult quest)
    {
        return new QuestReward
        {
            CodonNumber = quest.CodonNumber,
            ExperiencePoints = quest.Steps.Count * 15,
            ElementalEssence = quest.ElementalAlignment + " Essence",
            ArchetypalWisdom = quest.Archetype + " unlocked",
            ResonanceBonus = quest.ElementalBonus > 1.2f ? 10 : 5
        };
    }

    private string GetCodonName(int codon) => $"Gate {codon}";
    private string GetCodonDescription(int codon, ElementalType element) => 
        $"A {element} archetype quest that teaches through direct experience.";

    #endregion

    public Dictionary<int, CodonQuest> GetAllCodonQuests() => _codonQuests;
    public CodonElement GetElementalLogic(ElementalType element) => _elementalLogic[element];
}

#region Data Models

public class CodonQuest
{
    public int Number { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Archetype { get; set; } = string.Empty;
    public ElementalType Element { get; set; }
    public string Description { get; set; } = string.Empty;
    public List<QuestStep> Steps { get; set; } = new();
}

public class QuestStep
{
    public string Description { get; set; } = string.Empty;
    public string ActionType { get; set; } = string.Empty;
    public List<QuestAction> AvailableActions { get; set; } = new();
}

public class CodonQuestResult
{
    public int CodonNumber { get; set; }
    public string QuestTitle { get; set; } = string.Empty;
    public string Archetype { get; set; } = string.Empty;
    public string ElementalAlignment { get; set; } = string.Empty;
    public List<QuestStep> Steps { get; set; } = new();
    public int CurrentStep { get; set; }
    public List<string> CompletedSteps { get; set; } = new();
    public float ElementalBonus { get; set; }
    public int Difficulty { get; set; }
    public string Description { get; set; } = string.Empty;
    public bool Success { get; set; }
    public QuestReward? Reward { get; set; }
}

public class CodonStepResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string ActionTaken { get; set; } = string.Empty;
    public string StepDescription { get; set; } = string.Empty;
    public bool ElementalBonus { get; set; }
    public bool QuestComplete { get; set; }
    public QuestReward? QuestReward { get; set; }
}

public class CodonElement
{
    public string Name { get; set; } = string.Empty;
    public List<string> Qualities { get; set; } = new();
    public List<string> Strengths { get; set; } = new();
    public List<string> Challenges { get; set; } = new();
    public List<QuestAction> BestActions { get; set; } = new();
    public float Bonus { get; set; }
}

public class ElementalModifier
{
    public float Bonus { get; set; }
    public string Description { get; set; } = string.Empty;
}

public class QuestReward
{
    public int CodonNumber { get; set; }
    public int ExperiencePoints { get; set; }
    public string ElementalEssence { get; set; } = string.Empty;
    public string ArchetypalWisdom { get; set; } = string.Empty;
    public int ResonanceBonus { get; set; }
}

public enum ElementalType
{
    Fire, Water, Earth, Air
}

public enum QuestAction
{
    // Fire actions
    Ignite, Begin, Focus, Act, Transform, Change, Evolve, Create, Lead,
    
    // Water actions  
    Flow, Yield, Feel, Embrace, Accept, Heal, Support, Nurture, Surrender,
    
    // Earth actions
    Build, Stabilize, Plan, Complete, Deliver, Cultivate, Progress, Ground, Develop,
    
    // Air actions
    Think, Communicate, Connect, Innovate, Research, Question, Link, Teach, Share,
    
    // Universal actions
    Gather, Organize, Combine, Celebrate, Disguise, Adapt, Persist, Learn, 
    Release, Rest, Reflect, Inspire, Examine, Measure, Guide, Meditate, 
    Center, Radiate, Welcome, Balance, Unite
}

#endregion
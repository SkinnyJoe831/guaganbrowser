using ModularSimWorld.Components;

namespace ModularSimWorld.Components;

/// <summary>
/// Console-based world viewer to display simulation state
/// </summary>
public class WorldViewer
{
    private readonly FileSystemHandler _fileHandler;
    private readonly AvatarManager _avatarManager;
    private readonly SimulationEngine _simulationEngine;
    
    public WorldViewer(FileSystemHandler fileHandler, AvatarManager avatarManager, SimulationEngine simulationEngine)
    {
        _fileHandler = fileHandler;
        _avatarManager = avatarManager;
        _simulationEngine = simulationEngine;
        Console.WriteLine("[WorldViewer] WorldViewer initialized");
    }
    
    /// <summary>
    /// Displays the current simulation status
    /// </summary>
    public void DisplayStatus()
    {
        Console.WriteLine("\n" + new string('=', 60));
        Console.WriteLine("              MODULAR SIMULATION WORLD");
        Console.WriteLine(new string('=', 60));
        
        // Display simulation engine status
        Console.WriteLine($"Simulation Status: {(_simulationEngine.IsRunning ? "RUNNING" : "STOPPED")}");
        Console.WriteLine($"Tick Count: {_simulationEngine.TickCount}");
        Console.WriteLine($"Objects: {_simulationEngine.ObjectCount}");
        Console.WriteLine($"Queued Actions: {_simulationEngine.ActionCount}");
        
        Console.WriteLine(new string('-', 60));
        
        // Display avatar information with FSO skeleton data
        Console.WriteLine($"Avatars ({_avatarManager.AvatarCount}):");
        foreach (var avatar in _avatarManager.GetAllAvatars())
        {
            var skeletonInfo = _avatarManager.GetSkeletonInfo(avatar.Id);
            Console.WriteLine($"  • {avatar.Name} ({avatar.Type}) at ({avatar.Position.X:F1}, {avatar.Position.Y:F1}, {avatar.Position.Z:F1})");
            Console.WriteLine($"    {skeletonInfo}");
        }
        
        Console.WriteLine(new string('-', 60));
        
        // Display file system information with DBPF entries
        Console.WriteLine($"Virtual Files ({_fileHandler.FileCount}):");
        foreach (var filePath in _fileHandler.ListFiles())
        {
            var fileInfo = _fileHandler.GetFileInfo(filePath);
            Console.WriteLine($"  • {filePath}");
            Console.WriteLine($"    {fileInfo}");
        }
        
        Console.WriteLine(new string('=', 60) + "\n");
    }
    
    /// <summary>
    /// Displays help information
    /// </summary>
    public void DisplayHelp()
    {
        Console.WriteLine("\n" + new string('=', 60));
        Console.WriteLine("                    HELP MENU");
        Console.WriteLine(new string('=', 60));
        Console.WriteLine("Commands:");
        Console.WriteLine("  status    - Display current simulation status");
        Console.WriteLine("  start     - Start the simulation");
        Console.WriteLine("  stop      - Stop the simulation");
        Console.WriteLine("  tick      - Process one simulation tick");
        Console.WriteLine("  avatar    - Create a new avatar");
        Console.WriteLine("  move      - Move an avatar");
        Console.WriteLine("  object    - Add a simulation object");
        Console.WriteLine("  action    - Queue a simulation action");
        Console.WriteLine("  file      - Store a file in the virtual file system");
        Console.WriteLine("  weather   - View current astrological weather report");
        Console.WriteLine("  createchar- Create character with astrological profile");
        Console.WriteLine("  dream     - Experience personalized dream sequences");
        Console.WriteLine("  tamagotchi- Create autonomous Tamagotchi agent");
        Console.WriteLine("  care      - Care for your Tamagotchi agent");
        Console.WriteLine("  status    - Check Tamagotchi agent status");
        Console.WriteLine("  journal   - Write in Cynthia's notebook (affects agent!)");
        Console.WriteLine("  resonance - Check agent's emotional resonance");
        Console.WriteLine("  listchars - View all created astrological characters");
        Console.WriteLine("  help      - Show this help menu");
        Console.WriteLine("  exit      - Exit the simulation");
        Console.WriteLine(new string('=', 60) + "\n");
    }
    
    /// <summary>
    /// Displays the welcome message
    /// </summary>
    public void DisplayWelcome()
    {
        Console.Clear();
        Console.WriteLine(new string('█', 60));
        Console.WriteLine("█" + new string(' ', 58) + "█");
        Console.WriteLine("█         MODULAR SIMULATION WORLD v1.0              █");
        Console.WriteLine("█         Built with FSO.Interface Library           █");
        Console.WriteLine("█" + new string(' ', 58) + "█");
        Console.WriteLine(new string('█', 60));
        Console.WriteLine();
        Console.WriteLine("A modular simulation world engine demonstrating:");
        Console.WriteLine("• File System Handler (FSO.Files.Interface)");
        Console.WriteLine("• Avatar Management (FSO.Vitaboy.Interface)");
        Console.WriteLine("• Simulation Engine (FSO.SimAntics.Interface)");
        Console.WriteLine("• Astrological Character Creation");
        Console.WriteLine("• Real-time Astrological Weather Reports");
        Console.WriteLine("• Personalized Dream Sequences");
        Console.WriteLine("• Autonomous Tamagotchi Agents");
        Console.WriteLine("• DNA-Based Agent Evolution");
        Console.WriteLine("• Cosmic Resonance Field Simulation");
        Console.WriteLine("• Modular Architecture");
        Console.WriteLine();
        Console.WriteLine("Type 'help' for commands or 'start' to begin simulation.");
        Console.WriteLine();
    }
}
using System.Globalization;
using System.Text.Json;

namespace ModularSimWorld.Components;

/// <summary>
/// Astrological weather service that provides current astrological conditions
/// like a weather report but for planetary positions and cosmic influences
/// </summary>
public class AstrologicalWeatherService
{
    private readonly HttpClient _httpClient;
    private readonly bool _useRealtimeData;
    private readonly string? _astronomiaServiceUrl;

    public AstrologicalWeatherService(bool useRealtimeData = true, string? astronomiaServiceUrl = null)
    {
        _httpClient = new HttpClient();
        _useRealtimeData = useRealtimeData;
        _astronomiaServiceUrl = astronomiaServiceUrl;
        Console.WriteLine("[AstroWeather] Astrological Weather Service initialized");
    }

    /// <summary>
    /// Gets the current astrological weather report
    /// </summary>
    public async Task<AstrologicalWeatherReport> GetCurrentWeatherAsync(double latitude = 0, double longitude = 0)
    {
        var currentTime = DateTime.UtcNow;
        
        if (_useRealtimeData && !string.IsNullOrEmpty(_astronomiaServiceUrl))
        {
            return await GetRealtimeAstrologicalWeather(currentTime, latitude, longitude);
        }
        else
        {
            return GenerateLocalAstrologicalWeather(currentTime, latitude, longitude);
        }
    }

    /// <summary>
    /// Gets astrological weather from external astronomical service
    /// </summary>
    private async Task<AstrologicalWeatherReport> GetRealtimeAstrologicalWeather(DateTime currentTime, double latitude, double longitude)
    {
        try
        {
            var requestData = new
            {
                timestamp = currentTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                latitude = latitude,
                longitude = longitude,
                include_planets = true,
                include_aspects = true,
                include_lunar_phases = true
            };

            var json = JsonSerializer.Serialize(requestData);
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync($"{_astronomiaServiceUrl}/current-positions", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseJson = await response.Content.ReadAsStringAsync();
                var externalData = JsonSerializer.Deserialize<ExternalAstronomicalData>(responseJson);
                
                return ConvertExternalDataToWeatherReport(externalData!, currentTime, latitude, longitude);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[AstroWeather] External service failed, using local calculations: {ex.Message}");
        }

        // Fallback to local calculation
        return GenerateLocalAstrologicalWeather(currentTime, latitude, longitude);
    }

    /// <summary>
    /// Generates astrological weather using local calculations
    /// </summary>
    private AstrologicalWeatherReport GenerateLocalAstrologicalWeather(DateTime currentTime, double latitude, double longitude)
    {
        var moonPhase = CalculateMoonPhase(currentTime);
        var dominantElement = GetDominantElement(currentTime);
        var energyForecast = GenerateEnergyForecast(currentTime);
        var planetaryHighlights = GetPlanetaryHighlights(currentTime);
        var aspectsToday = GetCurrentAspects(currentTime);
        
        return new AstrologicalWeatherReport
        {
            Timestamp = currentTime,
            Location = $"Lat: {latitude:F2}, Lon: {longitude:F2}",
            CurrentSeason = GetAstrologicalSeason(currentTime),
            MoonPhase = moonPhase,
            MoonSign = GetCurrentMoonSign(currentTime),
            DominantElement = dominantElement,
            EnergyLevel = CalculateCurrentEnergyLevel(currentTime),
            EnergyForecast = energyForecast,
            PlanetaryHighlights = planetaryHighlights,
            MajorAspects = aspectsToday,
            LuckyColors = GetLuckyColors(dominantElement),
            BestActivities = GetRecommendedActivities(moonPhase, dominantElement),
            CautionAreas = GetCautionAreas(aspectsToday),
            SpiritualWeather = GetSpiritualWeather(moonPhase, currentTime)
        };
    }

    #region Local Calculation Methods

    private MoonPhase CalculateMoonPhase(DateTime date)
    {
        // Simplified moon phase calculation
        var daysSinceNewMoon = (date.DayOfYear + date.Year * 365) % 29.5;
        
        return daysSinceNewMoon switch
        {
            >= 0 and < 1 => MoonPhase.NewMoon,
            >= 1 and < 7 => MoonPhase.WaxingCrescent,
            >= 7 and < 8 => MoonPhase.FirstQuarter,
            >= 8 and < 14 => MoonPhase.WaxingGibbous,
            >= 14 and < 15 => MoonPhase.FullMoon,
            >= 15 and < 21 => MoonPhase.WaningGibbous,
            >= 21 and < 22 => MoonPhase.ThirdQuarter,
            _ => MoonPhase.WaningCrescent
        };
    }

    private string GetCurrentMoonSign(DateTime date)
    {
        var moonSigns = new[] { "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", 
                               "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces" };
        var signIndex = (date.DayOfYear * 12 / 365) % 12;
        return moonSigns[signIndex];
    }

    private string GetAstrologicalSeason(DateTime date)
    {
        return date.Month switch
        {
            3 or 4 or 5 => "Aries Season (Spring Awakening)",
            6 or 7 or 8 => "Cancer Season (Summer Abundance)", 
            9 or 10 or 11 => "Libra Season (Autumn Balance)",
            _ => "Capricorn Season (Winter Reflection)"
        };
    }

    private ElementType GetDominantElement(DateTime date)
    {
        var elements = new[] { ElementType.Fire, ElementType.Earth, ElementType.Air, ElementType.Water };
        var elementIndex = (date.DayOfYear / 91) % 4;
        return elements[elementIndex];
    }

    private int CalculateCurrentEnergyLevel(DateTime date)
    {
        var baseEnergy = 50;
        var moonBonus = CalculateMoonPhase(date) == MoonPhase.FullMoon ? 20 : 0;
        var seasonalBonus = date.Month switch
        {
            3 or 4 or 5 => 15, // Spring energy
            6 or 7 or 8 => 10, // Summer stability
            9 or 10 or 11 => 5, // Autumn transition
            _ => -5 // Winter conservation
        };
        
        return Math.Max(1, Math.Min(100, baseEnergy + moonBonus + seasonalBonus));
    }

    private List<string> GenerateEnergyForecast(DateTime date)
    {
        var forecasts = new List<string>();
        var energy = CalculateCurrentEnergyLevel(date);
        
        if (energy > 75)
        {
            forecasts.Add("High cosmic energy - excellent for new beginnings");
            forecasts.Add("Strong manifestation potential");
        }
        else if (energy > 50)
        {
            forecasts.Add("Balanced energy - good for routine activities");
            forecasts.Add("Steady progress on existing projects");
        }
        else
        {
            forecasts.Add("Lower energy - focus on rest and reflection");
            forecasts.Add("Ideal time for meditation and planning");
        }
        
        return forecasts;
    }

    private List<PlanetaryHighlight> GetPlanetaryHighlights(DateTime date)
    {
        var highlights = new List<PlanetaryHighlight>();
        
        // Generate some planetary positions based on date
        var planets = new[] { "Mercury", "Venus", "Mars", "Jupiter", "Saturn" };
        var signs = new[] { "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", 
                           "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces" };
        
        foreach (var planet in planets)
        {
            var signIndex = (date.DayOfYear + planet.GetHashCode()) % 12;
            var influence = GetPlanetaryInfluence(planet, signs[signIndex]);
            
            highlights.Add(new PlanetaryHighlight
            {
                Planet = planet,
                Sign = signs[signIndex],
                Influence = influence,
                Intensity = (date.DayOfYear + planet.GetHashCode()) % 10 + 1
            });
        }
        
        return highlights;
    }

    private string GetPlanetaryInfluence(string planet, string sign)
    {
        return planet switch
        {
            "Mercury" => $"Communication and thinking influenced by {sign} energy",
            "Venus" => $"Love and beauty expressed through {sign} qualities",
            "Mars" => $"Action and drive channeled via {sign} motivation",
            "Jupiter" => $"Growth and expansion guided by {sign} wisdom",
            "Saturn" => $"Structure and discipline shaped by {sign} lessons",
            _ => $"General influence through {sign}"
        };
    }

    private List<string> GetCurrentAspects(DateTime date)
    {
        var aspects = new List<string>();
        var aspectTypes = new[] { "Conjunction", "Square", "Trine", "Opposition", "Sextile" };
        var planets = new[] { "Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn" };
        
        // Generate some aspects based on the date
        var numAspects = (date.DayOfYear % 5) + 2;
        for (int i = 0; i < numAspects; i++)
        {
            var planet1 = planets[(date.DayOfYear + i) % planets.Length];
            var planet2 = planets[(date.DayOfYear + i + 1) % planets.Length];
            var aspect = aspectTypes[(date.DayOfYear + i) % aspectTypes.Length];
            
            aspects.Add($"{planet1} {aspect} {planet2}");
        }
        
        return aspects;
    }

    private List<string> GetLuckyColors(ElementType element)
    {
        return element switch
        {
            ElementType.Fire => new List<string> { "Red", "Orange", "Gold", "Bright Yellow" },
            ElementType.Earth => new List<string> { "Brown", "Green", "Beige", "Terracotta" },
            ElementType.Air => new List<string> { "Light Blue", "White", "Silver", "Pale Yellow" },
            ElementType.Water => new List<string> { "Deep Blue", "Teal", "Purple", "Sea Green" },
            _ => new List<string> { "White", "Silver" }
        };
    }

    private List<string> GetRecommendedActivities(MoonPhase moonPhase, ElementType element)
    {
        var activities = new List<string>();
        
        // Moon phase activities
        activities.AddRange(moonPhase switch
        {
            MoonPhase.NewMoon => new[] { "Setting intentions", "Planning new projects", "Meditation" },
            MoonPhase.WaxingCrescent => new[] { "Taking action on goals", "Building momentum" },
            MoonPhase.FirstQuarter => new[] { "Overcoming obstacles", "Making decisions" },
            MoonPhase.WaxingGibbous => new[] { "Refining plans", "Adjusting course" },
            MoonPhase.FullMoon => new[] { "Celebrating achievements", "Releasing what no longer serves" },
            MoonPhase.WaningGibbous => new[] { "Gratitude practices", "Sharing wisdom" },
            MoonPhase.ThirdQuarter => new[] { "Letting go", "Forgiveness work" },
            MoonPhase.WaningCrescent => new[] { "Rest and reflection", "Preparation for new cycle" },
            _ => new[] { "General spiritual practice" }
        });
        
        // Element-based activities
        activities.AddRange(element switch
        {
            ElementType.Fire => new[] { "Physical exercise", "Creative projects", "Leadership activities" },
            ElementType.Earth => new[] { "Gardening", "Financial planning", "Organizing" },
            ElementType.Air => new[] { "Communication", "Learning", "Social activities" },
            ElementType.Water => new[] { "Emotional healing", "Artistic expression", "Water activities" },
            _ => new[] { "Balanced lifestyle activities" }
        });
        
        return activities;
    }

    private List<string> GetCautionAreas(List<string> aspects)
    {
        var cautions = new List<string>();
        
        foreach (var aspect in aspects)
        {
            if (aspect.Contains("Square") || aspect.Contains("Opposition"))
            {
                cautions.Add($"Tension from {aspect} - practice patience");
            }
        }
        
        if (!cautions.Any())
        {
            cautions.Add("Generally harmonious energy - proceed with confidence");
        }
        
        return cautions;
    }

    private string GetSpiritualWeather(MoonPhase moonPhase, DateTime date)
    {
        var spiritualConditions = new[]
        {
            "Clear spiritual visibility - insights flow easily",
            "Mystical fog - trust your intuition over logic",
            "Spiritual storms - transformation energy is high", 
            "Calm spiritual seas - peaceful meditation favored",
            "Spiritual winds of change - stay flexible",
            "Bright spiritual sunshine - optimism and joy"
        };
        
        var conditionIndex = ((int)moonPhase + date.DayOfYear) % spiritualConditions.Length;
        return spiritualConditions[conditionIndex];
    }

    private AstrologicalWeatherReport ConvertExternalDataToWeatherReport(ExternalAstronomicalData data, DateTime timestamp, double latitude, double longitude)
    {
        // Convert external API data to our weather report format
        return new AstrologicalWeatherReport
        {
            Timestamp = timestamp,
            Location = $"Lat: {latitude:F2}, Lon: {longitude:F2}",
            CurrentSeason = data.Season ?? GetAstrologicalSeason(timestamp),
            MoonPhase = Enum.Parse<MoonPhase>(data.MoonPhase ?? "NewMoon"),
            MoonSign = data.MoonSign ?? "Aries",
            DominantElement = Enum.Parse<ElementType>(data.DominantElement ?? "Fire"),
            EnergyLevel = data.EnergyLevel ?? 50,
            EnergyForecast = data.EnergyForecast ?? new List<string>(),
            PlanetaryHighlights = data.PlanetaryPositions?.Select(p => new PlanetaryHighlight
            {
                Planet = p.Planet,
                Sign = p.Sign,
                Influence = p.Influence,
                Intensity = p.Intensity
            }).ToList() ?? new List<PlanetaryHighlight>(),
            MajorAspects = data.MajorAspects ?? new List<string>(),
            LuckyColors = data.LuckyColors ?? new List<string>(),
            BestActivities = data.RecommendedActivities ?? new List<string>(),
            CautionAreas = data.CautionAreas ?? new List<string>(),
            SpiritualWeather = data.SpiritualCondition ?? "Clear spiritual visibility"
        };
    }

    #endregion
}

#region Data Models

public class AstrologicalWeatherReport
{
    public DateTime Timestamp { get; set; }
    public string Location { get; set; } = string.Empty;
    public string CurrentSeason { get; set; } = string.Empty;
    public MoonPhase MoonPhase { get; set; }
    public string MoonSign { get; set; } = string.Empty;
    public ElementType DominantElement { get; set; }
    public int EnergyLevel { get; set; }
    public List<string> EnergyForecast { get; set; } = new();
    public List<PlanetaryHighlight> PlanetaryHighlights { get; set; } = new();
    public List<string> MajorAspects { get; set; } = new();
    public List<string> LuckyColors { get; set; } = new();
    public List<string> BestActivities { get; set; } = new();
    public List<string> CautionAreas { get; set; } = new();
    public string SpiritualWeather { get; set; } = string.Empty;
}

public class PlanetaryHighlight
{
    public string Planet { get; set; } = string.Empty;
    public string Sign { get; set; } = string.Empty;
    public string Influence { get; set; } = string.Empty;
    public int Intensity { get; set; }
}

public class ExternalAstronomicalData
{
    public string? Season { get; set; }
    public string? MoonPhase { get; set; }
    public string? MoonSign { get; set; }
    public string? DominantElement { get; set; }
    public int? EnergyLevel { get; set; }
    public List<string>? EnergyForecast { get; set; }
    public List<ExternalPlanetaryPosition>? PlanetaryPositions { get; set; }
    public List<string>? MajorAspects { get; set; }
    public List<string>? LuckyColors { get; set; }
    public List<string>? RecommendedActivities { get; set; }
    public List<string>? CautionAreas { get; set; }
    public string? SpiritualCondition { get; set; }
}

public class ExternalPlanetaryPosition
{
    public string Planet { get; set; } = string.Empty;
    public string Sign { get; set; } = string.Empty;
    public string Influence { get; set; } = string.Empty;
    public int Intensity { get; set; }
}

public enum MoonPhase
{
    NewMoon, WaxingCrescent, FirstQuarter, WaxingGibbous,
    FullMoon, WaningGibbous, ThirdQuarter, WaningCrescent
}

public enum ElementType
{
    Fire, Earth, Air, Water
}

#endregion
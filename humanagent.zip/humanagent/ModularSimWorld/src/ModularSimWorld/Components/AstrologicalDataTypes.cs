using System.Text.Json;

namespace ModularSimWorld.Components;

/// <summary>
/// Astrological character with triple-tradition analysis
/// Body (Tropical), Mind (Sidereal), Heart (Draconian)
/// </summary>
public class AstrologicalCharacter
{
    public string Name { get; set; } = string.Empty;
    public DateTime BirthDate { get; set; }
    public TimeSpan BirthTime { get; set; }
    public string BirthLocation { get; set; } = string.Empty;
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string CalculationMethod { get; set; } = string.Empty;
    
    public TropicalBodyTraits BodyTraits { get; set; } = new();
    public SiderealMindTraits MindTraits { get; set; } = new();
    public DraconianHeartTraits HeartTraits { get; set; } = new();
    
    // Human Design DNA - created from all three traditions
    public HumanDesignDNA DNA { get; set; } = new();
}

/// <summary>
/// Tropical astrology traits for physical body characteristics
/// </summary>
public class TropicalBodyTraits
{
    public TropicalZodiacSign SunSign { get; set; }
    public TropicalZodiacSign MoonSign { get; set; }
    public TropicalZodiacSign RisingSign { get; set; }
    
    public TropicalElement PrimaryElement { get; set; }
    public TropicalQuality PrimaryQuality { get; set; }
    
    public Dictionary<string, double> PlanetaryPositions { get; set; } = new();
    public List<string> AspectPatterns { get; set; } = new();
    public List<int> ActiveHouseCusps { get; set; } = new();
    
    // Physical manifestation traits
    public string ConstitutionalType { get; set; } = string.Empty;
    public string EnergyPattern { get; set; } = string.Empty;
    public List<string> PhysicalStrengths { get; set; } = new();
    public List<string> PhysicalChallenges { get; set; } = new();
    
    // Helper properties for backward compatibility
    public TropicalElement Element { get => PrimaryElement; set => PrimaryElement = value; }
    public TropicalZodiacSign ZodiacSign { get => SunSign; set => SunSign = value; }
    public TropicalQuality Quality { get => PrimaryQuality; set => PrimaryQuality = value; }
    public int PhysicalStrength { get; set; } = 50;
    public int Agility { get; set; } = 50;
    public string Constitution { get => ConstitutionalType; set => ConstitutionalType = value; }
    public int Endurance { get; set; } = 50;
}

/// <summary>
/// Sidereal astrology traits for mind characteristics  
/// </summary>
public class SiderealMindTraits
{
    public SiderealZodiacSign SiderealSun { get; set; }
    public SiderealZodiacSign SiderealMoon { get; set; }
    public Nakshatra MoonNakshatra { get; set; }
    public Nakshatra SunNakshatra { get; set; }
    
    public Dictionary<string, SiderealZodiacSign> PlanetaryPositions { get; set; } = new();
    public List<string> YogaCombinations { get; set; } = new();
    public List<int> VedicHouses { get; set; } = new();
    
    // Mental processing traits
    public string ThinkingStyle { get; set; } = string.Empty;
    public string LearningPattern { get; set; } = string.Empty;
    public List<string> MentalGifts { get; set; } = new();
    public List<string> MentalBlocks { get; set; } = new();
    public string IntuitionType { get; set; } = string.Empty;
    
    // Helper properties for backward compatibility
    public Nakshatra Nakshatra { get => MoonNakshatra; set => MoonNakshatra = value; }
    public SiderealZodiacSign SiderealSign { get => SiderealSun; set => SiderealSun = value; }
    public string Dasha { get; set; } = "Mahadasha";
    public int Intellect { get; set; } = 50;
    public int Focus { get; set; } = 50;
    public int Intuition { get; set; } = 50;
    public int Creativity { get; set; } = 50;
}

/// <summary>
/// Draconian astrology traits for heart/emotional characteristics
/// </summary>
public class DraconianHeartTraits
{
    public DragonEnergyType NorthNodeEnergy { get; set; }
    public DragonEnergyType SouthNodeEnergy { get; set; }
    public double NodeAxisDegrees { get; set; }
    
    public Dictionary<string, DragonEnergyType> DraconicPlanets { get; set; } = new();
    public List<string> KarmicPatterns { get; set; } = new();
    public string SoulPurpose { get; set; } = string.Empty;
    
    // Emotional/heart traits
    public string EmotionalNature { get; set; } = string.Empty;
    public string LoveLanguage { get; set; } = string.Empty;
    public List<string> HeartGifts { get; set; } = new();
    public List<string> EmotionalShadows { get; set; } = new();
    public string IntimacyStyle { get; set; } = string.Empty;
    
    // Helper properties for backward compatibility
    public DragonEnergyType DragonEnergy { get => NorthNodeEnergy; set => NorthNodeEnergy = value; }
    public DragonEnergyType NorthNode { get => NorthNodeEnergy; set => NorthNodeEnergy = value; }
    public DragonEnergyType SouthNode { get => SouthNodeEnergy; set => SouthNodeEnergy = value; }
    public int Empathy { get; set; } = 50;
    public int Passion { get; set; } = 50;
    public int EmotionalDepth { get; set; } = 50;
}

/// <summary>
/// Human Design DNA created from astrological synthesis
/// </summary>
public class HumanDesignDNA
{
    // Core Design Elements
    public string Type { get; set; } = string.Empty; // Manifestor, Generator, etc.
    public string Strategy { get; set; } = string.Empty;
    public string Authority { get; set; } = string.Empty;
    public string Profile { get; set; } = string.Empty;
    
    // Gate Activations (64 total)
    public Dictionary<int, bool> DefinedGates { get; set; } = new();
    public List<int> ActiveChannels { get; set; } = new();
    public Dictionary<string, bool> CenterDefinitions { get; set; } = new();
    
    // Elemental Synthesis
    public string PrimaryElement { get; set; } = string.Empty; // Fire, Earth, Air, Water
    public string SecondaryElement { get; set; } = string.Empty;
    public List<string> ElementalQualities { get; set; } = new();
    
    // Incarnation Cross (Life Theme)
    public string IncarnationCross { get; set; } = string.Empty;
    public List<int> CrossGates { get; set; } = new(); // 4 gates that form the cross
    
    // Variables for digestion, environment, etc.
    public Dictionary<string, string> Variables { get; set; } = new();
}

#region Enums and Supporting Types

public enum TropicalZodiacSign
{
    Aries, Taurus, Gemini, Cancer, Leo, Virgo,
    Libra, Scorpio, Sagittarius, Capricorn, Aquarius, Pisces
}

public enum TropicalElement
{
    Fire, Earth, Air, Water
}

public enum TropicalQuality  
{
    Cardinal, Fixed, Mutable
}

public enum SiderealZodiacSign
{
    Aries, Taurus, Gemini, Cancer, Leo, Virgo,
    Libra, Scorpio, Sagittarius, Capricorn, Aquarius, Pisces
}

public enum Nakshatra
{
    Ashwini, Bharani, Krittika, Rohini, Mrigashirsha, Mrigashira, Ardra, Punarvasu,
    Pushya, Ashlesha, Magha, PurvaPhalguni, UttaraPhalguni, Hasta,
    Chitra, Swati, Vishakha, Anuradha, Jyeshtha, Mula, PurvaAshadha,
    UttaraAshadha, Shravana, Dhanishtha, Shatabhisha, PurvaBhadrapada,
    UttaraBhadrapada, Revati
}

public enum DragonEnergyType
{
    // North Node energies (future direction)
    Initiator, Creator, Connector, Nurturer, Performer, Perfecter,
    Harmonizer, Transformer, Seeker, Builder, Innovator, Mystic,
    
    // South Node energies (past mastery) 
    Warrior, Architect, Messenger, Protector, Ruler, Analyst,
    Partner, Healer, Teacher, Authority, Rebel, Dreamer,
    
    // Dragon elements for compatibility
    FireDragon, WaterDragon, EarthDragon, AirDragon
}

#endregion

/// <summary>
/// Tamagotchi Agent with astrological DNA and autonomous behavior
/// </summary>
public class TamagotchiAgent
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; } = string.Empty;
    public AstrologicalCharacter AstroCharacter { get; set; } = new();
    public HumanDesignDNA DNA { get; set; } = new();
    
    // Agent Status
    public int Age { get; set; } = 0; // Days since creation
    public string EvolutionStage { get; set; } = "Seed";
    public int Evolution { get; set; } = 0; // 0-100
    public int Happiness { get; set; } = 50; // 0-100
    public int Energy { get; set; } = 100; // 0-100
    public int Health { get; set; } = 100; // 0-100
    public int Resonance { get; set; } = 0; // Cosmic alignment 0-100
    
    // Autonomous Behavior
    public Dictionary<string, double> Motivations { get; set; } = new();
    public List<string> CurrentGoals { get; set; } = new();
    public List<string> RecentActions { get; set; } = new();
    public DateTime LastUpdate { get; set; } = DateTime.Now;
    
    // Codon Quest System
    public CodonQuestResult? ActiveQuest { get; set; }
    public List<int> CompletedCodons { get; set; } = new();
    public Dictionary<string, object> QuestProgress { get; set; } = new();
    
    // Missing properties for compilation - AgentMood enum for proper type handling
    public AgentMood CurrentMoodEnum { get; set; } = AgentMood.Happy;
    public string CurrentMood { get => CurrentMoodEnum.ToString(); set => CurrentMoodEnum = Enum.Parse<AgentMood>(value, true); }
    public DateTime LastCareTime { get; set; } = DateTime.Now;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public Dictionary<string, int> Traits { get; set; } = new();
    public List<int> Gates { get; set; } = new();
}
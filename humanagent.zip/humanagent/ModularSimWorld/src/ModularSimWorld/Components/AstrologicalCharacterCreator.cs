using System.Numerics;
using System.Text.Json;

namespace ModularSimWorld.Components;

/// <summary>
/// Astrological character creation system using multiple astrological traditions
/// Supports external astronomical calculation services (Astronomia HD, Sharp Astrology)
/// </summary>
public class AstrologicalCharacterCreator
{
    private readonly HttpClient _httpClient;
    private readonly Random _random;
    private readonly bool _useExternalServices;

    public AstrologicalCharacterCreator()
    {
        _httpClient = new HttpClient();
        _random = new Random();
        _useExternalServices = false; // Set to true when API keys available
    }

    /// <summary>
    /// Creates a complete astrological character with tropical, sidereal, and draconian analysis
    /// </summary>
    public async Task<AstrologicalCharacter> CreateCharacterAsync(string name, DateTime birthDate, TimeSpan birthTime, string birthLocation, double latitude = 0, double longitude = 0)
    {
        TropicalBodyTraits bodyTraits;
        SiderealMindTraits mindTraits;
        DraconianHeartTraits heartTraits;

        if (_useExternalServices)
        {
            // Use external astronomical APIs for precise calculations
            bodyTraits = await GenerateExternalTropicalBodyTraits(birthDate, birthTime, latitude, longitude);
            mindTraits = await GenerateExternalSiderealMindTraits(birthDate, birthTime, latitude, longitude);
            heartTraits = await GenerateExternalDraconianHeartTraits(birthDate, birthTime, latitude, longitude);
        }
        else
        {
            // Use internal calculation methods for demo
            bodyTraits = GenerateTropicalBodyTraits(birthDate, birthTime);
            mindTraits = GenerateSiderealMindTraits(birthDate, birthTime);
            heartTraits = GenerateDraconianHeartTraits(birthDate, birthTime);
        }

        return new AstrologicalCharacter
        {
            Name = name,
            BirthDate = birthDate,
            BirthTime = birthTime,
            BirthLocation = birthLocation,
            Latitude = latitude,
            Longitude = longitude,
            CalculationMethod = _useExternalServices ? "External API" : "Internal Demo",
            BodyTraits = bodyTraits,
            MindTraits = mindTraits,
            HeartTraits = heartTraits
        };
    }

    /// <summary>
    /// Synchronous character creation wrapper
    /// </summary>
    public AstrologicalCharacter CreateCharacter(string name, DateTime birthDate, TimeSpan birthTime, string birthLocation)
    {
        return CreateCharacterAsync(name, birthDate, birthTime, birthLocation).GetAwaiter().GetResult();
    }

    #region External API Methods (Future Integration)

    /// <summary>
    /// Generates tropical body traits using external Astronomia HD API
    /// </summary>
    private async Task<TropicalBodyTraits> GenerateExternalTropicalBodyTraits(DateTime birthDate, TimeSpan birthTime, double latitude, double longitude)
    {
        try
        {
            var requestData = new
            {
                birth_date = birthDate.ToString("yyyy-MM-dd"),
                birth_time = birthTime.ToString(@"hh\:mm"),
                latitude = latitude,
                longitude = longitude,
                calculation_type = "tropical"
            };

            var response = await _httpClient.PostAsync("https://api.astronomia-hd.com/tropical-body-analysis", 
                new StringContent(JsonSerializer.Serialize(requestData), System.Text.Encoding.UTF8, "application/json"));

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<ExternalTropicalResult>(json);
                
                return new TropicalBodyTraits
                {
                    ZodiacSign = Enum.Parse<TropicalZodiacSign>(result?.ZodiacSign ?? "Aries"),
                    Element = Enum.Parse<TropicalElement>(result?.Element ?? "Fire"),
                    Quality = Enum.Parse<TropicalQuality>(result?.Quality ?? "Cardinal"),
                    PhysicalStrength = result?.PhysicalStrength ?? 50,
                    Constitution = result?.Constitution ?? 50,
                    Agility = result?.Agility ?? 50,
                    Endurance = result?.Endurance ?? 50
                };
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Astro] External tropical API failed: {ex.Message}");
        }

        // Fallback to internal calculation
        return GenerateTropicalBodyTraits(birthDate, birthTime);
    }

    /// <summary>
    /// Generates sidereal mind traits using external Sharp Astrology API
    /// </summary>
    private async Task<SiderealMindTraits> GenerateExternalSiderealMindTraits(DateTime birthDate, TimeSpan birthTime, double latitude, double longitude)
    {
        try
        {
            var requestData = new
            {
                birth_date = birthDate.ToString("yyyy-MM-dd"),
                birth_time = birthTime.ToString(@"hh\:mm"),
                latitude = latitude,
                longitude = longitude,
                calculation_type = "sidereal",
                ayanamsa = "lahiri"
            };

            var response = await _httpClient.PostAsync("https://api.sharp-astrology.com/sidereal-mind-analysis",
                new StringContent(JsonSerializer.Serialize(requestData), System.Text.Encoding.UTF8, "application/json"));

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<ExternalSiderealResult>(json);
                
                return new SiderealMindTraits
                {
                    SiderealSign = Enum.Parse<SiderealZodiacSign>(result?.SiderealSign ?? "Aries"),
                    Nakshatra = Enum.Parse<Nakshatra>(result?.Nakshatra ?? "Ashwini"),
                    Dasha = result?.CurrentDasha ?? "Mercury",
                    Intellect = result?.Intellect ?? 50,
                    Intuition = result?.Intuition ?? 50,
                    Focus = result?.Focus ?? 50,
                    Creativity = result?.Creativity ?? 50
                };
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Astro] External sidereal API failed: {ex.Message}");
        }

        // Fallback to internal calculation
        return GenerateSiderealMindTraits(birthDate, birthTime);
    }

    /// <summary>
    /// Generates draconian heart traits using external nodal analysis
    /// </summary>
    private async Task<DraconianHeartTraits> GenerateExternalDraconianHeartTraits(DateTime birthDate, TimeSpan birthTime, double latitude, double longitude)
    {
        try
        {
            var requestData = new
            {
                birth_date = birthDate.ToString("yyyy-MM-dd"),
                birth_time = birthTime.ToString(@"hh\:mm"),
                latitude = latitude,
                longitude = longitude,
                calculation_type = "draconian_nodes"
            };

            var response = await _httpClient.PostAsync("https://api.draconic-astrology.com/nodal-heart-analysis",
                new StringContent(JsonSerializer.Serialize(requestData), System.Text.Encoding.UTF8, "application/json"));

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringContent();
                var result = JsonSerializer.Deserialize<ExternalNodalResult>(json);
                
                var northNode = result?.NorthNode ?? "Aries";
                var southNode = result?.SouthNode ?? "Libra";
                
                return new DraconianHeartTraits
                {
                    NorthNode = northNode,
                    SouthNode = southNode,
                    DragonEnergy = GetDragonEnergyFromNodes(northNode, southNode),
                    EmotionalDepth = result?.EmotionalDepth ?? 50,
                    Passion = result?.Passion ?? 50,
                    Empathy = result?.Empathy ?? 50,
                    SoulPurpose = GetSoulPurpose(northNode, southNode)
                };
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Astro] External draconian API failed: {ex.Message}");
        }

        // Fallback to internal calculation
        return GenerateDraconianHeartTraits(birthDate, birthTime);
    }

    #endregion

    #region Internal Calculation Methods

    /// <summary>
    /// Generates tropical body traits using internal calculations
    /// </summary>
    private TropicalBodyTraits GenerateTropicalBodyTraits(DateTime birthDate, TimeSpan birthTime)
    {
        var zodiacSign = GetTropicalZodiacSign(birthDate);
        var element = GetTropicalElement(zodiacSign);
        var quality = GetTropicalQuality(zodiacSign);

        return new TropicalBodyTraits
        {
            ZodiacSign = zodiacSign,
            Element = element,
            Quality = quality,
            PhysicalStrength = CalculateBodyAttribute("strength", zodiacSign, birthTime),
            Constitution = CalculateBodyAttribute("constitution", zodiacSign, birthTime),
            Agility = CalculateBodyAttribute("agility", zodiacSign, birthTime),
            Endurance = CalculateBodyAttribute("endurance", zodiacSign, birthTime)
        };
    }

    /// <summary>
    /// Generates sidereal mind traits using internal calculations
    /// </summary>
    private SiderealMindTraits GenerateSiderealMindTraits(DateTime birthDate, TimeSpan birthTime)
    {
        var siderealSign = GetSiderealZodiacSign(birthDate);
        var nakshatra = GetNakshatra(birthDate, birthTime);
        var dasha = GetCurrentDasha(birthDate);

        return new SiderealMindTraits
        {
            SiderealSign = siderealSign,
            Nakshatra = nakshatra,
            Dasha = dasha,
            Intellect = CalculateMindAttribute("intellect", siderealSign, nakshatra, birthTime),
            Intuition = CalculateMindAttribute("intuition", siderealSign, nakshatra, birthTime),
            Focus = CalculateMindAttribute("focus", siderealSign, nakshatra, birthTime),
            Creativity = CalculateMindAttribute("creativity", siderealSign, nakshatra, birthTime)
        };
    }

    /// <summary>
    /// Generates draconian heart traits using internal calculations
    /// </summary>
    private DraconianHeartTraits GenerateDraconianHeartTraits(DateTime birthDate, TimeSpan birthTime)
    {
        var northNode = GetNorthNodePosition(birthDate);
        var southNode = GetSouthNodePosition(birthDate);

        return new DraconianHeartTraits
        {
            NorthNode = northNode,
            SouthNode = southNode,
            DragonEnergy = GetDragonEnergyFromNodes(northNode, southNode),
            EmotionalDepth = CalculateHeartAttribute("depth", northNode, southNode, birthTime),
            Passion = CalculateHeartAttribute("passion", northNode, southNode, birthTime),
            Empathy = CalculateHeartAttribute("empathy", northNode, southNode, birthTime),
            SoulPurpose = GetSoulPurpose(northNode, southNode)
        };
    }

    private TropicalZodiacSign GetTropicalZodiacSign(DateTime birthDate)
    {
        var dayOfYear = birthDate.DayOfYear;
        
        return dayOfYear switch
        {
            >= 80 and <= 110 => TropicalZodiacSign.Aries,     // Mar 21 - Apr 19
            >= 111 and <= 141 => TropicalZodiacSign.Taurus,   // Apr 20 - May 20
            >= 142 and <= 172 => TropicalZodiacSign.Gemini,   // May 21 - Jun 21
            >= 173 and <= 204 => TropicalZodiacSign.Cancer,   // Jun 22 - Jul 22
            >= 205 and <= 235 => TropicalZodiacSign.Leo,      // Jul 23 - Aug 22
            >= 236 and <= 266 => TropicalZodiacSign.Virgo,    // Aug 23 - Sep 22
            >= 267 and <= 297 => TropicalZodiacSign.Libra,    // Sep 23 - Oct 23
            >= 298 and <= 328 => TropicalZodiacSign.Scorpio,  // Oct 24 - Nov 21
            >= 329 and <= 359 => TropicalZodiacSign.Sagittarius, // Nov 22 - Dec 21
            >= 360 or <= 19 => TropicalZodiacSign.Capricorn,  // Dec 22 - Jan 19
            >= 20 and <= 49 => TropicalZodiacSign.Aquarius,   // Jan 20 - Feb 18
            >= 50 and <= 79 => TropicalZodiacSign.Pisces,     // Feb 19 - Mar 20
            _ => TropicalZodiacSign.Aries
        };
    }

    private TropicalElement GetTropicalElement(TropicalZodiacSign sign)
    {
        return sign switch
        {
            TropicalZodiacSign.Aries or TropicalZodiacSign.Leo or TropicalZodiacSign.Sagittarius => TropicalElement.Fire,
            TropicalZodiacSign.Taurus or TropicalZodiacSign.Virgo or TropicalZodiacSign.Capricorn => TropicalElement.Earth,
            TropicalZodiacSign.Gemini or TropicalZodiacSign.Libra or TropicalZodiacSign.Aquarius => TropicalElement.Air,
            TropicalZodiacSign.Cancer or TropicalZodiacSign.Scorpio or TropicalZodiacSign.Pisces => TropicalElement.Water,
            _ => TropicalElement.Fire
        };
    }

    private TropicalQuality GetTropicalQuality(TropicalZodiacSign sign)
    {
        return sign switch
        {
            TropicalZodiacSign.Aries or TropicalZodiacSign.Cancer or TropicalZodiacSign.Libra or TropicalZodiacSign.Capricorn => TropicalQuality.Cardinal,
            TropicalZodiacSign.Taurus or TropicalZodiacSign.Leo or TropicalZodiacSign.Scorpio or TropicalZodiacSign.Aquarius => TropicalQuality.Fixed,
            TropicalZodiacSign.Gemini or TropicalZodiacSign.Virgo or TropicalZodiacSign.Sagittarius or TropicalZodiacSign.Pisces => TropicalQuality.Mutable,
            _ => TropicalQuality.Cardinal
        };
    }

    private int CalculateBodyAttribute(string attribute, TropicalZodiacSign sign, TimeSpan birthTime)
    {
        var baseValue = _random.Next(30, 71);
        var hourModifier = (int)(birthTime.TotalHours * 2);
        
        var signModifier = sign switch
        {
            TropicalZodiacSign.Aries or TropicalZodiacSign.Leo => attribute == "strength" ? 20 : 10,
            TropicalZodiacSign.Taurus or TropicalZodiacSign.Capricorn => attribute == "constitution" ? 20 : 10,
            TropicalZodiacSign.Gemini or TropicalZodiacSign.Sagittarius => attribute == "agility" ? 20 : 10,
            TropicalZodiacSign.Cancer or TropicalZodiacSign.Virgo => attribute == "endurance" ? 20 : 10,
            _ => 5
        };
        
        return Math.Max(1, Math.Min(100, baseValue + signModifier + hourModifier));
    }

    private SiderealZodiacSign GetSiderealZodiacSign(DateTime birthDate)
    {
        // Apply approximate 24-degree ayanamsa adjustment for sidereal calculation
        var dayOfYear = birthDate.DayOfYear + 24; // Approximate ayanamsa adjustment
        if (dayOfYear > 365) dayOfYear -= 365;
        
        return dayOfYear switch
        {
            >= 104 and <= 134 => SiderealZodiacSign.Aries,
            >= 135 and <= 165 => SiderealZodiacSign.Taurus,
            >= 166 and <= 196 => SiderealZodiacSign.Gemini,
            >= 197 and <= 227 => SiderealZodiacSign.Cancer,
            >= 228 and <= 258 => SiderealZodiacSign.Leo,
            >= 259 and <= 289 => SiderealZodiacSign.Virgo,
            >= 290 and <= 320 => SiderealZodiacSign.Libra,
            >= 321 and <= 351 => SiderealZodiacSign.Scorpio,
            >= 352 or <= 18 => SiderealZodiacSign.Sagittarius,
            >= 19 and <= 48 => SiderealZodiacSign.Capricorn,
            >= 49 and <= 78 => SiderealZodiacSign.Aquarius,
            >= 79 and <= 103 => SiderealZodiacSign.Pisces,
            _ => SiderealZodiacSign.Aries
        };
    }

    private Nakshatra GetNakshatra(DateTime birthDate, TimeSpan birthTime)
    {
        var nakshatraIndex = (birthDate.DayOfYear + (int)birthTime.TotalHours) % 27;
        return (Nakshatra)nakshatraIndex;
    }

    private string GetCurrentDasha(DateTime birthDate)
    {
        var dashas = new[] { "Mercury", "Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn" };
        var dashaIndex = (DateTime.Now.Year - birthDate.Year) % dashas.Length;
        return dashas[dashaIndex];
    }

    private int CalculateMindAttribute(string attribute, SiderealZodiacSign sign, Nakshatra nakshatra, TimeSpan birthTime)
    {
        var baseValue = _random.Next(25, 76);
        var nakshatraModifier = ((int)nakshatra % 4) * 5;
        
        var signModifier = sign switch
        {
            SiderealZodiacSign.Gemini or SiderealZodiacSign.Virgo => attribute == "intellect" ? 20 : 10,
            SiderealZodiacSign.Cancer or SiderealZodiacSign.Pisces => attribute == "intuition" ? 20 : 10,
            SiderealZodiacSign.Capricorn or SiderealZodiacSign.Virgo => attribute == "focus" ? 20 : 10,
            SiderealZodiacSign.Leo or SiderealZodiacSign.Aquarius => attribute == "creativity" ? 20 : 10,
            _ => 5
        };
        
        return Math.Max(1, Math.Min(100, baseValue + signModifier + nakshatraModifier));
    }

    private string GetNorthNodePosition(DateTime birthDate)
    {
        var signs = new[] { "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", 
                           "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces" };
        
        var nodeIndex = (birthDate.Year * 12 + birthDate.Month) % 12;
        return signs[nodeIndex];
    }

    private string GetSouthNodePosition(DateTime birthDate)
    {
        var signs = new[] { "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces",
                           "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo" };
        
        var nodeIndex = (birthDate.Year * 12 + birthDate.Month) % 12;
        return signs[nodeIndex];
    }

    private DragonEnergyType GetDragonEnergyFromNodes(string northNode, string southNode)
    {
        var fireSignsMap = new Dictionary<string, DragonEnergyType>
        {
            { "Aries", DragonEnergyType.FireDragon },
            { "Leo", DragonEnergyType.FireDragon },
            { "Sagittarius", DragonEnergyType.FireDragon },
            { "Taurus", DragonEnergyType.EarthDragon },
            { "Virgo", DragonEnergyType.EarthDragon },
            { "Capricorn", DragonEnergyType.EarthDragon },
            { "Gemini", DragonEnergyType.AirDragon },
            { "Libra", DragonEnergyType.AirDragon },
            { "Aquarius", DragonEnergyType.AirDragon },
            { "Cancer", DragonEnergyType.WaterDragon },
            { "Scorpio", DragonEnergyType.WaterDragon },
            { "Pisces", DragonEnergyType.WaterDragon }
        };
        
        return fireSignsMap.TryGetValue(northNode, out var energy) ? energy : DragonEnergyType.FireDragon;
    }

    private int CalculateHeartAttribute(string attribute, string northNode, string southNode, TimeSpan birthTime)
    {
        var baseValue = _random.Next(20, 81);
        var timeModifier = (int)(birthTime.TotalMinutes % 60);
        
        var modifier = northNode switch
        {
            "Cancer" or "Scorpio" or "Pisces" => attribute == "depth" ? 25 : 15,
            "Aries" or "Leo" or "Sagittarius" => attribute == "passion" ? 15 : 10,
            "Libra" or "Aquarius" or "Gemini" => attribute == "empathy" ? 15 : 10,
            _ => 5
        };
        return Math.Max(1, Math.Min(100, baseValue + modifier));
    }

    private string GetSoulPurpose(string northNode, string southNode)
    {
        return northNode switch
        {
            "Aries" => "Leadership and pioneering new paths",
            "Taurus" => "Building stability and appreciating beauty",
            "Gemini" => "Communication and sharing knowledge",
            "Cancer" => "Nurturing and emotional healing",
            "Leo" => "Creative self-expression and inspiration",
            "Virgo" => "Service and perfecting skills",
            "Libra" => "Creating harmony and balance",
            "Scorpio" => "Transformation and depth exploration",
            "Sagittarius" => "Seeking truth and expanding consciousness",
            "Capricorn" => "Building lasting structures and authority",
            "Aquarius" => "Innovation and humanitarian service",
            "Pisces" => "Spiritual transcendence and compassion",
            _ => "Discovering your unique path"
        };
    }

    #endregion
}

#region External API Response Models

public class ExternalTropicalResult
{
    public string ZodiacSign { get; set; } = string.Empty;
    public string Element { get; set; } = string.Empty;
    public string Quality { get; set; } = string.Empty;
    public int PhysicalStrength { get; set; }
    public int Constitution { get; set; }
    public int Agility { get; set; }
    public int Endurance { get; set; }
}

public class ExternalSiderealResult
{
    public string SiderealSign { get; set; } = string.Empty;
    public string Nakshatra { get; set; } = string.Empty;
    public string CurrentDasha { get; set; } = string.Empty;
    public int Intellect { get; set; }
    public int Intuition { get; set; }
    public int Focus { get; set; }
    public int Creativity { get; set; }
}

public class ExternalNodalResult
{
    public string NorthNode { get; set; } = string.Empty;
    public string SouthNode { get; set; } = string.Empty;
    public int EmotionalDepth { get; set; }
    public int Passion { get; set; }
    public int Empathy { get; set; }
}

#endregion
using FSO.Interface.Files;
using FSO.Interface.Files.Models;
using System.IO;

namespace ModularSimWorld.Components;

/// <summary>
/// Handles file system operations using FSO.Files.Interface
/// </summary>
public class FileSystemHandler
{
    private readonly Dictionary<string, byte[]> _virtualFiles;
    private readonly Dictionary<string, DBPFEntry> _dbpfEntries;
    
    public FileSystemHandler()
    {
        _virtualFiles = new Dictionary<string, byte[]>();
        _dbpfEntries = new Dictionary<string, DBPFEntry>();
        Console.WriteLine("[FileSystem] FileSystemHandler initialized with FSO.Files.Interface");
    }
    
    /// <summary>
    /// Simulates loading a file from the virtual file system
    /// </summary>
    public byte[]? LoadFile(string path)
    {
        if (_virtualFiles.TryGetValue(path, out byte[]? data))
        {
            Console.WriteLine($"[FileSystem] Loaded file: {path} ({data.Length} bytes)");
            return data;
        }
        
        Console.WriteLine($"[FileSystem] File not found: {path}");
        return null;
    }
    
    /// <summary>
    /// Stores a file in the virtual file system with DBPF entry
    /// </summary>
    public void StoreFile(string path, byte[] data)
    {
        _virtualFiles[path] = data;
        
        // Create a DBPF entry for this file (simulated with FSO.Files.Interface.Models)
        var typeId = DBPFTypeID.XA; // Use an appropriate enum value from FSO
        var groupId = DBPFGroupID.Custom; // Use an appropriate enum value from FSO
        var instanceId = (uint)Path.GetFileName(path).GetHashCode();
        
        var dbpfEntry = new DBPFEntry(
            TypeId: typeId,
            GroupId: groupId,
            instanceId: instanceId,
            FileOffset: 0,
            FileSize: (uint)data.Length
        );
        
        _dbpfEntries[path] = dbpfEntry;
        Console.WriteLine($"[FileSystem] Stored file: {path} ({data.Length} bytes) with DBPF entry");
    }
    
    /// <summary>
    /// Lists all files in the virtual file system
    /// </summary>
    public IEnumerable<string> ListFiles()
    {
        return _virtualFiles.Keys;
    }
    
    /// <summary>
    /// Gets DBPF entry for a file
    /// </summary>
    public DBPFEntry? GetDBPFEntry(string path)
    {
        return _dbpfEntries.TryGetValue(path, out var entry) ? entry : null;
    }
    
    /// <summary>
    /// Gets file count
    /// </summary>
    public int FileCount => _virtualFiles.Count;
    
    /// <summary>
    /// Gets DBPF entry information for display
    /// </summary>
    public string GetFileInfo(string path)
    {
        if (_dbpfEntries.TryGetValue(path, out var entry))
        {
            return $"DBPF Entry - Type: {entry.TypeId}, Group: {entry.GroupId}, Instance: {entry.instanceId}, Size: {entry.FileSize}";
        }
        return "No DBPF entry found";
    }
}
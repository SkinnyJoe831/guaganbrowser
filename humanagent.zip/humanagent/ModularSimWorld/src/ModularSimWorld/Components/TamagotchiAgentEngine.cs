using System.Text.Json;

namespace ModularSimWorld.Components;

/// <summary>
/// Tamagotchi-style autonomous agent that evolves based on user care and cosmic conditions
/// Combines DNA (codon-gate mapping) with field resonance simulation
/// </summary>
public class TamagotchiAgentEngine
{
    private readonly Random _random;
    private readonly AstrologicalWeatherService _weatherService;
    private readonly Dictionary<string, TamagotchiAgent> _activeAgents;

    public TamagotchiAgentEngine(AstrologicalWeatherService weatherService)
    {
        _random = new Random();
        _weatherService = weatherService;
        _activeAgents = new Dictionary<string, TamagotchiAgent>();
        Console.WriteLine("[Tamagotchi] Agent Engine initialized");
    }

    /// <summary>
    /// Creates a Tamagotchi agent from astrological character DNA
    /// </summary>
    public TamagotchiAgent CreateAgent(AstrologicalCharacter character)
    {
        var agent = new TamagotchiAgent
        {
            Id = Guid.NewGuid().ToString(),
            Name = character.Name,
            DNA = ExtractDNA(character),
            CurrentMood = AgentMood.Neutral,
            Energy = 80,
            Happiness = 70,
            Health = 90,
            Resonance = 50,
            Age = 0,
            Evolution = 0,
            Traits = InitializeTraits(character),
            Gates = InitializeGates(character),
            CreatedAt = DateTime.UtcNow,
            LastCareTime = DateTime.UtcNow
        };

        _activeAgents[agent.Id] = agent;
        Console.WriteLine($"[Tamagotchi] Created agent: {agent.Name} with {agent.DNA.PrimaryElement} DNA");
        return agent;
    }

    /// <summary>
    /// Daily care loop - feed, play, interact with agent
    /// </summary>
    public async Task<CareResult> CareForAgent(string agentId, CareAction action)
    {
        if (!_activeAgents.TryGetValue(agentId, out var agent))
            return new CareResult { Success = false, Message = "Agent not found" };

        var weather = await _weatherService.GetCurrentWeatherAsync();
        var result = ProcessCareAction(agent, action, weather);
        
        // Update agent state
        UpdateAgentFromCare(agent, result);
        agent.LastCareTime = DateTime.UtcNow;

        // Check for evolution
        if (ShouldEvolve(agent))
        {
            var evolution = EvolveAgent(agent);
            result.EvolutionOccurred = true;
            result.EvolutionDescription = evolution;
        }

        return result;
    }

    /// <summary>
    /// Get agent status and current expression
    /// </summary>
    public AgentStatus GetAgentStatus(string agentId)
    {
        if (!_activeAgents.TryGetValue(agentId, out var agent))
            return new AgentStatus { Found = false };

        var timeSinceLastCare = DateTime.UtcNow - agent.LastCareTime;
        var needsAttention = timeSinceLastCare.TotalHours > 8;
        
        return new AgentStatus
        {
            Found = true,
            Agent = agent,
            CurrentExpression = GenerateExpression(agent),
            VoiceLine = GenerateVoiceLine(agent),
            MoodAura = GetMoodAura(agent),
            NeedsAttention = needsAttention,
            TimeSinceLastCare = timeSinceLastCare
        };
    }

    /// <summary>
    /// Autonomous behavior tick - agent acts on its own
    /// </summary>
    public async Task ProcessAutonomousTick()
    {
        foreach (var agent in _activeAgents.Values)
        {
            await ProcessAgentAutonomy(agent);
        }
    }

    #region Private Methods

    private AgentDNA ExtractDNA(AstrologicalCharacter character)
    {
        return new AgentDNA
        {
            PrimaryElement = character.BodyTraits.Element.ToString(),
            SecondaryElement = character.HeartTraits.DragonEnergy.ToString(),
            ZodiacSeed = character.BodyTraits.ZodiacSign.ToString(),
            NakshatraSeed = character.MindTraits.Nakshatra.ToString(),
            Codons = GenerateCodons(character),
            BaseResonance = CalculateBaseResonance(character)
        };
    }

    private List<string> GenerateCodons(AstrologicalCharacter character)
    {
        var codons = new List<string>();
        
        // Generate codons from astrological data
        codons.Add($"BODY-{character.BodyTraits.ZodiacSign}-{character.BodyTraits.Element}");
        codons.Add($"MIND-{character.MindTraits.Nakshatra}-{character.MindTraits.SiderealSign}");
        codons.Add($"HEART-{character.HeartTraits.DragonEnergy}-{character.HeartTraits.NorthNode}");
        
        return codons;
    }

    private int CalculateBaseResonance(AstrologicalCharacter character)
    {
        var bodyResonance = character.BodyTraits.PhysicalStrength;
        var mindResonance = character.MindTraits.Intellect;
        var heartResonance = character.HeartTraits.EmotionalDepth;
        
        return (bodyResonance + mindResonance + heartResonance) / 3;
    }

    private Dictionary<string, int> InitializeTraits(AstrologicalCharacter character)
    {
        return new Dictionary<string, int>
        {
            ["Curiosity"] = character.MindTraits.Intellect + _random.Next(-10, 11),
            ["Playfulness"] = character.HeartTraits.Passion + _random.Next(-10, 11),
            ["Stability"] = character.BodyTraits.Constitution + _random.Next(-10, 11),
            ["Empathy"] = character.HeartTraits.Empathy + _random.Next(-10, 11),
            ["Independence"] = character.BodyTraits.Agility + _random.Next(-10, 11)
        };
    }

    private Dictionary<string, bool> InitializeGates(AstrologicalCharacter character)
    {
        var gates = new Dictionary<string, bool>();
        
        // Map astrological data to Human Design-style gates
        gates["Gate1_Creativity"] = character.MindTraits.Creativity > 70;
        gates["Gate2_Direction"] = character.BodyTraits.PhysicalStrength > 70;
        gates["Gate3_Ordering"] = character.BodyTraits.Constitution > 70;
        gates["Gate4_Understanding"] = character.MindTraits.Intellect > 70;
        gates["Gate5_Patterns"] = character.MindTraits.Focus > 70;
        gates["Gate6_Emotions"] = character.HeartTraits.EmotionalDepth > 70;
        
        return gates;
    }

    private CareResult ProcessCareAction(TamagotchiAgent agent, CareAction action, AstrologicalWeatherReport weather)
    {
        var result = new CareResult { Success = true, Action = action };
        var effectiveness = CalculateActionEffectiveness(agent, action, weather);
        
        switch (action)
        {
            case CareAction.Feed:
                result.EnergyChange = (int)(20 * effectiveness);
                result.HealthChange = (int)(15 * effectiveness);
                result.Message = effectiveness > 1.2 ? 
                    $"{agent.Name} absolutely loves this cosmic meal!" :
                    $"{agent.Name} enjoys the nourishment.";
                break;

            case CareAction.Play:
                result.HappinessChange = (int)(25 * effectiveness);
                result.EnergyChange = (int)(-10 * effectiveness);
                result.Message = effectiveness > 1.2 ?
                    $"{agent.Name} is having the time of their life!" :
                    $"{agent.Name} enjoys playtime.";
                break;

            case CareAction.Rest:
                result.EnergyChange = (int)(30 * effectiveness);
                result.HappinessChange = (int)(10 * effectiveness);
                result.Message = $"{agent.Name} feels refreshed and peaceful.";
                break;

            case CareAction.Meditate:
                result.ResonanceChange = (int)(15 * effectiveness);
                result.HappinessChange = (int)(20 * effectiveness);
                result.Message = effectiveness > 1.2 ?
                    $"{agent.Name} achieves deep cosmic alignment!" :
                    $"{agent.Name} finds inner peace.";
                break;

            case CareAction.Learn:
                result.EvolutionChange = (int)(10 * effectiveness);
                result.EnergyChange = (int)(-5 * effectiveness);
                result.Message = $"{agent.Name} expands their consciousness.";
                break;
        }

        return result;
    }

    private double CalculateActionEffectiveness(TamagotchiAgent agent, CareAction action, AstrologicalWeatherReport weather)
    {
        var effectiveness = 1.0;
        
        // Cosmic alignment bonus
        var alignmentBonus = agent.DNA.PrimaryElement.ToLower() == weather.DominantElement.ToString().ToLower() ? 0.3 : 0.0;
        effectiveness += alignmentBonus;
        
        // Moon phase effects
        effectiveness += weather.MoonPhase switch
        {
            MoonPhase.FullMoon => 0.2,
            MoonPhase.NewMoon => action == CareAction.Meditate ? 0.3 : 0.1,
            _ => 0.0
        };
        
        // Energy level effects
        if (agent.Energy < 30 && (action == CareAction.Feed || action == CareAction.Rest))
            effectiveness += 0.2;
        
        return effectiveness;
    }

    private void UpdateAgentFromCare(TamagotchiAgent agent, CareResult result)
    {
        agent.Energy = Math.Max(0, Math.Min(100, agent.Energy + result.EnergyChange));
        agent.Happiness = Math.Max(0, Math.Min(100, agent.Happiness + result.HappinessChange));
        agent.Health = Math.Max(0, Math.Min(100, agent.Health + result.HealthChange));
        agent.Resonance = Math.Max(0, Math.Min(100, agent.Resonance + result.ResonanceChange));
        agent.Evolution = Math.Max(0, Math.Min(100, agent.Evolution + result.EvolutionChange));
        
        // Update mood based on stats
        agent.CurrentMood = DetermineMood(agent);
        
        // Increment age
        agent.Age += 0.1;
    }

    private AgentMood DetermineMood(TamagotchiAgent agent)
    {
        var averageWellbeing = (agent.Energy + agent.Happiness + agent.Health) / 3.0;
        
        return averageWellbeing switch
        {
            > 80 => AgentMood.Joyful,
            > 60 => AgentMood.Happy,
            > 40 => AgentMood.Neutral,
            > 20 => AgentMood.Sad,
            _ => AgentMood.Distressed
        };
    }

    private bool ShouldEvolve(TamagotchiAgent agent)
    {
        return agent.Evolution >= 80 && _random.NextDouble() < 0.3;
    }

    private string EvolveAgent(TamagotchiAgent agent)
    {
        agent.Evolution = 0; // Reset evolution meter
        
        // Evolve traits
        var traitToEvolve = agent.Traits.OrderBy(t => _random.Next()).First();
        agent.Traits[traitToEvolve.Key] = Math.Min(100, traitToEvolve.Value + _random.Next(10, 21));
        
        // Possibly activate new gate
        var inactiveGates = agent.Gates.Where(g => !g.Value).ToList();
        if (inactiveGates.Any() && _random.NextDouble() < 0.4)
        {
            var gateToActivate = inactiveGates[_random.Next(inactiveGates.Count)];
            agent.Gates[gateToActivate.Key] = true;
            return $"{agent.Name} has activated their {gateToActivate.Key.Replace("_", " ")} and evolved {traitToEvolve.Key}!";
        }
        
        return $"{agent.Name} has evolved their {traitToEvolve.Key} through cosmic resonance!";
    }

    private string GenerateExpression(TamagotchiAgent agent)
    {
        return agent.CurrentMood switch
        {
            AgentMood.Joyful => "✨ *radiating pure joy* ✨",
            AgentMood.Happy => "😊 *contentedly glowing*",
            AgentMood.Neutral => "🌟 *calmly existing*",
            AgentMood.Sad => "🌧️ *quietly contemplating*",
            AgentMood.Distressed => "⚡ *needs attention urgently*",
            _ => "🌀 *in mysterious state*"
        };
    }

    private string GenerateVoiceLine(TamagotchiAgent agent)
    {
        var elementVoice = agent.DNA.PrimaryElement switch
        {
            "Fire" => "burns with",
            "Water" => "flows with", 
            "Earth" => "grounds in",
            "Air" => "dances with",
            _ => "resonates with"
        };

        var trait = agent.Traits.OrderByDescending(t => t.Value).First();
        
        return agent.CurrentMood switch
        {
            AgentMood.Joyful => $"My {agent.DNA.PrimaryElement} spirit {elementVoice} pure {trait.Key.ToLower()}! ⭐",
            AgentMood.Happy => $"I {elementVoice} warm {trait.Key.ToLower()} today~ 🌟",
            AgentMood.Neutral => $"My {agent.DNA.PrimaryElement} essence {elementVoice} steady {trait.Key.ToLower()}...",
            AgentMood.Sad => $"My {trait.Key.ToLower()} feels dim... could use some care 💫",
            AgentMood.Distressed => $"Help! My {agent.DNA.PrimaryElement} energy is fading! 🆘",
            _ => $"I am {agent.DNA.PrimaryElement}... I am {trait.Key.ToLower()}..."
        };
    }

    private string GetMoodAura(TamagotchiAgent agent)
    {
        var element = agent.DNA.PrimaryElement.ToLower();
        var mood = agent.CurrentMood;
        
        return (element, mood) switch
        {
            ("fire", AgentMood.Joyful) => "🔥✨ Blazing Golden Flames ✨🔥",
            ("fire", AgentMood.Happy) => "🔥 Warm Orange Glow 🔥",
            ("fire", AgentMood.Neutral) => "🕯️ Steady Flame",
            ("fire", _) => "💨 Dim Embers",
            
            ("water", AgentMood.Joyful) => "💎✨ Crystalline Rapids ✨💎",
            ("water", AgentMood.Happy) => "💙 Gentle Blue Streams 💙",
            ("water", AgentMood.Neutral) => "🌊 Calm Waters",
            ("water", _) => "🌫️ Misty Vapor",
            
            ("earth", AgentMood.Joyful) => "🌸✨ Blooming Garden ✨🌸", 
            ("earth", AgentMood.Happy) => "🌱 Rich Green Growth 🌱",
            ("earth", AgentMood.Neutral) => "🗻 Solid Mountain",
            ("earth", _) => "🏔️ Barren Stone",
            
            ("air", AgentMood.Joyful) => "🌈✨ Rainbow Winds ✨🌈",
            ("air", AgentMood.Happy) => "💨 Playful Breezes 💨", 
            ("air", AgentMood.Neutral) => "🌬️ Gentle Currents",
            ("air", _) => "⛅ Still Air",
            
            _ => "🌟 Cosmic Essence 🌟"
        };
    }

    private async Task ProcessAgentAutonomy(TamagotchiAgent agent)
    {
        var timeSinceLastCare = DateTime.UtcNow - agent.LastCareTime;
        
        // Natural decay over time
        if (timeSinceLastCare.TotalHours >= 1)
        {
            agent.Energy = Math.Max(0, agent.Energy - 1);
            agent.Happiness = Math.Max(0, agent.Happiness - 1);
            
            if (timeSinceLastCare.TotalHours >= 12)
            {
                agent.Health = Math.Max(0, agent.Health - 2);
                agent.CurrentMood = AgentMood.Distressed;
            }
        }
        
        // Autonomous actions based on traits and gates
        if (_random.NextDouble() < 0.1) // 10% chance per tick
        {
            await PerformAutonomousAction(agent);
        }
    }

    private async Task PerformAutonomousAction(TamagotchiAgent agent)
    {
        var weather = await _weatherService.GetCurrentWeatherAsync();
        var dominantTrait = agent.Traits.OrderByDescending(t => t.Value).First();
        
        var action = dominantTrait.Key switch
        {
            "Curiosity" => "explores cosmic patterns",
            "Playfulness" => "creates joyful energy",
            "Stability" => "strengthens its foundation",
            "Empathy" => "sends loving vibrations",
            "Independence" => "charts its own path",
            _ => "resonates with the universe"
        };

        Console.WriteLine($"[Autonomous] {agent.Name} {action} on their own! (Energy: {agent.Energy}%)");
    }

    public List<TamagotchiAgent> GetActiveAgents() => _activeAgents.Values.ToList();

    /// <summary>
    /// Applies notebook reflection - journal entries affect agent stats
    /// </summary>
    public NotebookReflectionResult ApplyNotebookReflection(string agentId, string journalEntry)
    {
        if (!_activeAgents.TryGetValue(agentId, out var agent))
            return new NotebookReflectionResult { Success = false, Message = "Agent not found" };

        var result = new NotebookReflectionResult 
        { 
            Success = true, 
            JournalEntry = journalEntry,
            AgentName = agent.Name
        };

        // Analyze emotional content and apply reflections
        var words = journalEntry.ToLower();
        var changes = new List<string>();

        // Negative emotions and states
        if (ContainsWords(words, "hungry", "starving", "food", "eat"))
        {
            var change = Math.Max(-15, -agent.Energy / 4);
            agent.Energy = Math.Max(0, agent.Energy + change);
            changes.Add($"Hunger reflection: Energy {change:+0;-#}");
            result.EnergyChange += change;
        }

        if (ContainsWords(words, "tired", "exhausted", "sleep", "fatigue"))
        {
            var change = Math.Max(-20, -agent.Energy / 3);
            agent.Energy = Math.Max(0, agent.Energy + change);
            changes.Add($"Fatigue reflection: Energy {change:+0;-#}");
            result.EnergyChange += change;
        }

        if (ContainsWords(words, "sad", "lonely", "depressed", "hurt"))
        {
            var change = Math.Max(-15, -agent.Happiness / 4);
            agent.Happiness = Math.Max(0, agent.Happiness + change);
            changes.Add($"Sadness reflection: Happiness {change:+0;-#}");
            result.HappinessChange += change;
        }

        if (ContainsWords(words, "stress", "anxious", "worried", "overwhelmed"))
        {
            var change = Math.Max(-12, -agent.Resonance / 4);
            agent.Resonance = Math.Max(0, agent.Resonance + change);
            changes.Add($"Stress reflection: Resonance {change:+0;-#}");
            result.ResonanceChange += change;
        }

        if (ContainsWords(words, "sick", "pain", "ill", "unwell"))
        {
            var change = Math.Max(-10, -agent.Health / 5);
            agent.Health = Math.Max(0, agent.Health + change);
            changes.Add($"Illness reflection: Health {change:+0;-#}");
            result.HealthChange += change;
        }

        // Positive emotions and states
        if (ContainsWords(words, "love", "loved", "adore", "affection"))
        {
            var change = Math.Min(25, (100 - agent.Happiness) / 3);
            agent.Happiness = Math.Min(100, agent.Happiness + change);
            changes.Add($"Love reflection: Happiness +{change}");
            result.HappinessChange += change;
        }

        if (ContainsWords(words, "happy", "joy", "excited", "elated", "blissful"))
        {
            var change = Math.Min(20, (100 - agent.Happiness) / 4);
            agent.Happiness = Math.Min(100, agent.Happiness + change);
            changes.Add($"Joy reflection: Happiness +{change}");
            result.HappinessChange += change;
        }

        if (ContainsWords(words, "peaceful", "calm", "serene", "tranquil"))
        {
            var change = Math.Min(18, (100 - agent.Resonance) / 3);
            agent.Resonance = Math.Min(100, agent.Resonance + change);
            changes.Add($"Peace reflection: Resonance +{change}");
            result.ResonanceChange += change;
        }

        if (ContainsWords(words, "energy", "energized", "powerful", "strong"))
        {
            var change = Math.Min(15, (100 - agent.Energy) / 4);
            agent.Energy = Math.Min(100, agent.Energy + change);
            changes.Add($"Energy reflection: Energy +{change}");
            result.EnergyChange += change;
        }

        if (ContainsWords(words, "dream", "dreaming", "vision", "imagine"))
        {
            var change = Math.Min(12, (100 - agent.Resonance) / 4);
            agent.Resonance = Math.Min(100, agent.Resonance + change);
            var evolutionChange = Math.Min(5, (100 - agent.Evolution) / 10);
            agent.Evolution = Math.Min(100, agent.Evolution + evolutionChange);
            changes.Add($"Dream reflection: Resonance +{change}, Evolution +{evolutionChange}");
            result.ResonanceChange += change;
            result.EvolutionChange += evolutionChange;
        }

        if (ContainsWords(words, "create", "creative", "art", "music", "inspiration"))
        {
            var change = Math.Min(10, (100 - agent.Evolution) / 5);
            agent.Evolution = Math.Min(100, agent.Evolution + change);
            changes.Add($"Creative reflection: Evolution +{change}");
            result.EvolutionChange += change;
        }

        if (ContainsWords(words, "grateful", "thankful", "blessed", "appreciate"))
        {
            var happyChange = Math.Min(15, (100 - agent.Happiness) / 4);
            var resonanceChange = Math.Min(10, (100 - agent.Resonance) / 5);
            agent.Happiness = Math.Min(100, agent.Happiness + happyChange);
            agent.Resonance = Math.Min(100, agent.Resonance + resonanceChange);
            changes.Add($"Gratitude reflection: Happiness +{happyChange}, Resonance +{resonanceChange}");
            result.HappinessChange += happyChange;
            result.ResonanceChange += resonanceChange;
        }

        // Update agent mood and calculate intensity
        agent.CurrentMood = DetermineMood(agent);
        agent.LastCareTime = DateTime.UtcNow; // Journal counts as interaction

        // Generate response based on changes
        result.Changes = changes;
        result.Message = GenerateReflectionMessage(agent, changes);
        result.Intensity = CalculateReflectionIntensity(result);

        Console.WriteLine($"[Notebook] {agent.Name} reflected on: \"{journalEntry[..Math.Min(30, journalEntry.Length)]}...\"");
        Console.WriteLine($"[Notebook] Changes: {string.Join(", ", changes)}");

        return result;
    }

    /// <summary>
    /// Get agent's current emotional resonance with journal patterns
    /// </summary>
    public AgentResonanceReport GetResonanceReport(string agentId)
    {
        if (!_activeAgents.TryGetValue(agentId, out var agent))
            return new AgentResonanceReport { Success = false, Message = "Agent not found" };

        return new AgentResonanceReport
        {
            Success = true,
            AgentName = agent.Name,
            CurrentResonance = agent.Resonance,
            EmotionalState = agent.CurrentMood.ToString(),
            ResonanceDescription = GetResonanceDescription(agent),
            SuggestedJournalThemes = GetSuggestedThemes(agent),
            ResonanceAura = GetMoodAura(agent)
        };
    }

    #region Notebook Reflection Helpers

    private bool ContainsWords(string text, params string[] words)
    {
        return words.Any(word => text.Contains(word));
    }

    private string GenerateReflectionMessage(TamagotchiAgent agent, List<string> changes)
    {
        if (!changes.Any())
            return $"{agent.Name} acknowledges your words but feels no immediate change.";

        var elementResponse = agent.DNA.PrimaryElement.ToLower() switch
        {
            "fire" => "ignites with resonance from your words",
            "water" => "flows deeper in response to your emotions", 
            "earth" => "grounds themselves in your shared experience",
            "air" => "dances with the energy of your thoughts",
            _ => "resonates with your inner state"
        };

        var intensity = changes.Count switch
        {
            >= 3 => "deeply",
            >= 2 => "noticeably", 
            _ => "subtly"
        };

        return $"{agent.Name} {intensity} {elementResponse}. Your journal entry has created ripples in their cosmic field.";
    }

    private int CalculateReflectionIntensity(NotebookReflectionResult result)
    {
        var totalChange = Math.Abs(result.EnergyChange) + Math.Abs(result.HappinessChange) + 
                         Math.Abs(result.HealthChange) + Math.Abs(result.ResonanceChange) + 
                         Math.Abs(result.EvolutionChange);
        return Math.Min(100, totalChange);
    }

    private string GetResonanceDescription(TamagotchiAgent agent)
    {
        return agent.Resonance switch
        {
            >= 80 => "Cosmic harmony - deeply attuned to universal frequencies",
            >= 60 => "Strong resonance - aligned with positive vibrations",
            >= 40 => "Moderate resonance - seeking deeper connection",
            >= 20 => "Weak resonance - struggling to find harmony",
            _ => "Resonance crisis - needs urgent spiritual care"
        };
    }

    private List<string> GetSuggestedThemes(TamagotchiAgent agent)
    {
        var suggestions = new List<string>();
        
        if (agent.Energy < 50) suggestions.Add("Rest and restoration");
        if (agent.Happiness < 50) suggestions.Add("Joy and celebration");
        if (agent.Health < 50) suggestions.Add("Healing and wellness");
        if (agent.Resonance < 50) suggestions.Add("Peace and harmony");
        if (agent.Evolution < 30) suggestions.Add("Dreams and creativity");
        
        if (!suggestions.Any())
        {
            suggestions.AddRange(new[] { "Gratitude", "Love", "Future dreams", "Creative inspirations" });
        }
        
        return suggestions;
    }

    #endregion

    #endregion
}

#region Data Models

public class AgentDNA
{
    public string PrimaryElement { get; set; } = string.Empty;
    public string SecondaryElement { get; set; } = string.Empty;
    public string ZodiacSeed { get; set; } = string.Empty;
    public string NakshatraSeed { get; set; } = string.Empty;
    public List<string> Codons { get; set; } = new();
    public int BaseResonance { get; set; }
}

public class CareResult
{
    public bool Success { get; set; }
    public CareAction Action { get; set; }
    public string Message { get; set; } = string.Empty;
    public int EnergyChange { get; set; }
    public int HappinessChange { get; set; }
    public int HealthChange { get; set; }
    public int ResonanceChange { get; set; }
    public int EvolutionChange { get; set; }
    public bool EvolutionOccurred { get; set; }
    public string EvolutionDescription { get; set; } = string.Empty;
}

public class AgentStatus
{
    public bool Found { get; set; }
    public TamagotchiAgent? Agent { get; set; }
    public string CurrentExpression { get; set; } = string.Empty;
    public string VoiceLine { get; set; } = string.Empty;
    public string MoodAura { get; set; } = string.Empty;
    public bool NeedsAttention { get; set; }
    public TimeSpan TimeSinceLastCare { get; set; }
}

public enum AgentMood
{
    Joyful, Happy, Neutral, Sad, Distressed
}

public enum CareAction
{
    Feed, Play, Rest, Meditate, Learn
}

public class NotebookReflectionResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string JournalEntry { get; set; } = string.Empty;
    public string AgentName { get; set; } = string.Empty;
    public int EnergyChange { get; set; }
    public int HappinessChange { get; set; }
    public int HealthChange { get; set; }
    public int ResonanceChange { get; set; }
    public int EvolutionChange { get; set; }
    public List<string> Changes { get; set; } = new();
    public int Intensity { get; set; }
}

public class AgentResonanceReport
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string AgentName { get; set; } = string.Empty;
    public int CurrentResonance { get; set; }
    public string EmotionalState { get; set; } = string.Empty;
    public string ResonanceDescription { get; set; } = string.Empty;
    public List<string> SuggestedJournalThemes { get; set; } = new();
    public string ResonanceAura { get; set; } = string.Empty;
}

#endregion
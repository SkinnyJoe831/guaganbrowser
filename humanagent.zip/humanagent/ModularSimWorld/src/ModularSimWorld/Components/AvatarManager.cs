using FSO.Interface.Vitaboy;
using FSO.Interface.Vitaboy.Models;
using System.Numerics;

namespace ModularSimWorld.Components;

/// <summary>
/// Manages avatars and their skeletons using FSO.Vitaboy.Interface
/// </summary>
public class AvatarManager
{
    private readonly Dictionary<string, SimAvatar> _avatars;
    private readonly Dictionary<string, Skeleton> _skeletons;
    private int _nextAvatarId = 1;
    
    public AvatarManager()
    {
        _avatars = new Dictionary<string, SimAvatar>();
        _skeletons = new Dictionary<string, Skeleton>();
        Console.WriteLine("[Avatar] AvatarManager initialized with FSO.Vitaboy.Interface");
    }
    
    /// <summary>
    /// Creates a new avatar in the simulation world
    /// </summary>
    public string CreateAvatar(string name, AvatarType type = AvatarType.Adult)
    {
        var avatarId = $"avatar_{_nextAvatarId++}";
        var skeleton = CreateDefaultSkeleton();
        _skeletons[avatarId] = skeleton;
        
        var avatar = new SimAvatar
        {
            Id = avatarId,
            Name = name,
            Type = type,
            Position = new Vector3D(0, 0, 0),
            SkeletonId = avatarId
        };
        
        _avatars[avatarId] = avatar;
        Console.WriteLine($"[Avatar] Created {type} avatar: {name} (ID: {avatarId})");
        return avatarId;
    }
    
    /// <summary>
    /// Moves an avatar to a new position
    /// </summary>
    public bool MoveAvatar(string avatarId, Vector3D newPosition)
    {
        if (_avatars.TryGetValue(avatarId, out var avatar))
        {
            var oldPos = avatar.Position;
            avatar.Position = newPosition;
            Console.WriteLine($"[Avatar] Moved {avatar.Name} from ({oldPos.X}, {oldPos.Y}, {oldPos.Z}) to ({newPosition.X}, {newPosition.Y}, {newPosition.Z})");
            return true;
        }
        
        Console.WriteLine($"[Avatar] Avatar not found: {avatarId}");
        return false;
    }
    
    /// <summary>
    /// Gets avatar information
    /// </summary>
    public SimAvatar? GetAvatar(string avatarId)
    {
        return _avatars.TryGetValue(avatarId, out var avatar) ? avatar : null;
    }
    
    /// <summary>
    /// Lists all avatars
    /// </summary>
    public IEnumerable<SimAvatar> GetAllAvatars()
    {
        return _avatars.Values;
    }
    
    private Skeleton CreateDefaultSkeleton()
    {
        var rootBone = new Bone(
            Unknown: 0,
            Name: "Root",
            ParentName: "",
            HasProps: 0,
            Translation: Vector2.Zero,
            Rotation: Quaternion.Identity,
            CanTranslate: 1,
            CanRotate: 1,
            CanBlend: 0,
            Index: 0,
            WiggleValue: 0.0f,
            WigglePower: 0.0f,
            Children: Array.Empty<Bone>(),
            AbsolutePosition: Vector3.Zero,
            AbsoluteMatrix: Matrix4x4.Identity
        );

        var spineBone = new Bone(
            Unknown: 0,
            Name: "Spine",
            ParentName: "Root",
            HasProps: 0,
            Translation: Vector2.Zero,
            Rotation: Quaternion.Identity,
            CanTranslate: 1,
            CanRotate: 1,
            CanBlend: 0,
            Index: 1,
            WiggleValue: 0.0f,
            WigglePower: 0.0f,
            Children: Array.Empty<Bone>(),
            AbsolutePosition: new Vector3(0, 1, 0),
            AbsoluteMatrix: Matrix4x4.Identity
        );

        var headBone = new Bone(
            Unknown: 0,
            Name: "Head",
            ParentName: "Spine",
            HasProps: 0,
            Translation: Vector2.Zero,
            Rotation: Quaternion.Identity,
            CanTranslate: 1,
            CanRotate: 1,
            CanBlend: 0,
            Index: 2,
            WiggleValue: 0.0f,
            WigglePower: 0.0f,
            Children: Array.Empty<Bone>(),
            AbsolutePosition: new Vector3(0, 2, 0),
            AbsoluteMatrix: Matrix4x4.Identity
        );

        return new Skeleton(
            Name: "DefaultSkeleton",
            Bones: new[] { rootBone, spineBone, headBone },
            RootBone: rootBone
        );
    }
    
    /// <summary>
    /// Gets the FSO skeleton for an avatar
    /// </summary>
    public Skeleton? GetAvatarSkeleton(string avatarId)
    {
        return _skeletons.TryGetValue(avatarId, out var skeleton) ? skeleton : null;
    }
    
    /// <summary>
    /// Gets skeleton information for display
    /// </summary>
    public string GetSkeletonInfo(string avatarId)
    {
        if (_skeletons.TryGetValue(avatarId, out var skeleton))
        {
            return $"Skeleton '{skeleton.Name}' with {skeleton.Bones.Count()} bones: {string.Join(", ", skeleton.Bones.Select(b => b.Name))}";
        }
        return "No skeleton found";
    }
    
    public int AvatarCount => _avatars.Count;
}

/// <summary>
/// Represents a simulation avatar
/// </summary>
public class SimAvatar
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public AvatarType Type { get; set; }
    public Vector3D Position { get; set; }
    public string SkeletonId { get; set; } = string.Empty;
}

/// <summary>
/// Avatar types in the simulation
/// </summary>
public enum AvatarType
{
    Child,
    Teen,
    Adult,
    Elder
}

/// <summary>
/// Simple 3D vector for positioning
/// </summary>
public struct Vector3D
{
    public float X { get; set; }
    public float Y { get; set; }
    public float Z { get; set; }
    
    public Vector3D(float x, float y, float z)
    {
        X = x;
        Y = y;
        Z = z;
    }
}
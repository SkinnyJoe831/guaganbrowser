"""
64-Codon Progressive Resonance with GameGAN Overlays
Each codon scene = previous codon + new resonance elements
Rendered in Sims-style with exaggerated visuals
"""

import numpy as np
import torch
from typing import Dict, List, Tuple

# Your 64 genetic codons from humanDesignGates.ts
CODON_SEQUENCE = [
    "TTT", "TTC", "TTA", "TTG", "TCT", "TCC", "TCA", "TCG",
    "TAT", "TAC", "TAA", "TAG", "TGT", "TGC", "TGA", "TGG", 
    "CTT", "CTC", "CTA", "CTG", "CCT", "CCC", "CCA", "CCG",
    "CAT", "CAC", "CAA", "CAG", "CGT", "CGC", "CGA", "CGG",
    "ATT", "ATC", "ATA", "ATG", "ACT", "ACC", "ACA", "ACG",
    "AAT", "AAC", "AAA", "AAG", "AGT", "AGC", "AGA", "AGG",
    "GTT", "GTC", "GTA", "GTG", "GCT", "GCC", "GCA", "GCG", 
    "GAT", "GAC", "GAA", "GAG", "GGT", "GGC", "GGA", "GGG"
]

class CodonResonanceElement:
    """Individual resonance element for each codon"""
    def __init__(self, codon_id: int, codon_sequence: str):
        self.id = codon_id
        self.sequence = codon_sequence
        self.frequency = self.calculate_base_frequency()
        self.harmonics = self.calculate_harmonic_series()
        self.visual_properties = self.generate_sims_properties()
        
    def calculate_base_frequency(self) -> float:
        """Calculate base resonance frequency from codon sequence"""
        # Each nucleotide has different frequency
        nucleotide_freq = {'T': 220.0, 'C': 293.66, 'A': 329.63, 'G': 392.0}  # Musical notes
        
        freq = 1.0
        for nucleotide in self.sequence:
            freq *= nucleotide_freq[nucleotide]
        return (freq ** (1/3)) / 100  # Normalize to reasonable range
        
    def calculate_harmonic_series(self) -> List[float]:
        """Generate harmonic frequencies for resonance overlays"""
        harmonics = []
        for i in range(1, 8):  # 7 harmonics
            harmonics.append(self.frequency * i)
        return harmonics
        
    def generate_sims_properties(self) -> Dict:
        """Generate Sims-style visual properties"""
        return {
            'color_hue': (self.id * 5.625) % 360,  # Spread across color wheel
            'glow_intensity': 0.3 + (self.frequency / 10),
            'pulse_rate': self.frequency * 2,
            'size_modifier': 0.8 + (self.id / 64) * 0.4,  # Progressive growth
            'sparkle_count': self.id % 10 + 3,
            'animation_speed': self.frequency * 1.5
        }

class ProgressiveCodonScene:
    """Scene that builds progressively with each codon"""
    def __init__(self):
        self.elements = []  # Accumulated resonance elements
        self.resonance_overlays = []  # GameGAN overlay patterns
        self.scene_complexity = 0
        
    def add_codon(self, codon_id: int) -> Dict:
        """Add new codon to scene, building on previous"""
        new_element = CodonResonanceElement(codon_id, CODON_SEQUENCE[codon_id-1])
        self.elements.append(new_element)
        
        # Calculate resonance with existing elements
        new_resonances = self.calculate_resonance_overlays(new_element)
        self.resonance_overlays.extend(new_resonances)
        
        # Build progressive scene
        scene_data = self.render_progressive_scene()
        
        return {
            'scene_data': scene_data,
            'total_elements': len(self.elements),
            'resonance_overlays': len(self.resonance_overlays),
            'complexity_level': self.scene_complexity
        }
        
    def calculate_resonance_overlays(self, new_element: CodonResonanceElement) -> List[Dict]:
        """Calculate GameGAN overlays between new element and existing ones"""
        overlays = []
        
        for existing in self.elements[:-1]:  # Don't include the new element itself
            # Calculate frequency resonance
            freq_ratio = new_element.frequency / existing.frequency
            
            # Create overlay if frequencies are in harmonic relationship
            if self.is_harmonic_resonance(freq_ratio):
                overlay = {
                    'type': 'harmonic_bridge',
                    'element1_id': existing.id,
                    'element2_id': new_element.id,
                    'resonance_strength': self.calculate_resonance_strength(freq_ratio),
                    'visual_effect': self.generate_overlay_visual(existing, new_element),
                    'animation_pattern': self.create_resonance_animation(freq_ratio)
                }
                overlays.append(overlay)
                
        return overlays
        
    def is_harmonic_resonance(self, freq_ratio: float) -> bool:
        """Check if frequency ratio creates harmonic resonance"""
        # Check for simple harmonic ratios (octaves, fifths, fourths, etc.)
        harmonic_ratios = [0.5, 0.75, 1.0, 1.33, 1.5, 2.0, 2.5, 3.0]
        tolerance = 0.1
        
        for ratio in harmonic_ratios:
            if abs(freq_ratio - ratio) < tolerance:
                return True
        return False
        
    def calculate_resonance_strength(self, freq_ratio: float) -> float:
        """Calculate strength of resonance between frequencies"""
        # Perfect harmonic ratios have strongest resonance
        perfect_ratios = {0.5: 1.0, 0.75: 0.8, 1.0: 1.0, 1.5: 0.9, 2.0: 1.0}
        
        for ratio, strength in perfect_ratios.items():
            if abs(freq_ratio - ratio) < 0.1:
                return strength
                
        return 0.3  # Weak resonance for non-harmonic ratios
        
    def generate_overlay_visual(self, elem1: CodonResonanceElement, elem2: CodonResonanceElement) -> Dict:
        """Generate Sims-style visual overlay between two elements"""
        return {
            'connection_type': 'energy_beam',
            'color_blend': self.blend_colors(elem1.visual_properties['color_hue'], 
                                           elem2.visual_properties['color_hue']),
            'glow_pattern': 'pulsing_wave',
            'particle_trail': True,
            'sparkle_bridge': True,
            'intensity': (elem1.visual_properties['glow_intensity'] + 
                         elem2.visual_properties['glow_intensity']) / 2
        }
        
    def create_resonance_animation(self, freq_ratio: float) -> Dict:
        """Create animation pattern for resonance overlay"""
        return {
            'wave_frequency': freq_ratio * 2,
            'amplitude': min(freq_ratio, 2.0),
            'phase_shift': freq_ratio * np.pi,
            'animation_type': 'sine_wave_flow',
            'duration': 3.0 + freq_ratio,
            'loop': True
        }
        
    def render_progressive_scene(self) -> np.ndarray:
        """Render complete scene with all elements and overlays"""
        # Scene gets more complex with each codon
        scene_size = (512, 512, 3)  # RGB image
        scene = np.zeros(scene_size)
        
        # Base environment (Sims-style)
        scene = self.add_sims_environment(scene)
        
        # Render all accumulated elements
        for element in self.elements:
            scene = self.render_codon_element(scene, element)
            
        # Render all resonance overlays
        for overlay in self.resonance_overlays:
            scene = self.render_resonance_overlay(scene, overlay)
            
        # Add progressive complexity effects
        scene = self.add_complexity_effects(scene)
        
        self.scene_complexity = len(self.elements) * len(self.resonance_overlays)
        return scene
        
    def add_sims_environment(self, scene: np.ndarray) -> np.ndarray:
        """Add Sims-style background environment"""
        # Colorful, cartoon-like background
        gradient = np.linspace(0.2, 0.8, scene.shape[0])
        scene[:, :, 0] = gradient[:, None]  # Blue gradient
        scene[:, :, 1] = 0.1  # Minimal green
        scene[:, :, 2] = 0.3 + gradient[:, None] * 0.2  # Purple tones
        
        return scene
        
    def render_codon_element(self, scene: np.ndarray, element: CodonResonanceElement) -> np.ndarray:
        """Render individual codon as Sims-style visual element"""
        props = element.visual_properties
        
        # Position based on ID (spiral pattern)
        angle = element.id * 0.1
        center_x = int(256 + 150 * np.cos(angle))
        center_y = int(256 + 150 * np.sin(angle))
        
        # Size increases with progression
        radius = int(20 * props['size_modifier'])
        
        # Draw glowing orb
        y, x = np.ogrid[:scene.shape[0], :scene.shape[1]]
        mask = (x - center_x)**2 + (y - center_y)**2 <= radius**2
        
        # Apply Sims-style colors
        hue_rad = props['color_hue'] * np.pi / 180
        r = 0.5 + 0.5 * np.cos(hue_rad)
        g = 0.5 + 0.5 * np.cos(hue_rad + 2*np.pi/3)
        b = 0.5 + 0.5 * np.cos(hue_rad + 4*np.pi/3)
        
        scene[mask, 0] = np.clip(scene[mask, 0] + r * props['glow_intensity'], 0, 1)
        scene[mask, 1] = np.clip(scene[mask, 1] + g * props['glow_intensity'], 0, 1)
        scene[mask, 2] = np.clip(scene[mask, 2] + b * props['glow_intensity'], 0, 1)
        
        return scene
        
    def render_resonance_overlay(self, scene: np.ndarray, overlay: Dict) -> np.ndarray:
        """Render GameGAN-style resonance overlay"""
        if overlay['type'] == 'harmonic_bridge':
            elem1 = next(e for e in self.elements if e.id == overlay['element1_id'])
            elem2 = next(e for e in self.elements if e.id == overlay['element2_id'])
            
            # Draw energy beam between elements
            scene = self.draw_energy_beam(scene, elem1, elem2, overlay['visual_effect'])
            
        return scene
        
    def draw_energy_beam(self, scene: np.ndarray, elem1: CodonResonanceElement, 
                        elem2: CodonResonanceElement, visual: Dict) -> np.ndarray:
        """Draw Sims-style energy beam between two elements"""
        # Calculate positions
        angle1 = elem1.id * 0.1
        pos1 = (int(256 + 150 * np.cos(angle1)), int(256 + 150 * np.sin(angle1)))
        
        angle2 = elem2.id * 0.1  
        pos2 = (int(256 + 150 * np.cos(angle2)), int(256 + 150 * np.sin(angle2)))
        
        # Draw beam line with glow effect
        beam_points = self.interpolate_beam_points(pos1, pos2, 50)
        
        for i, (x, y) in enumerate(beam_points):
            if 0 <= x < scene.shape[1] and 0 <= y < scene.shape[0]:
                # Pulsing intensity along beam
                intensity = visual['intensity'] * (0.5 + 0.5 * np.sin(i * 0.2))
                
                # Beam glow
                for dx in range(-3, 4):
                    for dy in range(-3, 4):
                        if 0 <= x+dx < scene.shape[1] and 0 <= y+dy < scene.shape[0]:
                            glow = intensity * np.exp(-(dx**2 + dy**2) / 6)
                            scene[y+dy, x+dx, :] = np.clip(scene[y+dy, x+dx, :] + glow, 0, 1)
                            
        return scene
        
    def interpolate_beam_points(self, pos1: Tuple[int, int], pos2: Tuple[int, int], 
                               num_points: int) -> List[Tuple[int, int]]:
        """Create smooth curve between two points"""
        points = []
        for i in range(num_points):
            t = i / (num_points - 1)
            x = int(pos1[0] * (1-t) + pos2[0] * t)
            y = int(pos1[1] * (1-t) + pos2[1] * t)
            points.append((x, y))
        return points
        
    def add_complexity_effects(self, scene: np.ndarray) -> np.ndarray:
        """Add progressive complexity effects as more codons accumulate"""
        complexity_factor = min(self.scene_complexity / 1000, 1.0)
        
        # Add sparkles based on complexity
        num_sparkles = int(complexity_factor * 100)
        for _ in range(num_sparkles):
            x, y = np.random.randint(0, scene.shape[1]), np.random.randint(0, scene.shape[0])
            sparkle_intensity = complexity_factor * 0.5
            scene[y, x, :] = np.clip(scene[y, x, :] + sparkle_intensity, 0, 1)
            
        return scene
        
    def blend_colors(self, hue1: float, hue2: float) -> float:
        """Blend two color hues"""
        return (hue1 + hue2) / 2

class CodonResonanceGameGAN:
    """Main system for generating 64-codon progressive resonance scenes"""
    
    def __init__(self):
        self.progressive_scene = ProgressiveCodonScene()
        self.generated_scenes = []
        
    def generate_all_64_codons(self) -> List[Dict]:
        """Generate all 64 progressive codon scenes"""
        print("🌟 Generating 64-Codon Progressive Resonance Scenes...")
        
        for codon_id in range(1, 65):
            print(f"   Codon {codon_id}/64: {CODON_SEQUENCE[codon_id-1]}")
            
            scene_result = self.progressive_scene.add_codon(codon_id)
            scene_result['codon_id'] = codon_id
            scene_result['codon_sequence'] = CODON_SEQUENCE[codon_id-1]
            
            self.generated_scenes.append(scene_result)
            
        print(f"✅ Generated {len(self.generated_scenes)} progressive resonance scenes!")
        return self.generated_scenes
        
    def create_resonance_animation(self) -> List[np.ndarray]:
        """Create animation sequence showing progressive codon evolution"""
        frames = []
        for scene in self.generated_scenes:
            frames.append(scene['scene_data'])
        return frames
        
    def get_scene_by_codon(self, codon_id: int) -> Dict:
        """Get specific codon scene"""
        if 1 <= codon_id <= 64:
            return self.generated_scenes[codon_id - 1]
        return None

# Usage Example
if __name__ == "__main__":
    print("🎮 64-Codon Progressive Resonance with GameGAN Overlays")
    print("🎨 Sims-style Visual Aesthetic")
    print("🌊 Each codon builds on the previous + resonance layers")
    
    # Create the resonance system
    resonance_gan = CodonResonanceGameGAN()
    
    # Generate all 64 progressive scenes
    all_scenes = resonance_gan.generate_all_64_codons()
    
    # Show progression stats
    for i, scene in enumerate(all_scenes[::10]):  # Every 10th scene
        codon_id = scene['codon_id']
        elements = scene['total_elements'] 
        overlays = scene['resonance_overlays']
        complexity = scene['complexity_level']
        
        print(f"Codon {codon_id}: {elements} elements, {overlays} overlays, complexity: {complexity}")
        
    print("\n🚀 Progressive resonance complete!")
    print("Each scene contains all previous codons + new resonance patterns!")
    print("GameGAN overlays show harmonic connections in Sims style!")